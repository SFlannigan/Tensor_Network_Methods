% Exact diagonalization of the same problem
%
% Run right after spinhalf_dmrg.m
%
% Note: don't run for large M

if M>11
    error('ERROR: system is too large for ED')
end

%% create operators

sxns = cell(M,1);
syns = cell(M,1);
szns = cell(M,1);
spns = cell(M,1);
smns = cell(M,1);
for iM = 1:M
    sxns{iM} = kron(kron(speye(2^(M-iM)),sx) , speye(2^(iM-1)));
    syns{iM} = kron(kron(speye(2^(M-iM)),sy) , speye(2^(iM-1)));
    szns{iM} = kron(kron(speye(2^(M-iM)),sz) , speye(2^(iM-1)));
    spns{iM} = kron(kron(speye(2^(M-iM)),sp) , speye(2^(iM-1)));
    smns{iM} = kron(kron(speye(2^(M-iM)),sm) , speye(2^(iM-1)));
end

%% create transverse Ising Hamiltonians (choose one)

H = 0;
% interaction term
if is_long_range
    % or long-range
    for i1 = 1:M-1
        for i2 = i1+1:M
            H = H + J/(i2-i1)^alpha * sxns{i1}*sxns{i2};
        end
    end
else    
    % nearest neighbour
    for i1 = 1:M-1
        H = H + J * sxns{i1}*sxns{i1+1};
    end
end

% field term
for iM = 1:M           
    H = H + B * szns{iM};
end

%% eigensystem

[eVec,eVal] = eig(H);

%% correlation matrices

exp_zz_exact = zeros(M,M,n_st);
exp_xx_exact = zeros(M,M,n_st);
exp_pm_exact = zeros(M,M,n_st);
exp_xy_exact = zeros(M,M,n_st);

for jj=1:n_st
    for i1=1:M
        for i2=1:M
            exp_zz_exact(i1,i2,jj)=eVec(:,jj)'*szns{i1}*szns{i2}*eVec(:,jj);
            exp_xx_exact(i1,i2,jj)=eVec(:,jj)'*sxns{i1}*sxns{i2}*eVec(:,jj);
            exp_pm_exact(i1,i2,jj)=eVec(:,jj)'*spns{i1}*smns{i2}*eVec(:,jj);
            exp_xy_exact(i1,i2,jj)=eVec(:,jj)'*sxns{i1}*syns{i2}*eVec(:,jj);
        end
    end
end
    
%% absolute errors of correlation matrices

for jj=1:n_st
    [max(max(abs(exp_zz_exact(:,:,jj) - exp_zz(:,:,jj)))),...
     max(max(abs(exp_xx_exact(:,:,jj) - exp_xx(:,:,jj)))),...
     max(max(abs(exp_pm_exact(:,:,jj) - exp_pm(:,:,jj)))),...
     max(max(abs(exp_xy_exact(:,:,jj) - exp_xy(:,:,jj))))]
end
















