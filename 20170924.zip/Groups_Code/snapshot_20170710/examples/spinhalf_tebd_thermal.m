% Imaginary Time Evolving Block Decimation Algorithm for MPS
% Preparation of finite-T states 
% 
% Algorithm:
% 1. Start with the infinity temperature density matrix (beta=0)
% 2. Vectorize in order to use MPS routines
% 3. Evolve with exp(-H*beta/2/n)
% 4. Repeat Step 3 n times to reach the density matrix with the desired temperature
% 4a.In the limit beta->infty one reaches the ground state, i.e. T=0
% 5. Run spinhalf_tebd_thermal_check.m for benchmarking
%
% Comment: here we try 2 methods: 
% 1. evolution rho(beta)=exp(-H*beta/2)*rho0*exp(-H*beta/2), i.e. without purification,
% 2. and with purification
%
% (Purification is clearly better as it preserves the positivity
% of rho by construction, however if one needs to obtain the density matrix
% the first method has it explicitly. The second method will require
% purification hence the bond dimentions will be squared(!), which will
% require additional compression. The second method will still give
% better results, but the first one can be easily used for benchmarking.)
%
% Ref: FIND A GOOD ONE, so far read arxiv.org/abs/1008.4303 seq. 1.2.2

clear *

addpath('../kernel/');
addpath('../tools/');

%% parameters

d=2;                        % local dimension, spin-1/2
paulis;                     % Pauli matrices
M=10;                       % number of spins
J=1;                        % interaction strength
is_long_range=0;            % 0 --- next-neighbour interractions
                            % 1 --- long-range interactions THIS CASE IS NOT READY
B=1;                        % field strength
Dmax=32;                    % maximum bond dimension

% initially start from beta=0
beta.max=10;
beta.step=0.1;
beta.vec=0:beta.step:beta.max;
beta.n=length(beta.vec);
beta.nsubstep=1;            % substeps between expectation values calculation

order=2;                    % order of the Suzuki-Trotter decomposition (2 or 4)
isclean=1;                  % test parameter
is_dyn_trunc=0;             % test parameter

%% create density matrix

rho=mpo(M);
rho=rho.set_proda(eye(d)); % this density matrix corresponds to the infinite
                           % temperature (not normalized)
% rho_std=rho.get_mpo_in_standard_basis

% vectorize rho
% dimensions: d_out*d_in x DL x DR
% version without purification
rho_vec=mps(M,Dmax);
rho_vec=rho_vec.convert_mpo2mps(rho);
rho_vec=rho_vec.make_canonical(1);
% version with purification
rho_vec_pur=mps(M,Dmax);
rho_vec_pur=rho_vec_pur.convert_mpo2mps(rho);
rho_vec_pur=rho_vec_pur.make_canonical(1);

%% create transverse Ising Hamiltonians

% the nearest neighbour interaction Hamiltonian should be split in a sum on
% local 2-site operators

% create trotter gates
if is_long_range
    error('TEBD example with long range interacions is not finished')
else
    % first, create the order of gate application
    if     order==2
        [o2sweep,gate_order]=rho_vec.create_trotter2_nn_sweep();
        gates2=cell(1,size(gate_order,1)); % beta.step/2
    elseif order==4
        [o4sweep,gate_order]=rho_vec.create_trotter4_nn_sweep();
        gates4=cell(2,size(gate_order,1)); % beta.step/12 and -beta.step/6
    else
        error('Only order 2 and 4 are available')
    end
    
    % CC --- complex conjugated version, needed for the method w/o purification
    if     order==2
        [o2sweep_CC,gate_order_CC]=rho_vec.create_trotter2_nn_sweep();
        gates2_CC=cell(1,size(gate_order_CC,1)); % beta.step/2
    elseif order==4
        [o4sweep_CC,gate_order_CC]=rho_vec.create_trotter4_nn_sweep();
        gates4_CC=cell(2,size(gate_order_CC,1)); % beta.step/12 and -beta.step/6
    else
        error('Only order 2 and 4 are available')
    end
    
    % second, create the gates
    for ig=1:size(gate_order,1)
        % number of the gate == number of the first site in the pair of
        % sites this gate is applied to
        iM1=gate_order(ig,1);
        
        % In this scheme we operate with the vectorized density matrix,
        % hence the operators are applied only on a half of the local
        % Hilbert space.
        
        % Local dimension is d_output*d_input, hence we need to act on the
        % second half of the local Hilbert space. Then the local operators are:
        sx_dm=kron(id,sx);
        sz_dm=kron(id,sz);
        id_dm=kron(id,id);
        d_dm =d^2;
        
        % Follow this rule to create a 2 site operator in the martix form:
        % Opetaror_for_2_sites = kron(operator_for_left_site,operator_for_right_site)
        
        % the interaction part is the same for all the gates
        Hlocal=J*kron(sx_dm,sx_dm);
        
        % the local part depends on the site position
        % O---O---O---O---O---...
        % |   |   |   |   |  
        % [===]   |   |   |
        % |   |   |   |   |
        % |   [===]   |   |
        % |   |   |   |   |
        % |   |   [===]   |
        % ...
        if     iM1==1
            Hlocal=Hlocal+B*(kron(sz_dm,id_dm)  +kron(id_dm,sz_dm)/2);
        elseif iM1==M-1
            Hlocal=Hlocal+B*(kron(sz_dm,id_dm)/2+kron(id_dm,sz_dm)  );
        else
            Hlocal=Hlocal+B*(kron(sz_dm,id_dm)/2+kron(id_dm,sz_dm)/2);
        end
        
        % bring to "gate form" from "kron form"
        % (this is an important step, as kron and reshape order states
        % differently)
        Hlocal=reshape(Hlocal,[d_dm d_dm d_dm d_dm]);
        Hlocal=permute(Hlocal,[2 1 4 3]); 
        Hlocal=reshape(Hlocal,[d_dm*d_dm d_dm*d_dm]);
        
        % NB: extra 1/2 is related to the purification scheme
        if     order==2
            gates2{1,ig}=expm(-beta.step/2 *Hlocal/2/beta.nsubstep);
        elseif order==4
            gates4{1,ig}=expm(-beta.step/12*Hlocal/2/beta.nsubstep);
            gates4{2,ig}=expm(+beta.step/6 *Hlocal/2/beta.nsubstep);
        else
            error('Only order 2 and 4 are available')
        end
        
        %% CC --- gates that will be used for the Complex Conjugated evolution
        % i.e. we act on the first part of the local Hilber space
        if     order==2
            tmp=reshape(gates2{1,ig},[d d d d d d d d]);
            tmp=permute(tmp,[2 1 4 3 6 5 8 7]);
            gates2_CC{1,ig}=reshape(tmp,[d^4 d^4]);
        elseif order==4
            tmp=reshape(gates4{1,ig},[d d d d d d d d]);
            tmp=permute(tmp,[2 1 4 3 6 5 8 7]);
            gates4_CC{1,ig}=reshape(tmp,[d^4 d^4]);
            tmp=reshape(gates4{2,ig},[d d d d d d d d]);
            tmp=permute(tmp,[2 1 4 3 6 5 8 7]);
            gates4_CC{2,ig}=reshape(tmp,[d^4 d^4]); 
        else
            error('Only order 2 and 4 are available')
        end        
        %% CC END
        
    end
end

%% tebd sweeps

exp_z=zeros(M,beta.n);
exp_z_pur=zeros(M,beta.n);

for ibeta=1:beta.n
    tic;
    if ibeta>1
        for ii=1:beta.nsubstep
            if     order==2
                [rho_vec,trunc]=rho_vec.apply_tebd_sweep(gates2,o2sweep,1,isclean,is_dyn_trunc);
                [rho_vec,trunc]=rho_vec.apply_tebd_sweep(gates2_CC,o2sweep_CC,1,isclean,is_dyn_trunc);

                [rho_vec_pur,trunc]=rho_vec_pur.apply_tebd_sweep(gates2,o2sweep,1,isclean,is_dyn_trunc);
            elseif order==4
                [rho_vec,trunc]=rho_vec.apply_tebd_sweep(gates4,o4sweep,1,isclean,is_dyn_trunc);
                [rho_vec,trunc]=rho_vec.apply_tebd_sweep(gates4_CC,o4sweep_CC,1,isclean,is_dyn_trunc);
                
                [rho_vec_pur,trunc]=rho_vec_pur.apply_tebd_sweep(gates4,o4sweep,1,isclean,is_dyn_trunc);
            end
%             rho_vec=rho_vec.clean();         % !!! check if this is needed at all
%             rho_vec_pur=rho_vec_pur.clean(); % !!! check if this is needed at all
        end       
    end
    
    % partition function Z
    % w/o purification
    Z=1;
    for iM=1:M
        tmp=rho_vec.data{iM};
        [d_dm,DL,DR]=size(tmp);
        d=sqrt(d_dm);
        tmp=reshape(tmp,[d d DL DR]);
        Z=ncon({Z,tmp},{[-1 2],[1 1 2 -2]},[1 2]);
    end  
    % w/  purification
    Z_pur=(rho_vec_pur.get_norm())^2;
    
    % local expectation values
    % w/o purification
    for iMM=1:M
        exp_z_tmp=1;
        for iM=1:M
            tmp=rho_vec.data{iM};
            [d_dm,DL,DR]=size(tmp);
            d=sqrt(d_dm);
            tmp=reshape(tmp,[d d DL DR]);
            if iM==iMM
                exp_z_tmp=ncon({exp_z_tmp,tmp,sz},{[-1 3],[1 2 3 -2],[2 1]},[1 2 3]);
            else
                exp_z_tmp=ncon({exp_z_tmp,tmp},{[-1 2],[1 1 2 -2]},[1 2]);
            end
        end 
        exp_z(iMM,ibeta)=exp_z_tmp/Z;
    end
    % w/ purification
    exp_z_pur(:,ibeta)=rho_vec_pur.get_loc_expc(kron(id,sz))/Z_pur;
    
    disp(['step #' num2str(ibeta,'%03i') '/' num2str(beta.n,'%03i') ...
        ' -- beta=' num2str(beta.vec(ibeta))...
        ' -- cpu time=' num2str(toc)])
end






























