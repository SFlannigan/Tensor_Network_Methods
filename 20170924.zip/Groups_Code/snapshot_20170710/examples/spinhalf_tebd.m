% Time Evolving Block Decimation Algorithm for MPS
% 
% Ref: FIND A GOOD ONE, so far read Johannes' master thesis

clear *

addpath('../kernel/');
addpath('../tools/');

%% parameters

paulis;                     % Pauli matrices
M=10;                       % number of spins
J=1;                        % interaction strength
is_long_range=0;            % 0 --- next-neighbour interractions
                            % 1 --- long-range interactions THIS CASE IS NOT READY
B=1;                        % field strength
Dmax=64;                    % maximum bond dimension

dt=0.02;
t_max=2;
steps=t_max/dt+1;
order=2;                    % order of the Suzuki-Trotter decomposition (2 or 4)
isclean=1;                  % test parameter

%% create initial state

is_dyn_trunc=1;             % test parameter
if is_dyn_trunc
    % compare this
    state=mps(M,1);
    state=state.set_product_state([1;0]); % all spins up
    state=state.make_canonical(1);
    state=state.set_Dmax(Dmax);
else
    % vs this
    state=mps(M,Dmax);
    state=state.set_product_state([1;0]); % all spins up
    state=state.make_canonical(1);
end

%% create transverse Ising Hamiltonians

% the nearest neighbour interaction Hamiltonian should be split in a sum on
% local 2-site operators

d = 2; % local dimension

% create trotter gates
if is_long_range
    error('TEBD example with long range interacions is not finished')
else
    % first, create the order of gate application
    if     order==2
        [o2sweep,gate_order] = state.create_trotter2_nn_sweep();
        gates2 = cell(1,size(gate_order,1)); % dt/2
    elseif order==4
        [o4sweep,gate_order] = state.create_trotter4_nn_sweep();
        gates4 = cell(2,size(gate_order,1)); % dt/12 and -dt/6
    else
        error('Only order 2 and 4 are available')
    end
    
    % second, create the gates
    for ig=1:size(gate_order,1)
        % number of the gate == number of the left spin in the pair of
        % spins this gate is applied
        ii=gate_order(ig,1);

        % Follow this rule to create a 2 site operator in the martix form:
        % Opetaror_for_2_sites = kron(operator_for_left_spin,operator_for_right_spin)
        
        % the interaction part is the same
        Hlocal = J * kron(sx,sx);

        % the local part depends on the site position
        if     ii==1
            Hlocal = Hlocal + B * ( kron(sz,id)   + kron(id,sz)/2 );
        elseif ii==M-1
            Hlocal = Hlocal + B * ( kron(sz,id)/2 + kron(id,sz)   );
        else
            Hlocal = Hlocal + B * ( kron(sz,id)/2 + kron(id,sz)/2 );
        end

        % bring to "gate form" from "kron form"
        % (this is an important step, as kron and reshape order states
        % differently)
        Hlocal=reshape(Hlocal,[d d d d]);
        Hlocal=permute(Hlocal,[2 1 4 3]); 
        Hlocal=reshape(Hlocal,[d*d d*d]);

        if     order==2
            gates2{1,ig} = expm(-1i*( dt/2 )*Hlocal);
        elseif order==4
            gates4{1,ig} = expm(-1i*( dt/12)*Hlocal);
            gates4{2,ig} = expm(-1i*(-dt/6 )*Hlocal);
        else
            error('Only order 2 and 4 are available')
        end
    end
end



%% tebd sweeps

exp_z=zeros(M,steps);
svn=zeros(M-1,steps);         % von Neumann entropy

for tt=1:steps
    tic;
    % evaluation
    exp_z(:,tt)=state.get_loc_expc(sz);
    
    lams=state.get_schmidt();
    for il=1:M-1
        tmp=lams{il}.^2;
        svn(il,tt) = -tmp' * log( tmp + (tmp==0) );
    end    
   
    if     order==2
        [state,trunc]=state.apply_tebd_sweep(gates2,o2sweep,1,isclean,is_dyn_trunc);
    elseif order==4
        [state,trunc]=state.apply_tebd_sweep(gates4,o4sweep,1,isclean,is_dyn_trunc);
    end
    state=state.clean();
    
    disp(['step #' num2str(tt)...
        ' -- time=' num2str((tt-1)*dt)...
        ' -- cpu time=' num2str(toc)...
        ': svn=' num2str(svn(round(M/2)+1,tt))])
end

%% plotting

% bar3(exp_pm)



























