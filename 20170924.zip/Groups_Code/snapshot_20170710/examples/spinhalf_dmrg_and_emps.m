% Iterative ground and first excited states search with MPS
% 
% Ref: e.g. arxiv.org/abs/1008.3477, section 6.3

clear *

addpath('../kernel/');
addpath('../tools/');

%% parameters

paulis;                     % Pauli matrices
M=10;                       % number of spins
J=1;                        % interaction strength
is_long_range=0;            % 0 --- next-neighbour interractions
                            % 1 --- long-range interactions
B=1;                        % field strength
Dmax=64;                    % maximum bond dimension

%% create transverse Ising Hamiltonians (choose one)

ham=mpo(M);
if is_long_range
    % long-range intereaction case
    alpha=4;                    % power law decay rate
    % create decomposition of interaction decay function into sum of exponentials
    relres_lim=1e-6;            % the smaller the better, but depends on the problem
    nroe_max=20;                % number of exponents
    dec_fun=1./(1:(M-1)).^alpha;
    exdec=sum_of_exponentials(dec_fun,nroe_max,relres_lim);
    ham=ham.set_n1sumaa_sumc_lr(sqrt(abs(J))*sx,B*sz,sign(J),exdec);
else
    % nearest neighbour interaction case
    ham=ham.set_sumab_sumc(J*sx,sx,B*sz);
end

%% create initial states

n_st = 3;                   % number of states to find
state=cell(n_st,1);
for jj=1:length(state)
    state{jj}=mps(M,Dmax);
    state{jj}=state{jj}.set_product_state([1;1]/sqrt(2));
    state{jj}=state{jj}.make_canonical(1);
end

%% search

disp('Ground state search...')
max_sweeps=20;
% stop when relative energy change is smaller than stop_thres:
stop_thres=1e-10; 
tmp_en=1;
for jj=1:max_sweeps
    [state{1},conv]=state{1}.apply_dmrg_ns_sweep(2,ham,Dmax);
    en=conv.sweep_en(end);
    rel_en=abs(en-tmp_en)./en;
    disp(['sweep #' num2str(jj) ...
          ' -- energy = ' num2str(en) ...
          ' -- rel_en = ' num2str(rel_en)])
    tmp_en=en;
    if abs(rel_en)<stop_thres
        break
    end
end

for jj = 2:n_st
    disp(['State ' num2str(jj) ' search...'])
    
    % previous states need to be transfered as a cell vertor
    state_prev = cell(jj-1,1);
    for ii = 1:jj-1
        state_prev{ii} = state{ii};
    end
    
    tmp_en=1;
    for ii=1:max_sweeps
        [state{jj},conv]=state{jj}.apply_emps_ns_sweep(2,ham,Dmax,state_prev);
        en=conv.sweep_en(end);
        rel_en=abs(en-tmp_en)./en;
        disp(['sweep #' num2str(ii) ...
              ' -- energy = ' num2str(en) ...
              ' -- rel_en = ' num2str(rel_en)])
        tmp_en=en;
        if abs(rel_en)<stop_thres
            break
        end
    end
end

%% calculating expectation values

exp_z = zeros(M,n_st);
exp_zz = zeros(M,M,n_st);
exp_xx = zeros(M,M,n_st);
exp_pm = zeros(M,M,n_st);
exp_xy = zeros(M,M,n_st);

for ii=1:n_st
    % local operators
    exp_z(:,ii)   =state{ii}.get_loc_expc(sz);
    % Hermitian correlation matrices
    exp_zz(:,:,ii)=state{ii}.get_corr_mat_herm(sz,sz);
    exp_xx(:,:,ii)=state{ii}.get_corr_mat_herm(sx,sx);
    exp_pm(:,:,ii)=state{ii}.get_corr_mat_herm(sp,sm);
    % any correlation matrix
    exp_xy(:,:,ii)=state{ii}.get_corr_mat(sx,sy);
end

%% plotting

% figure(1)
% bar3(abs(exp_pm(:,:,1)))
% figure(2)
% bar3(abs(exp_pm(:,:,2)))



























