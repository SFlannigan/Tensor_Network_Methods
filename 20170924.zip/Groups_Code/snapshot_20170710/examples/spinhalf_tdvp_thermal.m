% Imaginary Time Evolving Block Decimation Algorithm for MPS
% Preparation of finite-T states 
% 
% Algorithm:
% 1. Start with the infinity temperature density matrix (beta=0)
% 2. Vectorize in order to use MPS routines
% 3. Evolve with exp(-H*beta/2/n)
% 4. Repeat Step 3 n times to reach the density matrix with the desired temperature
% 4a.In the limit beta->infty one reaches the ground state, i.e. T=0
% 5. Run spinhalf_tebd_thermal_check.m for benchmarking
%
% Comment: here we try 2 methods: 
% 1. evolution rho(beta)=exp(-H*beta/2)*rho0*exp(-H*beta/2), i.e. without purification,
% 2. and with purification
%
% (Purification is clearly better as it preserves the positivity
% of rho by construction, however if one needs to obtain the density matrix
% the first method has it explicitly. The second method will require
% purification hence the bond dimentions will be squared(!), which will
% require additional compression. The second method will still give
% better results, but the first one can be easily used for benchmarking.)
%
% Ref: FIND A GOOD ONE, so far read arxiv.org/abs/1008.4303 seq. 1.2.2

clearvars

addpath('../kernel/');
addpath('../tools/');

%% parameters

d=2;                        % local dimension, spin-1/2
paulis;                     % Pauli matrices
M=10;                       % number of spins
J=1;                        % interaction strength
isPBC=0;                    % 1 --- PBC, 
                            % 0 --- OBC
B=1;                        % field strength
Dmax=32;                    % maximum bond dimension

% initially start from beta=0
beta.max=5;
beta.step=0.1;
beta.vec=0:beta.step:beta.max;
beta.n=length(beta.vec);
beta.nsubstep=1;            % substeps between expectation values calculation

order=2;                    % order of the Suzuki-Trotter decomposition (2 or 4)
expv_opts.tol=1e-7;
expv_opts.nkryl=20;
expv_opts.isclean=0;                % test parameter
expv_opts.is_dyn_trunc=1;           % test parameter
expv_opts.is_norm=0;                % normalization after tdvp


%% create density matrix

rho=mpo(M);
rho=rho.set_proda(eye(d)); % this density matrix corresponds to the infinite
                           % temperature (not normalized)
% rho_std=rho.get_mpo_in_standard_basis()

% vectorize rho
% dimensions: d_out*d_in x DL x DR
rho_vec=mps(M,Dmax);
rho_vec=rho_vec.convert_mpo2mps(rho);
rho_vec=rho_vec.make_bond_dim_to_max(); % increases precision of TDVP
rho_vec=rho_vec.make_canonical(1,0); % do not normalize!

%% create transverse Ising Hamiltonians

ham=mpo(M);
ham=ham.set_n1sumaa_n2sumbb_n3sumcc_sumd(sx,sy,sz,B*sz^2,J,J,J); % open boundary condition
if isPBC
    ham=ham.add_pbc_n1aa_n2bb_n3cc(sx,sy,sz,J,J,J);
end

% add auxiliary spin at each site
for iM=1:M
    ham=ham.set_data(superkron(eye(d),ham.data{iM}),iM);
end

%% tdvp sweeps

exp_z =zeros(M,beta.n);
energy=zeros(1,beta.n);
Z     =zeros(1,beta.n);

for ibeta=1:beta.n
    tic;  
    if ibeta>1
        for ii=1:beta.nsubstep
            [rho_vec,conv.tdvp{ibeta,ii}]=rho_vec.apply_tdvp_2s_trotter(ham,...
                -1i*beta.step/2/beta.nsubstep,expv_opts,order);
        end       
    end
    
    % evaluation
    Z(ibeta)=(rho_vec.get_norm())^2;
    exp_z(:,ibeta)=rho_vec.get_loc_expc(kron(id,sz))/Z(ibeta);
    energy(ibeta) =rho_vec.get_mpo_expc(ham)/Z(ibeta);
    
    disp(['step #' num2str(ibeta,'%03i') '/' num2str(beta.n,'%03i') ...
        ' -- beta=' num2str(beta.vec(ibeta))...
        ' -- cpu time=' num2str(toc)])
end

% entropy
S=log(Z)+energy.*beta.vec;






























