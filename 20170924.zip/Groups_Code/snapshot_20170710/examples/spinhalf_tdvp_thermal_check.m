% Exact diagonalization calculation of the same problem as in
% spinhalf_tdvp_thermal.m
%
% Run this script without changing anything 
%
% Note: don't run for large M

if M>10
    error('ERROR: system is too large for ED')
end

%% create operators

sxns=cell(M,1);
syns=cell(M,1);
szns=cell(M,1);
spns=cell(M,1);
smns=cell(M,1);
for iM=1:M
    sxns{iM}=kron(kron(speye(2^(M-iM)),sx),speye(2^(iM-1)));
    syns{iM}=kron(kron(speye(2^(M-iM)),sy),speye(2^(iM-1)));
    szns{iM}=kron(kron(speye(2^(M-iM)),sz),speye(2^(iM-1)));
    spns{iM}=kron(kron(speye(2^(M-iM)),sp),speye(2^(iM-1)));
    smns{iM}=kron(kron(speye(2^(M-iM)),sm),speye(2^(iM-1)));
end

%% create transverse Ising Hamiltonians (choose one)

H=sparse(size(szns{1},1),size(szns{1},2));
% interaction term
for iM=1:M-1
    H=H+J*(sxns{iM}*sxns{iM+1}+syns{iM}*syns{iM+1}+szns{iM}*szns{iM+1});
end
if isPBC
    H=H+J*(sxns{1}*sxns{M}+syns{1}*syns{M}+szns{1}*szns{M});
end

% field term
for iM=1:M
    H=H+B*szns{iM}^2;
end

%% via imaginary time-evolution

% initial state
rho_ed=diag(ones(2^M,1));
% evolution operator
beta_op=expm(-beta.step*full(H)/2);

% evalueated variables
exp_z_ed =zeros(M,beta.n);
energy_ed=zeros(1,beta.n);
Z_ed     =zeros(1,beta.n);

for ibeta=1:beta.n
    tic;
    % evolution
    if ibeta>1
        rho_ed=beta_op*rho_ed*beta_op; % bera_op==beta_op'
    end
    % pick one way
    % 1. normalized
%     rho_ed=rho_ed/trace(rho_ed);
    % 2. non-normalizes
    Z_ed(ibeta)=trace(rho_ed);
    
    
    % evaluation
    for iM=1:M
        exp_z_ed(iM,ibeta)=trace(rho_ed*szns{iM})/Z_ed(ibeta);
    end
    energy_ed(ibeta)=trace(rho_ed*H)/Z_ed(ibeta);
    
    disp(['step #' num2str(ibeta,'%03i') '/' num2str(beta.n,'%03i') ...
        ' -- beta=' num2str(beta.vec(ibeta))...
        ' -- cpu time=' num2str(toc)])
end

% entropy
S_ed    =log(Z_ed    )+energy_ed    .*beta.vec;

%% via eig

exp_z_ed_eig =zeros(M,beta.n);
energy_ed_eig=zeros(1,beta.n);
Z_ed_eig     =zeros(1,beta.n);

[eVec,eVal]=eig(full(H));
eVal=diag(eVal);

for ibeta=1:beta.n
    tic;
    % density matrix
    P=exp(-beta.vec(ibeta)*(eVal-0*eVal(1))); % !!!
    Z_ed_eig(ibeta)=sum(P);        
    rho_ed_eig=eVec*diag(P)*eVec';
    rho_ed_eig=rho_ed_eig/Z_ed_eig(ibeta);
    
    % evaluation
    for iM=1:M
        exp_z_ed_eig(iM,ibeta)=trace(rho_ed_eig*szns{iM});
    end
    energy_ed_eig(ibeta)=trace(rho_ed_eig*H);
    
    disp(['step #' num2str(ibeta,'%03i') '/' num2str(beta.n,'%03i') ...
        ' -- beta=' num2str(beta.vec(ibeta))...
        ' -- cpu time=' num2str(toc)])
end

% entropy
S_ed_eig=log(Z_ed_eig)+energy_ed_eig.*beta.vec;

%% errors

% error of exp_z
figure
plot(beta.vec,max(abs(exp_z-exp_z_ed)),'k','LineWidth',2); hold all
plot(beta.vec,max(abs(exp_z-exp_z_ed_eig)),'--r','LineWidth',2);
title('Error between ED and T-MPS','FontSize',10)
xlabel('$\beta$','Interpreter','latex','FontSize',18)
ylabel('$\max_i(\langle \sigma_i^z \rangle_\mathrm{ED}-\langle \sigma_i^z \rangle_\mathrm{T-MPS})$',...
    'Interpreter','latex','FontSize',18)

% error of energy
figure
plot(beta.vec,abs((energy-energy_ed)./energy_ed),'k','LineWidth',2); hold all
plot(beta.vec,abs((energy-energy_ed_eig)./energy_ed_eig),'--r','LineWidth',2);
title('Error between ED and T-MPS','FontSize',10)
xlabel('$\beta$','Interpreter','latex','FontSize',18)
ylabel('$| E_\mathrm{ED}-E_\mathrm{T-MPS} | / |E_\mathrm{ED}|$','Interpreter','latex','FontSize',18)

% error of partition function
figure
plot(beta.vec,abs((Z_ed    -Z)./Z_ed    ),'k','LineWidth',2); hold all
plot(beta.vec,abs((Z_ed_eig-Z)./Z_ed_eig),'--r','LineWidth',2);
title('Error between ED and T-MPS','FontSize',10)
xlabel('$\beta$','Interpreter','latex','FontSize',18)
ylabel('$| Z_\mathrm{ED}-Z_\mathrm{T-MPS} | / |Z_\mathrm{ED}|$','Interpreter','latex','FontSize',18)

% error of entropy
figure
plot(beta.vec,abs((S_ed    -S)./S_ed    ),'k','LineWidth',2); hold all
plot(beta.vec,abs((S_ed_eig-S)./S_ed_eig),'--r','LineWidth',2);
title('Error between ED and T-MPS','FontSize',10)
xlabel('$\beta$','Interpreter','latex','FontSize',18)
ylabel('$| S_\mathrm{ED}-S_\mathrm{T-MPS} | / |S_\mathrm{ED}|$','Interpreter','latex','FontSize',18)












