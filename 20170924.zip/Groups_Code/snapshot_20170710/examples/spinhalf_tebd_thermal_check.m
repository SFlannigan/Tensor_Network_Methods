% Exact diagonalization calculation of the same problem as in
% spinhalf_tebd_thermal.m
%
% Run this script without changing anything 
%
% Note: don't run for large M

if M>10
    error('ERROR: system is too large for ED')
end

%% create operators

sxns=cell(M,1);
syns=cell(M,1);
szns=cell(M,1);
spns=cell(M,1);
smns=cell(M,1);
for iM=1:M
    sxns{iM}=kron(kron(speye(2^(M-iM)),sx),speye(2^(iM-1)));
    syns{iM}=kron(kron(speye(2^(M-iM)),sy),speye(2^(iM-1)));
    szns{iM}=kron(kron(speye(2^(M-iM)),sz),speye(2^(iM-1)));
    spns{iM}=kron(kron(speye(2^(M-iM)),sp),speye(2^(iM-1)));
    smns{iM}=kron(kron(speye(2^(M-iM)),sm),speye(2^(iM-1)));
end

%% create transverse Ising Hamiltonians (choose one)

H=sparse(size(szns{1},1),size(szns{1},2));
% interaction term
if is_long_range
    % long-range
    for i1=1:M-1
        for i2=i1+1:M
            H=H+J/(i2-i1)^alpha*sxns{i1}*sxns{i2};
        end
    end
else
    % or nearest neighbour
    for i1=1:M-1
        H=H+J*sxns{i1}*sxns{i1+1};
    end
end

% field term
for iM=1:M
    H=H+B*szns{iM};
end

%% via imaginary time-evolution

% initial state
rho_ed=diag(ones(2^M,1));
% evolution operator
beta_op=expm(-beta.step*full(H)/2);

% evalueated variables
exp_z_ed=zeros(M,beta.n);
energ_ed=zeros(1,beta.n);

for ibeta=1:beta.n
    tic;
    % evolution
    if ibeta>1
        rho_ed=beta_op*rho_ed*beta_op; % bera_op==beta_op'
    end
    rho_ed=rho_ed/trace(rho_ed);

    % evaluation
    for iM=1:M
        exp_z_ed(iM,ibeta)=trace(rho_ed*szns{iM});
    end
    energ_ed(ibeta)=trace(rho_ed*H);
    
    disp(['step #' num2str(ibeta,'%03i') '/' num2str(beta.n,'%03i') ...
        ' -- beta=' num2str(beta.vec(ibeta))...
        ' -- cpu time=' num2str(toc)])
end

%% via eig

exp_z_ed_eig=zeros(M,beta.n);
energ_ed_eig=zeros(1,beta.n);

[eVec,eVal]=eig(full(H));
eVal=diag(eVal);

for ibeta=1:beta.n
    tic;
    % density matrix
    Z=sum(exp(-beta.vec(ibeta)*(eVal-eVal(1))));        
    rho_ed_eig=eVec*diag(exp(-beta.vec(ibeta)*(eVal-eVal(1))))*eVec';
    rho_ed_eig=rho_ed_eig/Z;
    
    % evaluation
    for iM=1:M
        exp_z_ed_eig(iM,ibeta)=trace(rho_ed_eig*szns{iM});
    end
    energ_ed_eig(ibeta)=trace(rho_ed_eig*H);
    
    disp(['step #' num2str(ibeta,'%03i') '/' num2str(beta.n,'%03i') ...
        ' -- beta=' num2str(beta.vec(ibeta))...
        ' -- cpu time=' num2str(toc)])
end



%% absolute errors of correlation matrices

% error of exp_z
figure(1)
plot(beta.vec,max(abs(exp_z_pur-exp_z_ed)),'k','LineWidth',2); hold all
plot(beta.vec,max(abs(exp_z_pur-exp_z_ed_eig)),'--r','LineWidth',2);
title('Error between ED and T-MPS (w/ purification)')
xlabel('$\beta$','Interpreter','latex')
ylabel('$max(<\sigma_i^z>_{ED}-<\sigma_i^z>_{T-MPS})$','Interpreter','latex')

figure(2)
plot(beta.vec,max(abs(exp_z-exp_z_ed)),'k','LineWidth',2); hold all
plot(beta.vec,max(abs(exp_z-exp_z_ed_eig)),'--r','LineWidth',2);
title('Error between ED and T-MPS (w/o purification)')
xlabel('$\beta$','Interpreter','latex')
ylabel('$max(<\sigma_i^z>_{ED}-<\sigma_i^z>_{T-MPS})$','Interpreter','latex')

figure(3)
plot(beta.vec,max(abs(exp_z-exp_z_pur)),'k','LineWidth',2); hold all
title('Error between T-MPSes (w/ and w/o purification)')
xlabel('$\beta$','Interpreter','latex')
ylabel('$max(<\sigma_i^z>_{ED}-<\sigma_i^z>_{T-MPS})$','Interpreter','latex')
















