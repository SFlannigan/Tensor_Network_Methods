% Exact diagonalization calculation of the same problem as in
% spinhalf_tdvp.m or spinhalf_tebd.m
%
% Without changing anything run right after any of them to see relatives errors
%
% Note: don't run for large M

if M>11
    error('ERROR: system is too large for ED')
end

%% create operators

sxns = cell(M,1);
syns = cell(M,1);
szns = cell(M,1);
spns = cell(M,1);
smns = cell(M,1);
for iM = 1:M
    sxns{iM} = kron(kron(speye(2^(M-iM)),sx) , speye(2^(iM-1)));
    syns{iM} = kron(kron(speye(2^(M-iM)),sy) , speye(2^(iM-1)));
    szns{iM} = kron(kron(speye(2^(M-iM)),sz) , speye(2^(iM-1)));
    spns{iM} = kron(kron(speye(2^(M-iM)),sp) , speye(2^(iM-1)));
    smns{iM} = kron(kron(speye(2^(M-iM)),sm) , speye(2^(iM-1)));
end

%% create transverse Ising Hamiltonians (choose one)

H = 0;
% interaction term
if is_long_range
    % long-range
    for i1 = 1:M-1
        for i2 = i1+1:M
            H = H + J/(i2-i1)^alpha * sxns{i1}*sxns{i2};
        end
    end
else    
    % or nearest neighbour
    for i1 = 1:M-1
        H = H + J * sxns{i1}*sxns{i1+1};
    end
end

% field term
for iM = 1:M           
    H = H + B * szns{iM};
end

%% time-evolution

% initial state
psi=zeros(2^M,1);
psi(1)=1;
% time-evolution operator
time_op=expm(-1i*dt*H);

% evalueated variables
exp_z_exact=zeros(M,steps);
svn_exact=zeros(1,steps);         % von Neumann entropy

for tt=1:steps
    tic;
    % evaluation
    for iM=1:M
        exp_z_exact(iM,tt)=psi'*szns{iM}*psi;
    end
    
    tmp=reshape(psi,2^round(M/2),[]);
    tmp=tmp*tmp';
    tmp=svd(tmp);
    
    svn_exact(1,tt) = -tmp' * log( tmp + (tmp==0) );

    % time evolution
    psi=time_op*psi;
    
    disp(['step #' num2str(tt)...
        ' -- time=' num2str((tt-1)*dt)...
        ' -- cpu time=' num2str(toc)...
        ': svn=' num2str(svn_exact(1,tt))])
end

%% relative errors of correlation matrices

% local magnetization
plot(0:dt:t_max,max(abs((exp_z_exact - exp_z)./exp_z_exact)),'--k'); hold all
% Von Neumann entropy
plot(0:dt:t_max,abs((svn_exact - svn(round(M/2),:))./svn_exact),'--b')















