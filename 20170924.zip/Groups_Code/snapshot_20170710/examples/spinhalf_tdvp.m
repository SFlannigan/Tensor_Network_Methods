% Time-dependent variational principle time evolution of MPS
% 
% Ref: e.g. arxiv.org/abs/1408.5056

clear *

addpath('../kernel/');
addpath('../tools/');

%% parameters

paulis;                     % Pauli matrices
M=10;                       % number of spins
J=1;                        % interaction strength
is_long_range=0;            % 0 --- next-neighbour interractions
                            % 1 --- long-range interactions
B=1;                        % field strength
Dmax=64;                    % maximum bond dimension

dt=0.02;
t_max=2;
steps=t_max/dt+1;
order=2;

%% create transverse Ising Hamiltonians (choose one)

ham=mpo(M);
if is_long_range
    % long-range intereaction case
    alpha=4;                    % power law decay rate
    % create decomposition of interaction decay function into sum of exponentials
    relres_lim=1e-6;            % the smaller the better, but depends on the problem
    nroe_max=20;                % number of exponents
    dec_fun=1./(1:(M-1)).^alpha;
    exdec=sum_of_exponentials(dec_fun,nroe_max,relres_lim);
    ham=ham.set_n1sumaa_sumc_lr(sqrt(abs(J))*sx,B*sz,sign(J),exdec);
else
    % nearest neighbour interaction case
    ham=ham.set_sumab_sumc(J*sx,sx,B*sz);
end

%% create initial state

expv_opts.is_dyn_trunc=0;             % test parameter
if expv_opts.is_dyn_trunc
    % compare this
    state=mps(M,1);
    state=state.set_product_state([1;0]); % all spins up
    state=state.make_canonical(1);
    state=state.set_Dmax(Dmax);
else
    % vs this
    state=mps(M,Dmax);
    state=state.set_product_state([1;0]); % all spins up
    state=state.make_canonical(1);
end

%% tdvp sweeps

exp_z=zeros(M,steps);
svn=zeros(M-1,steps);         % von Neumann entropy

% time evolution parameters
expv_opts.tol=1e-5;
expv_opts.nkryl=20;
expv_opts.isclean=1;            % test parameter

for tt=1:steps
    tic;
    % evaluation
    exp_z(:,tt)=state.get_loc_expc(sz);
    
    lams=state.get_schmidt();
    for il=1:M-1
        tmp=lams{il}.^2;
        svn(il,tt) = -tmp' * log( tmp + (tmp==0) );
    end    
    
    [state,conv]=state.apply_tdvp_2s_trotter(ham,dt,expv_opts,order);
    
    disp(['step #' num2str(tt)...
        ' -- time=' num2str((tt-1)*dt)...
        ' -- cpu time=' num2str(toc)...
        ': svn=' num2str(svn(round(M/2)+1,tt))])
end

%% plotting

% bar3(exp_pm)



























