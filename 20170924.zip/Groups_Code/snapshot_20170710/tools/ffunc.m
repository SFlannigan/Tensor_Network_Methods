function f = ffunc(r, qax)

    for aaa=1:size(r,2)
        tr=r(:,aaa);
        nu=norm(tr);
        theta=acos((qax'*tr)/(norm(tr)));
        f(aaa)=1.5*( (sin(theta)^2*sin(nu)/nu) + (3*cos(theta)^2-1)*(sin(nu)/nu^3-cos(nu)/nu^2) );
        if nu==0
            f(aaa)=1;
        end
    end

end


