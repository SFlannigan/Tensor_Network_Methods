function exdec = sum_of_exponentials(varargin)
% Expand arbitraty decaying function as a sum of decaying exponents
%
% Used for getting exponents for long-range MPOs
    
    if nargin==2 % run decomposition for fixed nroe
        df=varargin{1};
        nroe=varargin{2};
        nroe_max=nroe;
    elseif nargin==3 % run decomposition for fixed max relative deviation in the function
        df=varargin{1};
        nroe_max=varargin{2};
        res_lim=varargin{3};
    else
        error(['Wrong number of inputs for sum_of_exponentials (2 or 3 allowed)'])
    end
    
    df=reshape(df,length(df),1);
    N=length(df);

    if nargin==3
        for nroe=1:nroe_max
            
            try
            
                F=zeros(N-nroe+1,nroe);
                for mm=1:size(F,1)
                    for nn=1:size(F,2)
                        F(mm,nn)=df(mm+nn-1);
                    end
                end
                
                [U,V]=qr(F,0);
                red=N-nroe;
                U1=U(1:red,1:nroe);
                U2=U((end-red+1):end,1:nroe);
                exdec.lambdas=eig(pinv(U1)*U2);
                
                C=repmat(exdec.lambdas',N,1);
                C=C.^repmat((0:N-1)',1,nroe);
                
                exdec.xs=lsqnonneg(C,df);
                exdec.res=abs(df-C*exdec.xs);
                %rel_res=exdec.res./df;
                
            catch
                display(['Warning: function is hard to approximate, desired precision not reached'])
                break
            end
            if max(exdec.res)<res_lim
                break
            end
        end
        
        display(['Maximum residual from true interaction decay function = ' num2str(max(exdec.res))])
        display(['nroe = ' num2str(nroe)])
        
        if nroe==nroe_max
            error('Inefficient decomposition... stopping')
        end
        
    end
    
    if nargin==2
        
        F=zeros(N-nroe+1,nroe);
        for mm=1:size(F,1)
            for nn=1:size(F,2)
                F(mm,nn)=df(mm+nn-1);
            end
        end
        
        [U V]=qr(F,0);
        red=N-nroe;
        U1=U(1:red,1:nroe);
        U2=U((end-red+1):end,1:nroe);
        exdec.lambdas=eig(pinv(U1)*U2);
        
        C=repmat(exdec.lambdas',N,1);
        C=C.^repmat((0:N-1)',1,nroe);
        
        exdec.xs=lsqnonneg(C,df);
        
        exdec.res=abs(df-C*exdec.xs);
    
    end
    
end