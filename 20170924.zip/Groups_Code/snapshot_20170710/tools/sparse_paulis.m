% pauli matrices

sx=sparse([0 1; 1 0]);
sy=sparse([0 -1i; 1i 0]);
sz=sparse([1 0; 0 -1]);
sm=sparse([0 0; 1 0]);
sp=sparse([0 1; 0 0]);
id=sparse([1 0; 0 1]);
