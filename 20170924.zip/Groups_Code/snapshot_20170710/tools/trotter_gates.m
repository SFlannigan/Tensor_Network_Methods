function gates= trotter_gates(mb_ham,alpha)
% Return vector of trotter gates
%
% NEED MORE DESRIPTION, especially how to input the Hamiltonian

M=length(mb_ham);
gates=cell(1,M);

for mm=1:M
    tmp=expm(alpha.*mb_ham{mm});
    if max(max(abs(imag(tmp))))<1e-14
        tmp=real(tmp);
    end
    d=sqrt((size(mb_ham{1},1)));
    tmp=reshape(tmp,[d d d d]);
    tmp=permute(tmp,[4 3 2 1]);
    tmp=reshape(tmp,[d*d d*d]);
    gates{mm}=tmp;
end