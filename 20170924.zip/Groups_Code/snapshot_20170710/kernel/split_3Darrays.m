function [matsout,trunc,mat_rem]=split_3Darrays(matin,sizes,Dmax,lrcan,nsout,zero_thres,is_dyn_trunc)
% Split 3D array (inverse of merge_3Darrays)
%
% Contraction scheme:
%
% FROM
%
%   +--------+  
%  2| ABC... |3 
%   +--------+  
%     111...
%
% TO
%
%   +---+    +---+    +---+
%  2| A |3  2| B |3  2| C |3  ...
%   +---+    +---+    +---+
%     1        1        1
%
% If lrcan==1, A,B,C,... are  left-canonical, i.e. sum A'*A==I (sweeping to right)
% if lrcan==0, A,B,C,... are right-canonical, i.e. sum A*A'==I (sweeping to left)
%
% nsout<=ns --- defines how many tensors we output
%
% mat_rem is what is left after canonization of the last tensor and should
% be transfered to the next tensor afterwards
%
% is_dyn_trunc is a test parameter and might be removed in the future
%
% NB: the last dimension might become as smaller as larger!!!

ns  =size(sizes,2);
dns =sizes(1,:);
DLns=sizes(2,:);
DRns=sizes(3,:);

matsout=cell(1,nsout);
trunc=zeros(1,nsout);
iconv=1;

matin=permute(matin,[2 1 3]);

if lrcan
    
    for ins=1:nsout
        % single out the ins-th tensor
        matin=reshape(matin,[DLns(1)*dns(1) prod(dns(2:end))*DRns(end)]); 
        % If Matlab changes prod([])==1, then the previous line
        % should be changed too!!!
        
        [L,lam,R]=svd(matin,'econ'); % !!! test it for matin's size 1xN and Nx1
        lam=diag(lam);
        R=R';
        
        if is_dyn_trunc
            cDmax=min(length(find(lam>zero_thres*max(lam))),Dmax);
        else
%             cDmax=min(DRns(1),Dmax);
            cDmax=min(max(DRns(1),length(find(lam>zero_thres*max(lam)))),Dmax); % test it
        end
        trunc(iconv)=sum(lam((cDmax+1):end).^2)/max(lam)^2;
        iconv=iconv+1;
        
        % save the ins-th tensor
        matsout{ins}=reshape(L(:,1:cDmax),[DLns(1) dns(1) cDmax]);
        matsout{ins}=permute(matsout{ins},[2 1 3]);
        
        % cut off used dimensions
        dns = dns(2:end);
        DLns=DLns(2:end);
        DRns=DRns(2:end);
        
        if ins<ns
            % next tensor might have a new dimension
            DLns(1)=cDmax; 
            matin=diag(lam(1:cDmax))*R(1:cDmax,:);
        else
            % in this case mat_rem is saved
            mat_rem=diag(lam(1:cDmax))*R(1:cDmax,:);
        end
    end
    
else
    
    for ins=ns:-1:(1+ns-nsout)
        % single out the ins-th tensor
        matin=reshape(matin,[DLns(1)*prod(dns(1:end-1)) dns(end)*DRns(end)]); 
        
        [L,lam,R]=svd(matin,'econ'); % !!! test it for matin's size 1xN and Nx1
        lam=diag(lam);
        R=R';
        
        if is_dyn_trunc
            cDmax=min(length(find(lam>zero_thres*max(lam))),Dmax);
        else
%             cDmax=min(DLns(end),Dmax);
            cDmax=min(max(DLns(end),length(find(lam>zero_thres*max(lam)))),Dmax); % test it
        end
        trunc(iconv)=sum(lam((cDmax+1):end).^2)/max(lam)^2;
        iconv=iconv+1;
        
        % save the ins-th tensor
        matsout{ins-ns+nsout}=reshape(R(1:cDmax,:),[cDmax dns(end) DRns(end)]);
        matsout{ins-ns+nsout}=permute(matsout{ins-ns+nsout},[2 1 3]);
        
        % cut off used dimensions
        dns = dns(1:end-1);
        DLns=DLns(1:end-1);
        DRns=DRns(1:end-1);
        
        if ins>1
            % next tensor might have a new dimension
            DRns(end)=cDmax; 
            matin=L(:,1:cDmax)*diag(lam(1:cDmax));
        else
            % in this case mat_rem is saved
            mat_rem=L(:,1:cDmax)*diag(lam(1:cDmax));
        end
    end
    
end

end