classdef mps
% Matrix Product State Class May 2015
%
% Ref: e.g. New J. Phys. 14 125015, chapter 2.1
%
% To do:
%     - group methods
%     - sort out helper functions names

    properties (SetAccess=public)
    end



    properties (SetAccess=protected)
        
        % Max allowed bond dimension
        Dmax        
        
        % Matrix data
        %
        % Cell array of M elements (for M sites). Each element is a 3D
        % array d x D_left x D_right.
        % d - loca dimension
        % D_left and D_right - row and column dimensions of local matrices,
        % which do not exceed Dmax.
        data
        
        % Indicates the bond index where canonization changes
        %
        % For M sites, 0<=qr<=M-1 for canonical forms:
        % If qr==0, all local matrices are right-canonical, i.e. sum A*A'==I,
        % if qr==M-1, all local matrices are left-canonical, i.e. sum A'*A==I,
        % if 0<qr<M-1, local matrices 
        %     from the 1-st to qr-th sites are left-canonical, 
        %     from the (qr+2)-th to (M-1)-th are right-canonical,
        %     and the (qr+1)-th matrix is not canonical.
        % If qr==-1, all matrices are not canonical.
        %
        % Ref: e.g. arxiv.org/abs/1008.3477, pp. 15-25
        qr          
        
        % Threshold of what is considered zero
        zero_thres
    
    end



    methods
       
        function mps=mps(M,Dmax)
        % Class constructor
        
            mps.Dmax=Dmax;
            mps.data=cell(1,M);
            mps.zero_thres=1e-14;
            mps.qr=-1;
            
        end
        
        
        
        
        
        function mps=set_product_state(mps,vec)
        % Set product state 
        %
        % If vec is a column it is used as a local state on each site,
        % if vec is a matrix its columns are used as local states.
        %
        % IMPORTANT: mps is not in a canonical form
            
            M=size(mps.data,2);            
            d=size(vec,1);
            
            if size(vec,2)==1
                vecmat=repmat(vec,1,M);
            elseif size(vec,2)==M
                vecmat=vec;
            else
                error('ERROR:set_state: vec must be a d column, or a dxM matrix.')
            end
            
            % calculation of bond dimensions
            Dmaxvec=ones(1,M+1);
            for iM=2:M
                if Dmaxvec(iM)==1
                    tmp=min(Dmaxvec(iM-1)*d,mps.Dmax);
                    Dmaxvec(iM)    =tmp;
                    Dmaxvec(M+2-iM)=tmp;
                else
                    break;
                end
            end
            
            % filling up local arrays
            for pp=1:M
                tmp_mat=zeros(d,Dmaxvec(pp),Dmaxvec(pp+1));
                tmp_mat(:,1,1)=vecmat(:,pp);
                %tmp_mat=single(tmp_mat);
                %tmp_mat=gpuArray(tmp_mat)
                %tmp_mat=SparseMat(tmp_mat);
                mps.data{pp}=tmp_mat;
            end
            mps.qr=-1;
            
        end
        
        
        
        
        
        function mps=set_sum_state(mps,vec,vac)
        % Set state of the form vec vac vac ... + vac vec vac ... + vac vac
        % vec ... + ... 
        %
        % If vec is a column it is used as a local state on each site,
        % if vec is a matrix its columns are used as local states.
        % vac is a column defining the "vacuum state"
        %
        % IMPORTANT: mps is not in a canonical form
            
            
            M=size(mps.data,2);   
            d=size(vec,1);
            
            if size(vec,2)==1
                vecmat=repmat(vec,1,M);
            elseif size(vec,2)==M;
                vecmat=vec;
            else
                error('ERROR:set_state: vec must be a d column, or a dxM matrix.')
            end
            
            % calculation of bond dimensions
            Dmaxvec=ones(1,M+1);
            for iM=2:M
                if Dmaxvec(iM)==1
                    tmp=min(Dmaxvec(iM-1)*d,mps.Dmax);
                    Dmaxvec(iM)    =tmp;
                    Dmaxvec(M+2-iM)=tmp;
                else
                    break;
                end
            end     
            
            % filling up local arrays
            mps.data{1}=zeros(d,Dmaxvec(1),Dmaxvec(2));
            mps.data{1}(:,1,1)=vecmat(:,1);
            mps.data{1}(:,1,2)=vac;
            
            for mm=2:M-1;
                mps.data{mm}=zeros(d,Dmaxvec(mm),Dmaxvec(mm+1));
                mps.data{mm}(:,1,1)=vac;
                mps.data{mm}(:,2,1)=vecmat(:,mm);
                mps.data{mm}(:,2,2)=vac;
            end
                
            mps.data{M}=zeros(d,Dmaxvec(M),Dmaxvec(M+1));
            mps.data{M}(:,1,1)=vac;
            mps.data{M}(:,2,1)=vecmat(:,M);
            
            mps.qr=-1;
            
        end
        
        
        
        
        
        function mps=set_random_state(mps,d,isreal)
        % Set random state 
        %
        % IMPORTANT: mps is not in a canonical form
            
            M=size(mps.data,2);
            
            % calculation of bond dimensions
            Dmaxvec=ones(1,M+1);
            for iM=2:M
                if Dmaxvec(iM)==1
                    tmp=min(Dmaxvec(iM-1)*d,mps.Dmax);
                    Dmaxvec(iM)    =tmp;
                    Dmaxvec(M+2-iM)=tmp;
                else
                    break;
                end
            end       
            
            % filling up local arrays
            for pp=1:M
                if isreal
                    mps.data{pp}=rand(d,Dmaxvec(pp),Dmaxvec(pp+1));
                else
                    mps.data{pp}=rand(d,Dmaxvec(pp),Dmaxvec(pp+1))...
                        + 1i*rand(d,Dmaxvec(pp),Dmaxvec(pp+1));
                end
            end
            mps.qr=-1;
            
        end
        
        
        
        
        
        function mps=set_data(mps,data,isites)
        % Set any MPS manually
        %
        % It's used for testing.
        %
        % There are 2 ways to use this function:
        % 1. nargin==2: data is a cell(1,M), which replaces mps.data
        % 2. nargin==3: data is a 4D array, which replaces mps.data{isites}
        %
        % Note: isites can be a vector
            
            if nargin==2
                if and(iscell(data),size(data,2)==length(mps.data))
                    mps.data=data;
                else
                    error('ERROR: wrong input')
                end
            elseif nargin==3
                for is=isites
                    mps.data{is}=data;
                end
            else
                error('ERROR: wrong input')
            end
            
        end  
        
        
        
        
        
        function mps=set_Dmax(mps,Dmax_new)
        % Set Dmax manually
            
            mps.Dmax=Dmax_new;
            
        end  
        
        
        
        
        
        function mps=convert_mpo2mps(mps,mpo)
        % Conver MPO to MPS
        %
        % Combine local dimentions d_out and d_in of MPO into dd and save the object
        % as MPS with tensor dimensions d_out*d_in x D_left x D_right
        %
        % Comment: maybe make it more general to define the order of
        % combined local dimensions
            
            if length(mps.data)~=length(mpo.data)
                error('wrong object size')
            end
            
            for iM=1:length(mpo.data)
                [d_out,d_in,DL,DR]=size(mpo.data{iM});
                mps.data{iM}=reshape(mpo.data{iM},[d_out*d_in DL DR]);
            end
            
            mps.qr=-1;
            
        end
        
        
        
        
        
        function mps=make_bond_dim_to_max(mps)
        % Increase bond dimensions to maximum
        %
        % It is useful in the case of TDVP to increase bond dimensions 
        % beforehand, as it increases the precision.
            
            M=size(mps.data,2);
            d=size(mps.data{1},1);
            
            Dmaxvec=ones(1,M+1);
            for iM=2:M
                if Dmaxvec(iM)==1
                    tmp=min(Dmaxvec(iM-1)*d,mps.Dmax);
                    Dmaxvec(iM)    =tmp;
                    Dmaxvec(M+2-iM)=tmp;
                else
                    break;
                end
            end
            
            for iM=1:M
                tmp_mat=zeros(d,Dmaxvec(iM),Dmaxvec(iM+1));
                tmp_mat(:,1:size(mps.data{iM},2),1:size(mps.data{iM},3))=...
                    mps.data{iM};
                mps.data{iM}=tmp_mat;
            end
            
        end
        
        
        
        
        
        function vec=get_mps_in_standard_basis(mps)
        % Return vector in standard basis equivalent of MPS 
        % 
        % IMPORTANT: don't use for large systems
        
            M=size(mps.data,2);
            d=size(mps.data{1},1);
        
            if d^M > 2^12
                error('WARNING:get_mps_in_standart_basis: too many calculations');
            end
            
            vec = zeros(d^M,1);

            for ii = 1:d^M
                str = dec2base(ii-1, d, M);
                vecElement = 1;
                for iM = 1:M
                    locIndex = str2double(str(1)) + 1;
                    str(1) = [];
                    vecElement = vecElement*permute(mps.data{iM}(locIndex,:,:),[2 3 1]);
                end
                vec(ii) = vecElement;   
            end            
            
        end
        
        
        
        
        
        function vals=get_schmidt(mps)
        % Return Schmidt coefficients
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            M=length(mps.data);
            vals=cell(M-1,1);
            
            for mm=1:(M-1)
                [mps,vals{mm}]=mps.shift_qr(1);
            end
        
        end
        
        
        
        
        
        function nrm=get_norm(mps)
        % Return norm of state
            
            M=length(mps.data);
            edg2=ones(1,1);
            for mm=M:-1:1
                edg2=add_to_right_edge2_AB(edg2,mps.data{mm});
            end
            nrm=sqrt(edg2);
            
        end
        
        
        
        
        
        function nrm=get_overlap(mps,mps2)
        % Return <mps2|mps>
            
            M=length(mps.data);
            
            if length(mps2.data)~=M
                error('ERROR: MPSes have different length')
            end
            
            edg2=ones(1,1);
            for mm=M:-1:1
                edg2=add_to_right_edge2_AB(edg2,mps.data{mm},conj(mps2.data{mm}));
            end
            nrm=sqrt(edg2);
            
        end   
        
        
        
        
        
        function corr=get_corr_mat_herm(mps,op1,op2)
        % Return Hermitian correlation matrix
        %
        % Explicitly: corr_ij == < mps |op1_i op2_j | mps >
        %
        % Requirement: op1==op2'
        
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            if max(max(abs(op1-op2')))~=0
                error('ERROR:get_corr_mat_herm: op1~=op2''');
            end
        
            M=size(mps.data,2);
            corr=diag(mps.get_loc_expc(op1*op2))/2;
            
            for mm=2:M
                corr(1:(mm-1),mm)=mps.get_corr_col_part(op1,op2,mm);
            end
            
            corr=corr+corr';
            
        end
        
        
        
        
        
        function corr=get_corr_mat(mps,op1,op2)
        % Return correlation matrix
        %
        % Explicitly: corr_ij == < mps |op1_i op2_j | mps >
        %
        % Note: slower than get_corr_mat_herm(), but more general.
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            M=size(mps.data,2);
            corr=zeros(M,M);
            
            for mm=1:M
                corr(:,mm)=mps.get_corr_col(op1,op2,mm);
            end
            
        end
        
        
        
        
        
        function expc=get_corr_col_part(mps,op1,op2,op2idx)
        % Return corelation matrix column (part over the diagonal)
        %
        % Explicitly: expc_i == < mps |op1_i op2_op2idx | mps >,
        % for 1 <= i < op2idx
        %
        % This function is used by get_corr_mat_herm()
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            expc=zeros(op2idx-1,1);
            mm=op2idx;
            
            for nn=1:mm-1
                mps=mps.shift_qr(1);
            end
            
            [d,DL,DR]=size(mps.data{mm});
            tmp1=reshape(mps.data{mm},[d DL*DR]);
            tmp1=reshape(op2*tmp1,[d DL DR]);
            
            edg=eye(DR);
            edg=add_to_right_edge2_AB(edg,tmp1,conj(mps.data{mm}));
            
            for mm=(op2idx-1):-1:1

                [d,DL,DR]=size(mps.data{mm});
                tmp1=reshape(mps.data{mm},[d DL*DR]);
                tmp1=reshape(op1*tmp1,[d DL DR]);
                
                eval_edg=add_to_right_edge2_AB(edg,tmp1,conj(mps.data{mm}));
                expc(mm)=trace(eval_edg);
                
                edg=add_to_right_edge2_AB(edg,mps.data{mm});
                
            end
            
            if max(abs(imag(expc)))<mps.zero_thres*max(abs(real(expc)))
                expc=real(expc);
            end
                
        end
        
        
        
        
        
        function expc=get_corr_col(mps,op1,op2,op2idx)
        % Return corelation matrix column
        %
        % Explicitly: expc_i == < mps |op1_i op2_op2idx | mps >,
        % for 1 <= i <= M
        %
        % This function is used by get_corr_mat()
            
            M=size(mps.data,2);
            expc=zeros(M,1);
            
            op2_mps=mps.apply_loc(op2,op2idx);

            edg{M+1}=1;
            for mm=M:-1:2
                edg{mm}=add_to_right_edge2_AB(edg{mm+1},op2_mps.data{mm},conj(mps.data{mm}));
            end
            edg{1}=1;
            
            for mm=1:M
                [d,DL,DR]=size(mps.data{mm});
                tmp=reshape(op2_mps.data{mm}, [d  DL*DR]);
                tmp=op1*tmp;
                tmp=reshape(tmp, [d DL DR]);
                expc(mm)=edge2_sandwich_AB(edg{mm},edg{mm+1},tmp,conj(mps.data{mm}));
                edg{mm+1}=add_to_left_edge2_AB(edg{mm},op2_mps.data{mm},conj(mps.data{mm}));
            end
            
            if max(abs(imag(expc)))<mps.zero_thres*max(abs(real(expc)))
                expc=real(expc);
            end
            
        end
        
        
        
        
        
        function expc=get_loc_expc(mps,locop)
        % Return vector of local expectation values
        %
        % If locop is a single dxd operator, it is used on each site, 
        % if locop is a dxdxM array, its matrices are used on local sites. 
            
            M=size(mps.data,2);
            expc=zeros(M,1);
            
            if size(locop,3)==1
                locten=repmat(locop,1,1,M);
            elseif size(locop,3)==M;
                locten=locop;
            else
                error('ERROR:loc_expc: locop must be dxd matrix or dxdxM array')
            end
            
            if mps.qr==0
            
                for mm=1:M
                    [d,DL,DR]=size(mps.data{mm});
                    tmp=reshape(mps.data{mm},d, DL*DR);
                    tmp=tmp*tmp';
                    expc(mm)=trace(locten(:,:,mm)*tmp); 
                    if mm<M
                        mps=mps.shift_qr(1);
                    end
                end
                
            elseif mps.qr==M-1
                
                for mm=M:-1:1
                    [d,DL,DR]=size(mps.data{mm});
                    tmp=reshape(mps.data{mm},d, DL*DR);
                    tmp=tmp*tmp';
                    expc(mm)=trace(locten(:,:,mm)*tmp); 
                    if mm>1
                        mps=mps.shift_qr(0);
                    end
                end
                
            else
                error('ERROR: function works only for mps.qr==0 or M-1');
            end
            
            if max(abs(imag(expc)))<mps.zero_thres*max(abs(real(expc)))
                expc=real(expc);
            end
                
        end
        
        
        
        
        
        function sizes=get_data_sizes(mps)
        % Return sizes of data cells

            MVec=1:length(mps.data);
            sizes=zeros(length(mps.data),3);
            
            for iM=MVec
                [a,b,c]=size(mps.data{iM});
                sizes(iM,:)=[a,b,c];
            end

        end
        
        
        
        
        
        function mps=apply_loc(mps,locop,pos)
        % Apply local operator    
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end            
            
            for mm=1:(pos-1)
                mps=mps.shift_qr(1);
            end
            
            [d,DL,DR]=size(mps.data{pos});
            tmp=reshape(mps.data{pos},d, DL*DR);
            mps.data{pos}=reshape(locop*tmp,d,DL,DR);
            
            for mm=(pos-1):-1:1
                mps=mps.shift_qr(0);
            end
            
        end
        
        
        
        
        
        function [o2sweep,gate_order]=create_trotter2_nn_sweep(mps)
        % Create nearest-neighbor sweep for the 2nd order Trotter decomposition 
        %
        % Nearest-neighbor means that only neighbouring sites interact with
        % each other. See apply_tebd_sweep function. 
        % It also returns the requested gate order.
        %
        % Note: Application of gates goes from the right edge to the left and
        % back. qr scheme is untouched, but it's assumed that that state 
        % was in  the right canonical state, i.e. qr==0
            
            M=length(mps.data);
            
            pos=1;
            gpos=1;
            for ii=M-1:-1:1
                L{pos}=[1; gpos; ii; 0]; 
                gate_order(gpos,1)=ii;
                gate_order(gpos,2)=ii+1;
                pos=pos+1;
                gpos=gpos+1;
            end
            
            R=fliplr(L);
            for ss=1:length(R)
                R{ss}(4)=1;
            end
            
            o2sweep=[R L];
            
        end
        
        
        
        
        
        function [o4sweep,gate_order]=create_trotter4_nn_sweep(mps)
        % Create nearest-neighbor sweep for the 4th order Trotter decomposition 
        %
        % Nearest-neighbor means that only neighbouring sites interact with
        % each other. See apply_tebd_sweep function. 
        % It also returns the requested gate order.
            
            M=length(mps.data);
            
            pos=1;
            gpos=1;
            for ii=M-1:-1:1
                L{pos}=[1; gpos; ii; 0]; 
                gate_order(gpos,1)=ii;
                gate_order(gpos,2)=ii+1;
                pos=pos+1;
                gpos=gpos+1;
            end

            pos=1;
            gpos=1;
            for ii=M-1:-1:1
                Lp{pos}=[2; gpos; ii; 0]; 
                pos=pos+1;
                gpos=gpos+1;
            end

            
            
            R=fliplr(L);
            for ss=1:length(R)
                R{ss}(4)=1;
            end

            Rp=fliplr(Lp);
            for ss=1:length(Rp)
                Rp{ss}(4)=1;
            end

            pos=1;
            for ii=M-1:-1:1
                OL{pos}=[0; 0; ii; 0];
                pos=pos+1;
            end

            pos=1;
            for ii=1:M-1
                OR{pos}=[0; 0; ii; 1];
                pos=pos+1;
            end
            
            o4sweep=([R L R Lp R OL R OL R OL R L R L OR L OR L OR L Rp L R L]);
            
            
        end
        
        
        
        
        
        function [o2sweep,gate_order]=create_trotter2_lr_sweep(mps)
        % Create long-range sweep for the 2nd order Trotter decomposition 
        %
        % Long-range means that every site interacts with every site. 
        % See apply_tebd_sweep function. It also returns the requested gate order
        %
        % DOUBLE CHECK BEFORE USING
            
            M=length(mps.data);
            
            pos=1;
            gpos=1;
            for jj=M:-1:2
                for ii=(jj-1):-1:2
                    R{pos}=[1; gpos; ii; 0]; 
                    gate_order(gpos,1)=ii;
                    gate_order(gpos,2)=jj;
                    pos=pos+1;
                    gpos=gpos+1;
                    R{pos}=[-1; 0; ii; 0]; 
                    pos=pos+1;
                end
                ii=1;
                R{pos}=[1; gpos; ii; 1];
                gate_order(gpos,1)=ii;
                gate_order(gpos,2)=jj;
                gpos=gpos+1;
                pos=pos+1;
                if jj>2
                    for ii=2:(jj-2)
                        R{pos}=[-1; 0; ii; 1]; 
                        pos=pos+1;            
                    end
                    ii=(jj-1);
                    R{pos}=[-1; 0; ii; 0];
                    pos=pos+1;          
                end
            end
            
            
            L=fliplr(R);
            for ss=1:length(L)
                if L{ss}(4)==0
                    L{ss}(4)=1;
                else
                    L{ss}(4)=0;
                end
            end
            
            o2sweep=[L R];
            
        end
        
        
        
        
        
        function [o4sweep,gate_order]=create_trotter4_lr_sweep(mps)
        % Create long-range sweep for the 4th order Trotter decomposition 
        %
        % Long-range means that every site interacts with every site. 
        % See apply_tebd_sweep function. It also returns the requested gate order
        %
        % DOUBLE CHECK BEFORE USING
            
            M=length(mps.data);
            
            pos=1;
            gpos=1;
            for jj=M:-1:2
                for ii=(jj-1):-1:2
                    R{pos}=[1; gpos; ii; 0]; 
                    gate_order(gpos,1)=ii;
                    gate_order(gpos,2)=jj;
                    pos=pos+1;
                    gpos=gpos+1;
                    R{pos}=[-1; 0; ii; 0]; 
                    pos=pos+1;
                end
                ii=1;
                R{pos}=[1; gpos; ii; 1];
                gate_order(gpos,1)=ii;
                gate_order(gpos,2)=jj;
                gpos=gpos+1;
                pos=pos+1;
                if jj>2
                    for ii=2:(jj-2)
                        R{pos}=[-1; 0; ii; 1]; 
                        pos=pos+1;            
                    end
                    ii=(jj-1);
                    R{pos}=[-1; 0; ii; 0];
                    pos=pos+1;          
                end
            end

            
            pos=1;
            gpos=1;
            for jj=M:-1:2
                for ii=(jj-1):-1:2
                    Rp{pos}=[2; gpos; ii; 0]; 
                    pos=pos+1;
                    gpos=gpos+1;
                    Rp{pos}=[-1; 0; ii; 0]; 
                    pos=pos+1;
                end
                ii=1;
                Rp{pos}=[2; gpos; ii; 1];
                gpos=gpos+1;
                pos=pos+1;
                if jj>2
                    for ii=2:(jj-2)
                        Rp{pos}=[-1; 0; ii; 1]; 
                        pos=pos+1;            
                    end
                    ii=(jj-1);
                    Rp{pos}=[-1; 0; ii; 0];
                    pos=pos+1;          
                end
            end
                        
            pos=1;
            for ii=M-1:-1:1
                O{pos}=[0; 0; ii; 0];
                pos=pos+1;
            end

            pos=1;
            for ii=1:M-1
                Op{pos}=[0; 0; ii; 1];
                pos=pos+1;
            end
            
            
            L=fliplr(R);
            for ss=1:length(L)
                if L{ss}(4)==0
                    L{ss}(4)=1;
                else
                    L{ss}(4)=0;
                end
            end

            Lp=fliplr(Rp);
            for ss=1:length(Lp)
                if Lp{ss}(4)==0
                    Lp{ss}(4)=1;
                else
                    Lp{ss}(4)=0;
                end
            end

            o4sweep=fliplr([ R L R Lp R Op R Op R Op R L R L O L O L O L Rp L R L]);

            
            
        end
        
        
        
        
                
        function [mps,trunc]=apply_tebd_sweep(mps,gates,sweep,nrm,isclean,is_dyn_trunc)
        % Perform TEBD sweep 
        %
        % Serial application of two-site gates. Functions to define sweeps 
        % are in this class. "sweep" is a cell array, where each cell 
        % contains a vector. The key to  the values is:
        %    
        % sweep{ss}(1): -1 -> apply a swap gate, 0 -> apply an identity, 1+ -> apply the gate series with gtclass=1+
        % sweep{ss}(2): gtnr, the gatenumber that should be applied, i.e. use gates{gtclass,gtnr}
        % sweep{ss}(3): ii, the site where the gate is applied
        % sweep{ss}(4): lr, determines whether the Schmidt values are multiplied to the left or right matrix (0 or 1)
            
            dd=size(mps.data{1},1)^2;
            
            for ss=1:length(sweep)
                
                if sweep{ss}(1)==-1
                    ii=sweep{ss}(3);
                    lr=sweep{ss}(4);
                    [mps,trunc(ss)]=mps.swap(ii,lr,isclean,is_dyn_trunc);
                end

                if sweep{ss}(1)==0
                    ii=sweep{ss}(3);
                    lr=sweep{ss}(4);
                    [mps,trunc(ss)]=mps.apply_loc_2s(eye(dd,dd),ii,lr,nrm,isclean,is_dyn_trunc);
                end
                
                if sweep{ss}(1)>0
                    gtclass=sweep{ss}(1);
                    gtnr=sweep{ss}(2);
                    ii=sweep{ss}(3);
                    lr=sweep{ss}(4);
                    [mps,trunc(ss)]=mps.apply_loc_2s(gates{gtclass,gtnr},ii,lr,nrm,isclean,is_dyn_trunc); 
                end
                
            end
            
        end
        
        
        
        
        
        function mps=make_canonical(mps,is_qr0,is_norm)
        % Converte state to a canonical form using qr 
        %
        % If is_qr0==1, make the input mps right-canonical,
        % if is_qr0==0, make teh input mps  left-canonical.
        %
        % If is_norm==1 (by default), normilize the input mps as well.
            
            if nargin<3
                is_norm=1;
            end
            
            M=length(mps.data);
            
            if is_qr0==1 % right-canonization
                
                mps.qr=M-1;
                for mm=1:M-1
                    [mps,~]=mps.shift_qr(0);
                end
                
                if is_norm
                    d=size(mps.data{1},1);
                    norm=0;
                    for id=1:d
                        tmp = permute(mps.data{1}(id,:,:),[2 3 1]);
                        norm = norm + tmp*tmp';
                    end
                    mps.data{1} = mps.data{1}/sqrt(norm);
                end
                
            elseif is_qr0==0 % left-canonization
                
                mps.qr=0;
                for mm=1:M-1
                    [mps,~]=mps.shift_qr(1);
                end
                
                if is_norm
                    d=size(mps.data{M},1);
                    norm=0;
                    for id=1:d
                        tmp = permute(mps.data{M}(id,:,:),[2 3 1]);
                        norm = norm + tmp'*tmp;
                    end
                    mps.data{M} = mps.data{M}/sqrt(norm);
                end
            else
                error('ERROR:make_canonical: wrong canonization type request')
            end
            
        end
        
        
        
        
        
        function mps=clean(mps)
        % Remove values smaller than the zero threshold 
        %
        % This can speed up calculations or save memory in certain cases.
            
            M=length(mps.data);
            
            for mm=1:M
                % in case if MPS is not normalized
                max_of_tensor=max(max(max(abs(mps.data{mm}))));
                mps.data{mm}(abs(mps.data{mm})<mps.zero_thres*max_of_tensor)=0;
            end
            
        end
        
        
        
        
        
        function [mps,conv]=apply_mpo_2s_sweep(mps,varargin)
        % Find psi to minimize K = || |psi> - Y |phi> ||^2 -> 0
        %
        % This function uses a two site update.
        %
        % Ref: http://iopscience.iop.org/1367-2630/8/12/305

            if nargin==2
                mpoY=varargin{1};
                conv_parms.Ktol=1e-10;
                conv_parms.maxsweeps=10;
                eta_given=0;
            elseif nargin==4
                mpoY=varargin{1};
                conv_parms.Ktol=varargin{2};
                conv_parms.maxsweeps=varargin{3};
                eta_given=0;
            elseif nargin==5
                mpoY=varargin{1};
                conv_parms.Ktol=varargin{2};
                conv_parms.maxsweeps=varargin{3};
                eta_given=varargin{4};
            elseif nargin==6
                mpoY=varargin{1};
                conv_parms.Ktol=varargin{2};
                conv_parms.maxsweeps=varargin{3};
                eta_given=varargin{4};
                phi=varargin{5}; % phi~=psi
            else
                error(['Wrong number of input arguments to apply_mpo_2s_sweep']);
            end
            
            if nargin<6
                phi=mps; % phi = old mps
            end
            
            M=size(mps.data,2);
            
            % eta=<phi| mpoY' mpoY |phi>
            if ~eta_given
                tmp=mpoY.get_herm_conj();
                tmp=tmp.mult(mpoY);
                eta=phi.get_mpo_expc(tmp);
                conv.eta=eta;
            else
                eta=eta_given;
            end
            
            % precalculate fixed neighboring site tensors
            dblmpoY = cell(1,M-1);
            dblphi  = cell(1,M-1);
            for mm=1:(M-1) 
                
                % sizes 
                [mlsz1,mlsz2,mlsz3] = size(phi.data{mm}); % phi~=mps
                [mrsz1,mrsz2,mrsz3] = size(phi.data{mm+1}); 
                
                [ylsz1,ylsz2,ylsz3,ylsz4] = size(mpoY.data{mm}); 
                [yrsz1,yrsz2,yrsz3,yrsz4] = size(mpoY.data{mm+1}); 
                
                % !!! REWRITE VIA AB=merge_3Darrays(A,B)
                % Contract 2 neighboring mpoY tensors
                tmpL = reshape(mpoY.data{mm},[ylsz1*ylsz2*ylsz3 ylsz4]);
                tmpR = permute(mpoY.data{mm+1},[3 1 2 4]);
                tmpR = reshape(tmpR,[yrsz3 yrsz1*yrsz2*yrsz4]);
                dblmpoY{mm} = reshape(tmpL*tmpR, [ylsz1 ylsz2 ylsz3 yrsz1 yrsz2 yrsz4]);
                dblmpoY{mm} = permute(dblmpoY{mm}, [1 4 2 5 3 6]);
                dblmpoY{mm} = reshape(dblmpoY{mm}, [ylsz1*yrsz1 ylsz2*yrsz2 ylsz3 yrsz4]);

                % Contract 2 neighboring phi tensors
                tmpL = reshape(phi.data{mm},[mlsz1*mlsz2 mlsz3]);
                tmpR = permute(phi.data{mm+1},[2 1 3]);
                tmpR = reshape(tmpR,[mrsz2 mrsz1*mrsz3]);
                dblphi{mm} = reshape(tmpL*tmpR, [mlsz1 mlsz2 mrsz1 mrsz3]);
                dblphi{mm} = permute(dblphi{mm}, [1 3 2 4]);
                dblphi{mm} = reshape(dblphi{mm}, [mlsz1*mrsz1 mlsz2 mrsz3]);
                
            end
            
            % phi_psi_edg: <phi| mpoY |psi> 
            phi_psi_edg{M+1}=ones(1,1,1);
            psi_psi_edg{M+1}=ones(1,1);
            for mm=M:-1:3
                gue=mps.data{mm}; % use previous matrix as guess;
                phi_psi_edg{mm}=add_to_right_edge3_AB(phi_psi_edg{mm+1},...
                    phi.data{mm},mpoY.data{mm},conj(gue));
                psi_psi_edg{mm}=add_to_right_edge2_AB(psi_psi_edg{mm+1},gue);
            end
            phi_psi_edg{1}=ones(1,1,1);
            psi_psi_edg{1}=ones(1,1);

            convpos=1;    
            for ss=1:conv_parms.maxsweeps
                
                for mm=1:(M-1) % sweep right

                    v=edge3_contract_AB(phi_psi_edg{mm},phi_psi_edg{mm+2},...
                        dblmpoY{mm},dblphi{mm});
                    %v(abs(v)<mps.zero_thres*max(abs(v)))=0;
                    
                    % old idea
                    %[mpssz(1) mpssz(2) mpssz(3)] = size(v);
                    %QXXH = @(mps_vec_in,transp) (edge2_contract_vec(psi_psi_edg{mm}, psi_psi_edg{mm+2}, mpssz , mps_vec_in));
                    %v=reshape(v,[prod(mpssz) 1]);
                    %[Ax conv.gmres_flag(convpos) conv.gmres_relres(convpos)]=gmres(QXXH,v,rest,conv_parms.gmres_tol);
                    %[Ax flag relres] = minres(QXXH,v,1e-8,10000);
                    %Ax=v;
                    %v=reshape(Ax,mpssz);
                    
                    [dl,Dl,~ ]=size(mps.data{mm});
                    [dr,Dm,Dr]=size(mps.data{mm+1});
                    
                    v=reshape(v,[dr dl Dl Dr]);
                    v=permute(v,[1 3 2 4]);
                    v=reshape(v,[dl*Dl dr*Dr]);

                    [L,lam,R]=svd(v,'econ');
                    lam=diag(lam);
                    R=R';
                    
                    % !!! add compression-flag here
                    cDmax=min(length(find(lam>mps.zero_thres*max(lam))),mps.Dmax);
%                     cDmax=min(size(mps.data{mm},3),mps.Dmax);
                    conv.trunc(convpos)=sum(lam((cDmax+1):end).^2)/max(lam)^2;
                    
                    % error estimate after truncation
                    veff=L(:,1:cDmax)*diag(lam(1:cDmax))*R(1:cDmax,:);
                    veff=reshape(veff, [dl Dl dr Dr]);
                    veff=permute(veff, [1 3 2 4]);
                    veff=reshape(veff, [dl*dr Dl Dr]);
                    
                    qxx=edge2_sandwich_AB(psi_psi_edg{mm},psi_psi_edg{mm+2},veff);
                    qxy=edge3_sandwich_AB(phi_psi_edg{mm},phi_psi_edg{mm+2},...
                        dblphi{mm},dblmpoY{mm},conj(veff));
                    conv.Ks(convpos)=qxx-2*real(qxy)+eta;
                    convpos=convpos+1;
                    
                    % always: update left tensor
                    L=L(:,1:cDmax);%*diag(lam(1:cDmax));
                    L=reshape(L,[dl Dl cDmax]);
                    
                    % update left side
                    mps.data{mm}=L;
                                        
                    if cDmax<Dm
                        % middle bond dimension becomes smaller
                        mps.data{mm+1}=mps.data{mm+1}(:,1:cDmax,:);
                    elseif cDmax>Dm 
                        % middle bond dimension becomes larger
                        % !!! lame way
                        tmp=zeros(dr,cDmax,Dr);
                        tmp(:,1:Dm,:)=mps.data{mm+1};
                        mps.data{mm+1}=tmp;
                    end
                    
                    % create new left edges
                    phi_psi_edg{mm+1}=add_to_left_edge3_AB(phi_psi_edg{mm},...
                        phi.data{mm},mpoY.data{mm},conj(mps.data{mm}));
                    psi_psi_edg{mm+1}=add_to_left_edge2_AB(psi_psi_edg{mm},mps.data{mm});
                    
                    % the right edge site will be updated in the reversed sweep
                    
                end
                
                for mm=M-1:-1:1 % sweep left
                    
                    v=edge3_contract_AB(phi_psi_edg{mm},phi_psi_edg{mm+2},...
                        dblmpoY{mm},dblphi{mm});
                    %v(abs(v)<mps.zero_thres*max(abs(v)))=0;
                    
                    [dl,Dl,Dm]=size(mps.data{mm});
                    [dr,~ ,Dr]=size(mps.data{mm+1});
                    
                    v=reshape(v,[dr dl Dl Dr]);
                    v=permute(v,[1 3 2 4]);
                    v=reshape(v,[dl*Dl dr*Dr]);

                    [L,lam,R]=svd(v,'econ');
                    lam=diag(lam);
                    R=R';
                    
                    cDmax=min(length(find(lam>mps.zero_thres*max(lam))),mps.Dmax);
%                     cDmax=min(size(mps.data{mm},3),mps.Dmax);
                    conv.trunc(convpos)=sum(lam((cDmax+1):end).^2)/max(lam)^2;
                    
                    % error estimate after truncation
                    veff=L(:,1:cDmax)*diag(lam(1:cDmax))*R(1:cDmax,:);
                    veff=reshape(veff, [dl Dl dr Dr]);
                    veff=permute(veff, [1 3 2 4]);
                    veff=reshape(veff, [dl*dr Dl Dr]);
                    
                    qxx=edge2_sandwich_AB(psi_psi_edg{mm},psi_psi_edg{mm+2},veff);
                    qxy=edge3_sandwich_AB(phi_psi_edg{mm},phi_psi_edg{mm+2},dblphi{mm},dblmpoY{mm},conj(veff));
                    conv.Ks(convpos)=qxx-2*real(qxy)+eta;
                    convpos=convpos+1;
                    
                    if mm>1 % usually update right side

                        %R=diag(lam(1:cDmax))*R(1:cDmax,:);
                        R=R(1:cDmax,:);
                        R=reshape(R,[cDmax dr Dr]);
                        R=permute(R,[2 1 3]);
                        mps.data{mm+1}=R;
                        
                        if cDmax<Dm
                            % middle bond dimension becomes smaller
                            mps.data{mm}=mps.data{mm}(:,:,1:cDmax);
                        elseif cDmax>Dm 
                            % middle bond dimension becomes larger
                            % !!! lame way
                            tmp=zeros(dl,Dl,cDmax);
                            tmp(:,:,1:Dm)=mps.data{mm};
                            mps.data{mm}=tmp;
                        end                        
                        
                        % create new right edge 
                        phi_psi_edg{mm+1}=add_to_right_edge3_AB(phi_psi_edg{mm+2},...
                            phi.data{mm+1},mpoY.data{mm+1},conj(mps.data{mm+1}));
                        psi_psi_edg{mm+1}=add_to_right_edge2_AB(psi_psi_edg{mm+2},mps.data{mm+1});
                        
                    else % update both (put lambda in left matrix)
                        
                        L=L(:,1:cDmax)*diag(lam(1:cDmax));
                        L=reshape(L,[dl Dl cDmax]);
                        mps.data{mm}=L;
                        
                        R=R(1:cDmax,:);
                        R=reshape(R,[cDmax dr Dr]);
                        R=permute(R,[2 1 3]);
                        mps.data{mm+1}=R;

                    end
                    
                end
                
                
                if abs(conv.Ks(end))<conv_parms.Ktol*abs(eta)
                    conv.nsweeps=ss;
                    return
                end
                
            end
            
            conv.nsweeps=ss;
           

        end
                
        
        
        
        
        function [mps,conv]=apply_mpo_1s_sweep(mps,varargin)
        % Find psi to minimize K = || |psi> - Y |phi> ||^2 -> 0
        %
        % This function uses a single site update.
        %
        % Ref: http://iopscience.iop.org/1367-2630/8/12/305
        %
        % Note: the single site update implicitely keeps the
        % norm  1. However therefore conv.norm gives the
        % true final norm before normalization
            
            if nargin==2
                mpoY=varargin{1};
                conv_parms.Ktol=1e-10;
                conv_parms.maxsweeps=10;
                eta_given=0;
            elseif nargin==4
                mpoY=varargin{1};
                conv_parms.Ktol=varargin{2};
                conv_parms.maxsweeps=varargin{3};
                eta_given=0;
            elseif nargin==5
                mpoY=varargin{1};
                conv_parms.Ktol=varargin{2};
                conv_parms.maxsweeps=varargin{3};
                eta_given=varargin{4};
            elseif nargin==6
                mpoY=varargin{1};
                conv_parms.Ktol=varargin{2};
                conv_parms.maxsweeps=varargin{3};
                eta_given=varargin{4};
                phi=varargin{5};
            else
                error(['Wrong number of input arguments to apply_mpo_1s_sweep']);
            end
            
            if nargin<6
                phi=mps; % phi = old mps
            end
            
            M=size(mps.data,2);
            
            % eta=<phi| mpoY' mpoY |phi>
            if ~eta_given
                tmp=mpoY.get_herm_conj;
                tmp=tmp.mult(mpoY);
                eta=phi.get_mpo_expc(tmp);
                conv.eta=eta;
            else
                eta=eta_given;
            end
            
            % phi_psi_edg: <phi| mpoY |psi> 
            phi_psi_edg{M+1}=ones(1,1,1);
            psi_psi_edg{M+1}=ones(1,1);
            for mm=M:-1:2
                gue=mps.data{mm}; % use previous matrix as guess;
                phi_psi_edg{mm}=add_to_right_edge3_AB(phi_psi_edg{mm+1},phi.data{mm},mpoY.data{mm},conj(gue));
                psi_psi_edg{mm}=add_to_right_edge2_AB(psi_psi_edg{mm+1},gue);
            end
            phi_psi_edg{1}=ones(1,1,1);
            psi_psi_edg{1}=ones(1,1);

            convpos=1;    
            for ss=1:conv_parms.maxsweeps
                
                for mm=1:(M-1) % sweep right
                    % QUESTION: is the last gate applicaion necessary?

                    [mpssz1,mpssz2,mpssz3]=size(mps.data{mm}); % for some stupid reason this function get called 3 times!
                    
                    U=edge3_contract_AB(phi_psi_edg{mm},phi_psi_edg{mm+1},mpoY.data{mm},phi.data{mm});
                    %U(abs(U)<mps.zero_thres*max(abs(U)))=0; 
                    
                    U=reshape(U,[mpssz1*mpssz2 mpssz3]);
                    [Q,~]=qr(U,0); % R can be thrown away
                    
                    mps.data{mm}=reshape(Q,[mpssz1 mpssz2 mpssz3]);
                    
                    % error estimate
                    U=reshape(U,[mpssz1 mpssz2 mpssz3]);
                    qxx=edge2_sandwich_AB(psi_psi_edg{mm},psi_psi_edg{mm+1},U);
                    qxy=edge3_sandwich_AB(phi_psi_edg{mm},phi_psi_edg{mm+1},phi.data{mm},mpoY.data{mm},conj(U));
                    conv.Ks(convpos)=qxx-2*real(qxy)+eta;
                    conv.norm(convpos)=norm(U(:));
                    convpos=convpos+1;
                    
                    % create new left edgees
                    phi_psi_edg{mm+1}=add_to_left_edge3_AB(phi_psi_edg{mm},phi.data{mm},mpoY.data{mm},conj(mps.data{mm}));
                    psi_psi_edg{mm+1}=add_to_left_edge2_AB(psi_psi_edg{mm},mps.data{mm});
                    
                end
                
                for mm=M:-1:1 % sweep left
                    
                    [mpssz1,mpssz2,mpssz3]=size(mps.data{mm});

                    U=edge3_contract_AB(phi_psi_edg{mm},phi_psi_edg{mm+1},mpoY.data{mm},phi.data{mm});
                    %U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                    
                    U=reshape(U,[mpssz1 mpssz2 mpssz3]);
                    U=permute(U,[2 1 3]);
                    U=reshape(U,[mpssz2 mpssz1*mpssz3]);
                    [Q,~]=qr(U',0);
                    
                    % Q is unitary and has the form (d rD x lD)
                    Q=reshape(Q,[mpssz1 mpssz3 mpssz2]);
                    mps.data{mm}=permute(Q,[1 3 2]);

                    % error estimate
                    U=reshape(U,[mpssz1 mpssz2 mpssz3]);
                    qxx=edge2_sandwich_AB(psi_psi_edg{mm},psi_psi_edg{mm+1},U);
                    qxy=edge3_sandwich_AB(phi_psi_edg{mm},phi_psi_edg{mm+1},phi.data{mm},mpoY.data{mm},conj(U));
                    conv.Ks(convpos)=qxx-2*real(qxy)+eta;
                    conv.norm(convpos)=norm(U(:));
                    convpos=convpos+1;
                    
                    if mm>1 
                        % create new right edge 
                        phi_psi_edg{mm}=add_to_right_edge3_AB(phi_psi_edg{mm+1},phi.data{mm},mpoY.data{mm},conj(mps.data{mm}));
                        psi_psi_edg{mm}=add_to_right_edge2_AB(psi_psi_edg{mm+1},mps.data{mm});
                    end
                    
                end
                
                
                if conv.Ks(end)<conv_parms.Ktol
                    conv.nsweeps=ss;
                    return
                end
                
            end
            
            conv.nsweeps=ss;
           

        end
                
        
        
        
        
        function expc=get_mpo_expc(mps,mpo)
        % Return expectation value of MPO
        
            M=size(mps.data,2);
            
            edg=ones(1,1,1);
            for mm=M:-1:1
                edg=add_to_right_edge3_AB(edg,mps.data{mm},mpo.data{mm});
            end
            expc=edg;
            
            if abs(imag(expc))<mps.zero_thres*abs(real(expc))
                expc=real(expc);
            end
                
        end
        
        
        
        
        
        function [mps,conv]=apply_dmrg_ns_sweep(mps,ns,ham,Dmaxnew,varargin)
        % Apply variational ground state search. n-site algorithm updates
        %
        % Performs a single sweep to right and then back to left.
        % Dynamically updates bond dimensions disregarding singular values
        % below mps.zero_thres.
        %
        % ns --- number of sites which will be updated at the same time
        % ham --- Hamlitonian in the MPO form
        % Dmaxnew --- new max bond dimension
        %
        % Ref: e.g. New J. Phys. 14 125015, chapter 3
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            if     nargin==4
                eigs_opts.issym=1;
                eigs_opts.isreal=1;
                eigs_opts.isv0=1;  % 1: start var. search from v0, 2: from a random state
                eigs_opts.maxp=20; % way to control # of p vectors in eigs
                eigs_opts.isclean=1; % test parameter
                eigs_opts.is_dyn_trunc=1; % test parameter
                eigs_str='sa';
            elseif nargin==5
                eigs_opts=varargin{1};
                if eigs_opts.isreal && eigs_opts.issym
                    eigs_str='sa';
                else
                    eigs_str='sr';
                end
            else
                error('ERROR: Wrong number of input arguments');
            end
                
            M=size(mps.data,2);
            mps.Dmax=Dmaxnew; 
            
            % edg3 --- left/right parts of the overlap <mps|ham|mps>
            edg3{M+1}=ones(1,1,1);
            for mm=M:-1:(1+ns)
                edg3{mm}=add_to_right_edge3_AB(edg3{mm+1},mps.data{mm},ham.data{mm});
            end
            edg3{1}=ones(1,1,1);
            
            % precalculate Hamiltonian for ns neighbouring sites
            nsiteham=cell(1,M+1-ns);
            for mm=1:(M+1-ns) 
                nsiteham{mm}=ham.data{mm};
                for ins=2:ns
                    nsiteham{mm}=merge_4Darrays(nsiteham{mm},ham.data{mm-1+ins});
                end
            end
            
            % convergence parameters are saved after each local update
            iconv=1; % index 
            conv.flags   =zeros(1,2*(M+1-ns)-1); % convergence flag
            conv.sweep_en=zeros(1,2*(M+1-ns)-1); % energy
            conv.trunc   =zeros(1,(2*(M+1-ns)-1)*ns); % trancation error
            
            % right sweep [mm mm+1 .. mm+ns-1]=optimization sites
            % last ns sites will be optimized during the left sweep 
            for mm=1:(M-ns)
                
                % dimensions of local tensors that will be varied together
                dns =zeros(1,ns);
                DLns=zeros(1,ns);
                DRns=zeros(1,ns);
                for ins=1:ns
                    [dns(ins),DLns(ins),DRns(ins)]=size(mps.data{mm-1+ins});
                end
                
                nsitemps_sz=[prod(dns) DLns(1) DRns(ns)];
                nsitemps_sz_vec=prod(nsitemps_sz);
                F = @(mps_vec_in) edge3_contract_AB(edg3{mm},edg3{mm+ns},...
                    nsiteham{mm},mps_vec_in,nsitemps_sz);
                
                % initial state
                if eigs_opts.isv0
                    v0=mps.data{mm};
                    for ins=2:ns
                        v0=merge_3Darrays(v0,mps.data{mm-1+ins});
                    end
                    eigs_opts.v0=reshape(v0,nsitemps_sz_vec,1);
                end
                
                % see eigs manual
                eigs_opts.p=min(eigs_opts.maxp,nsitemps_sz_vec);
                
                % variational search
                [U,conv.sweep_en(iconv),conv.flags(iconv)]=...
                    eigs(F,nsitemps_sz_vec,1,eigs_str,eigs_opts);
                if eigs_opts.isclean
                    U(abs(U)<mps.zero_thres*max(abs(U)))=0; % does it help?
                end
                
                [matsout,trunc,mat_rem]=split_3Darrays(reshape(U,nsitemps_sz),...
                    [dns;DLns;DRns],mps.Dmax,1,ns,mps.zero_thres,eigs_opts.is_dyn_trunc);
                conv.trunc(ns*(iconv-1)+1:ns*iconv)=trunc;
                iconv=iconv+1;
                
                % update local arrays
                for ins=1:ns
                    mps.data{mm-1+ins}=matsout{ins};
                end
                
                % update edg3 with the newly calculated site
                edg3{mm+1}=add_to_left_edge3_AB(edg3{mm},mps.data{mm},ham.data{mm});
                
                if size(mat_rem,2)<=size(mps.data{mm+ns},2)
                    % mat_rem is smaller than the next array
                    tmp=mps.data{mm+ns}(:,1:size(mat_rem,2),:);
                else
                    % mat_rem is larger than the next array
                    tmp=zeros(size(mps.data{mm+ns},1),size(mat_rem,2),size(mps.data{mm+ns},3));
                    tmp(:,1:size(mps.data{mm+ns},2),:)=mps.data{mm+ns};
                end
                mps.data{mm+ns}=merge_3Darrays(permute(mat_rem,[3 1 2]),tmp);
                
            end
            
            % left sweep
            for mm=(M+1-ns):-1:1
                
                % dimensions of local tensors that will be varied together
                dns =zeros(1,ns);
                DLns=zeros(1,ns);
                DRns=zeros(1,ns);
                for ins=1:ns
                    [dns(ins),DLns(ins),DRns(ins)]=size(mps.data{mm-1+ins});
                end
                
                nsitemps_sz=[prod(dns) DLns(1) DRns(end)];
                nsitemps_sz_vec=prod(nsitemps_sz);
                F = @(mps_vec_in) edge3_contract_AB(edg3{mm},edg3{mm+ns},...
                    nsiteham{mm},mps_vec_in,nsitemps_sz);
                
                % initial state
                if eigs_opts.isv0
                    v0=mps.data{mm};
                    for ins=2:ns
                        v0=merge_3Darrays(v0,mps.data{mm-1+ins});
                    end
                    eigs_opts.v0=reshape(v0,nsitemps_sz_vec,1);
                end
                
                % see eigs manual
                eigs_opts.p=min(eigs_opts.maxp,nsitemps_sz_vec);
                
                % variational search
                [U,conv.sweep_en(iconv),conv.flags(iconv)]=...
                    eigs(F,nsitemps_sz_vec,1,eigs_str,eigs_opts);
                if eigs_opts.isclean
                    U(abs(U)<mps.zero_thres*max(abs(U)))=0; % does it help?
                end
                
                [matsout,trunc,mat_rem]=split_3Darrays(reshape(U,nsitemps_sz),...
                    [dns;DLns;DRns],mps.Dmax,0,ns,mps.zero_thres,eigs_opts.is_dyn_trunc);
                conv.trunc(ns*(iconv-1)+1:ns*iconv)=trunc;
                iconv=iconv+1;
                
                % update local arrays
                for ins=1:ns
                    mps.data{mm-1+ins}=matsout{ins};
                end
                
                if mm>1
                    % update edg3 with the newly calculated site
                    edg3{mm-1+ns}=add_to_right_edge3_AB(edg3{mm+ns},...
                        mps.data{mm-1+ns},ham.data{mm-1+ns});
                    
                    if size(mat_rem,1)<=size(mps.data{mm-1},3)
                        % mat_rem is smaller than the next array
                        tmp=mps.data{mm-1}(:,:,1:size(mat_rem,1));
                    else
                        % mat_rem is larger than the next array
                        tmp=zeros(size(mps.data{mm-1},1),size(mps.data{mm-1},2),size(mat_rem,1));
                        tmp(:,1:size(mps.data{mm-1},2),:)=mps.data{mm-1};
                    end
                    mps.data{mm-1}=merge_3Darrays(tmp,permute(mat_rem,[3 1 2]));
                end
                
            end
            
        end
        
        
        
        
        
        function [mps,conv]=apply_emps_ns_sweep(mps,ns,ham,Dmaxnew,mpsprev,varargin)
        % Apply variational excited states search. n-site algorithm updates
        %
        % Performs a single sweep to right and then back to left.
        % Dynamically updates bond dimensions disregarding singular values
        % below mps.zero_thres.
        %
        % ns --- number of sites which will be updated at the same time
        % ham --- Hamlitonian in the MPO form
        % Dmaxnew --- new max bond dimension
        % mpsprev --- previously found eigenstates
        %
        % NOTE: this function has one disadvantage --- it finds only
        % negative eigenstates, so the Hamiltonian should be shifted
        % towards negative energies beforehand
        %
        % Ref: e.g. New J. Phys. 14 125015, chapter 3
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            if     nargin==5
                eigs_opts.issym=1;
                eigs_opts.isreal=1;
                eigs_opts.isv0=1;  % see below
                eigs_opts.maxp=20; % see below
                eigs_opts.isclean=1;
                eigs_opts.is_dyn_trunc=1; % test parameter
                eigs_str='sa';
            elseif nargin==6
                eigs_opts=varargin{1};
                if eigs_opts.isreal && eigs_opts.issym
                    eigs_str='sa';
                else
                    eigs_str='sr';
                end
            else
                error('ERROR: Wrong number of input arguments');
            end
                
            M=size(mps.data,2);
            mps.Dmax=Dmaxnew;
            nconst=length(mpsprev); % number of previously found mps
            
            % edg3 --- left/right parts of the overlap <mps|ham|mps>
            edg3{M+1}=ones(1,1,1);
            for mm=M:-1:(1+ns)
                edg3{mm}=add_to_right_edge3_AB(edg3{mm+1},mps.data{mm},ham.data{mm});
            end
            edg3{1}=ones(1,1,1);
            
            % overlaps with mpsprev 
            for ii=nconst:-1:1
                edg2{M+1,ii}=ones(1,1);
                for mm=M:-1:(1+ns)
                    edg2{mm,ii}=add_to_right_edge2_AB(edg2{mm+1,ii},...
                        mpsprev{ii}.data{mm},conj(mps.data{mm}));
                end
                edg2{1,ii}=ones(1,1);
            end
            
            % precalculate Hamiltonian for ns neighbouring sites
            nsiteham=cell(1,M+1-ns);
            for mm=1:(M+1-ns) 
                nsiteham{mm}=ham.data{mm};
                for ins=2:ns
                    nsiteham{mm}=merge_4Darrays(nsiteham{mm},ham.data{mm-1+ins});
                end
            end
            
            % precalculate contracted tensors of the previous sites
            nsitempsprev=cell(nconst,M+1-ns);
            for ii=1:nconst
                for mm=1:(M+1-ns) 
                    nsitempsprev{ii,mm}=mpsprev{ii}.data{mm};
                    for ins=2:ns
                        nsitempsprev{ii,mm}=merge_3Darrays(nsitempsprev{ii,mm},...
                            mpsprev{ii}.data{mm-1+ins});
                    end
                end
            end
            
            % convergence parameters are saved after each local update
            iconv=1; % index 
            conv.flags   =zeros(1,2*(M+1-ns)-1); % convergence flag
            conv.sweep_en=zeros(1,2*(M+1-ns)-1); % energy
            conv.trunc   =zeros(1,(2*(M+1-ns)-1)*ns); % trancation error
            
            % auxiliary function for constraints
            function mps_vec_out=FConst(edgL,edgR,hamData,mpssz,mps_vec_in,constTensor)
            % Cutting off non-orthogonal parts.
            % IMPORTANT: This part should be probably redone because it works
            % only for negative eigenvalues. We are throwing away the
            % non-orthogonal components of |psi> => decreasing <psi|psi> => 
            % making abs(<psi|H|psi>) smaller => increase the energy. 
            % Hence the solver eigs for minimization will tend to search for 
            % orthogonal solutions, which we need only if <psi|H|psi> 
            % is negative. In the case if it is positive eigs will collapse
            % to the eigenvalue 0.
            %
            % The current solution is to shift the whole spectrum down.
            %
            % There was an idea that restoration of norm of input and/or
            % output help to work with positive eigenvectors, but it
            % did not give any succesfull result.
                for icon=1:size(constTensor,2)
                    mps_vec_in=mps_vec_in-constTensor(:,icon)*...
                        (constTensor(:,icon)'*mps_vec_in);
                end
                
                mps_vec_out=edge3_contract_AB(edgL,edgR,hamData,mps_vec_in,mpssz);
                
                % it works better if the output is orthogonalized too
                for icon=1:size(constTensor,2)
                    mps_vec_out=mps_vec_out-constTensor(:,icon)*...
                        (constTensor(:,icon)'*mps_vec_out);
                end   
            end
            
            % right sweep [mm mm+1 .. mm+ns-1]=optimization sites
            % last ns sites will be optimized during the left sweep 
            for mm=1:(M-ns)
                
                % dimensions of local tensors that will be varied together
                dns =zeros(1,ns);
                DLns=zeros(1,ns);
                DRns=zeros(1,ns);
                for ins=1:ns
                    [dns(ins),DLns(ins),DRns(ins)]=size(mps.data{mm-1+ins});
                end
                
                nsitemps_sz=[prod(dns) DLns(1) DRns(end)];
                nsitemps_sz_vec=prod(nsitemps_sz);
                
                % constraints
                constTensor=zeros(nsitemps_sz_vec,nconst); % columns are orthogonal vectors
                for ii=1:nconst
                    constTensor(:,ii)=...
                        reshape(edge2_contract_AB(edg2{mm,ii},edg2{mm+ns,ii},...
                        nsitempsprev{ii,mm}),[nsitemps_sz_vec 1]);
                end
                
                % eigs can execute only functions with one argument 
                FConstExe = @(mps_vec_in) FConst(edg3{mm},edg3{mm+ns},nsiteham{mm},...
                    nsitemps_sz,mps_vec_in,constTensor);
                
                % initial state
                if eigs_opts.isv0
                    v0=mps.data{mm};
                    for ins=2:ns
                        v0=merge_3Darrays(v0,mps.data{mm-1+ins});
                    end
                    eigs_opts.v0=reshape(v0,nsitemps_sz_vec,1);
                end
                
                % see eigs manual
                eigs_opts.p=min(eigs_opts.maxp,nsitemps_sz_vec);
                
                % variational search
                [U,conv.sweep_en(iconv),conv.flags(iconv)]=...
                    eigs(FConstExe,nsitemps_sz_vec,1,eigs_str,eigs_opts);
                if eigs_opts.isclean
                    U(abs(U)<mps.zero_thres*max(abs(U)))=0; % does it help?
                end
                
                [matsout,trunc,mat_rem]=split_3Darrays(reshape(U,nsitemps_sz),...
                    [dns;DLns;DRns],mps.Dmax,1,ns,mps.zero_thres,eigs_opts.is_dyn_trunc);
                conv.trunc(ns*(iconv-1)+1:ns*iconv)=trunc;
                iconv=iconv+1;
                
                % update local arrays
                for ins=1:ns
                    mps.data{mm-1+ins}=matsout{ins};
                end
                
                % update edg3 and edg3 with the newly calculated site
                edg3{mm+1}=add_to_left_edge3_AB(edg3{mm},mps.data{mm},ham.data{mm});
                for ii=1:nconst
                    edg2{mm+1,ii}=add_to_left_edge2_AB(edg2{mm,ii},...
                        mpsprev{ii}.data{mm},conj(mps.data{mm}));
                end
                
                if size(mat_rem,2)<=size(mps.data{mm+ns},2)
                    % mat_rem is smaller than the next array
                    tmp=mps.data{mm+ns}(:,1:size(mat_rem,2),:);
                else
                    % mat_rem is larger than the next array
                    tmp=zeros(size(mps.data{mm+ns},1),size(mat_rem,2),size(mps.data{mm+ns},3));
                    tmp(:,1:size(mps.data{mm+ns},2),:)=mps.data{mm+ns};
                end
                mps.data{mm+ns}=merge_3Darrays(permute(mat_rem,[3 1 2]),tmp);
                
            end
            
            % left sweep
            for mm=(M+1-ns):-1:1
                
                % dimensions of local tensors that will be varied together
                dns =zeros(1,ns);
                DLns=zeros(1,ns);
                DRns=zeros(1,ns);
                for ins=1:ns
                    [dns(ins),DLns(ins),DRns(ins)]=size(mps.data{mm-1+ins});
                end
                
                nsitemps_sz=[prod(dns) DLns(1) DRns(end)];
                nsitemps_sz_vec=prod(nsitemps_sz);
                
                constTensor=zeros(nsitemps_sz_vec,nconst); % columns are orthogonal vectors
                for ii=1:nconst
                    constTensor(:,ii)=... 
                        reshape(edge2_contract_AB(edg2{mm,ii},edg2{mm+ns,ii},...
                        nsitempsprev{ii,mm}),[nsitemps_sz_vec 1]);                    
                end
                
                FConstExe = @(mps_vec_in) FConst(edg3{mm},edg3{mm+ns},nsiteham{mm},...
                    nsitemps_sz,mps_vec_in,constTensor);
                
                % initial state
                if eigs_opts.isv0
                    v0=mps.data{mm};
                    for ins=2:ns
                        v0=merge_3Darrays(v0,mps.data{mm-1+ins});
                    end
                    eigs_opts.v0=reshape(v0,nsitemps_sz_vec,1);
                end
                
                % see eigs manual
                eigs_opts.p=min(eigs_opts.maxp,nsitemps_sz_vec);
                
                % variational search
                [U,conv.sweep_en(iconv),conv.flags(iconv)]=...
                    eigs(FConstExe,nsitemps_sz_vec,1,eigs_str,eigs_opts);
                if eigs_opts.isclean
                    U(abs(U)<mps.zero_thres*max(abs(U)))=0; % does it help?
                end
                
                [matsout,trunc,mat_rem]=split_3Darrays(reshape(U,nsitemps_sz),...
                    [dns;DLns;DRns],mps.Dmax,0,ns,mps.zero_thres,eigs_opts.is_dyn_trunc);
                conv.trunc(ns*(iconv-1)+1:ns*iconv)=trunc;
                iconv=iconv+1;
                
                % update local arrays
                for ins=1:ns
                    mps.data{mm-1+ins}=matsout{ins};
                end
                
                if mm>1
                    % update edg3 with the newly calculated site
                    edg3{mm-1+ns}=add_to_right_edge3_AB(edg3{mm+ns},...
                        mps.data{mm-1+ns},ham.data{mm-1+ns});
                    for ii=1:nconst
                        edg2{mm-1+ns,ii}=add_to_right_edge2_AB(edg2{mm+ns,ii},...
                            mpsprev{ii}.data{mm-1+ns},conj(mps.data{mm-1+ns}));
                    end
                    
                    if size(mat_rem,1)<=size(mps.data{mm-1},3)
                        % mat_rem is smaller than the next array
                        tmp=mps.data{mm-1}(:,:,1:size(mat_rem,1));
                    else
                        % mat_rem is larger than the next array
                        tmp=zeros(size(mps.data{mm-1},1),size(mps.data{mm-1},2),size(mat_rem,1));
                        tmp(:,1:size(mps.data{mm-1},2),:)=mps.data{mm-1};
                    end
                    mps.data{mm-1}=merge_3Darrays(tmp,permute(mat_rem,[3 1 2]));
                end
                
            end
            
        end
        
        
        
        
        
        function [mps,conv]=apply_tdvp_1s_trotter(mps,ham,dt,expv_opts,order)
        % Apply time-evolution via TDVP. Single-site algorithm.
        % Single time step.
        %
        % expv_opts.tol      - tolerance
        % expv_opts.nkryl    - number of Krylov vectors
        % expv_opts.isclean  - cleaning after evolution (questinable parameter)
        % expv_opts.is_norm  - normalization after evolution (default 1)
        %
        % Ref: arxiv.org/abs/1408.5056
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            if ~isfield(expv_opts,'is_norm')
                expv_opts.is_norm=1;
            end
            
            M=size(mps.data,2);
            
            % create edges
            edg{M+1}=ones(1,1,1);
            for mm=M:-1:2
                edg{mm}=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
            end
            edg{1}=ones(1,1,1);
            
            if order==1
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt,expv_opts,edg,1);
                for mm=M:-1:2
                    mps=mps.shift_qr(0);
                end
            elseif order==2
                dt=dt/2;
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt,expv_opts,edg,1);
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt,expv_opts,edg,0);
            elseif order==4
                dt1=dt/12; 
                dt2=-dt/6;
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1T)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt2,expv_opts,edg,0); % (2)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,edg,0);                          % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,edg,0);                          % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,edg,0);                          % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,edg,1);                          % (id)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,edg,1);                          % (id)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,edg,1);                          % (id)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt2,expv_opts,edg,1); % (2)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
            else
                error('tdvp_1s_sweep: use order=1,2,4')
            end
        
        end
        
        
        
        
        
        function [mps,conv]=apply_tdvp_1s_trotter_nonherm(mps,ham,expmLL,dt,expv_opts,order)
        % Apply non-Hermitian time-evolution via TDVP. Single-site algorithm.
        % Single time step.
        %
        % DOUBLE CHECK BEFORE USING
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            M=size(mps.data,2);
            
            % create edges
            edg{M+1}=ones(1,1,1);
            for mm=M:-1:2
                edg{mm}=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
            end
            edg{1}=ones(1,1,1);
            
            if order==1
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt,expv_opts,edg,1);
                for mm=M:-1:2
                    mps=mps.shift_qr(0);
                end
            elseif order==2
                dt=dt/2;
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt,expv_opts,edg,1);
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt,expv_opts,edg,0);
            elseif order==4
                dt1=dt/12; 
                dt2=-dt/6;
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1T)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt2,expv_opts,edg,0); % (2)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,expmLL,edg,0);                                  % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,expmLL,edg,0);                                  % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,expmLL,edg,0);                                  % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,expmLL,edg,1);                                  % (id)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,expmLL,edg,1);                                  % (id)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,expmLL,edg,1);                                  % (id)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt2,expv_opts,edg,1); % (2)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_1s_sweep_nonherm(ham,expmLL,dt1,expv_opts,edg,0); % (1)T
            else
                error('tdvp_1s_sweep_nonherm: use order=1,2,4')
            end
        
        end        
        
        
        
        
        
        function [err,errmat]=get_tdvp_1s_error(mps,ham, ham2expc)
        % Return error estimation of TDVP. Single-site algorithm.
        %
        % Here ham2expc = <H^2>.
        %
        % Ref: arxiv.org/abs/1408.5056
        
            M=size(mps.data,2);
            
            % create edges
            edg{M+1}=ones(1,1,1);
            for mm=M:-1:2
                edg{mm}=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
            end
            edg{1}=ones(1,1,1);

            err=0;
            
            for mm=1:M % right sweep mm=optimization site
                
                mpssz(1)=size(mps.data{mm},1);
                mpssz(2)=size(mps.data{mm},2);
                mpssz(3)=size(mps.data{mm},3);
                mps_vec_dim=prod(mpssz);
                
                HFA = @(mps_vec_in) edge3_contract_AB(edg{mm},edg{mm+1},ham.data{mm},mps_vec_in,mpssz);
                
                U=reshape(mps.data{mm},[mps_vec_dim 1]);
                %errmat(mm,1)=real(U'*HFA(HFA(U)));
                %errmat(mm,3)=real(U'*(HFA(U)));
                err=err-real(U'*HFA(HFA(U)));
                
                if mm<M

                    % shift qr
                    U=reshape(mps.data{mm},[mpssz(1)*mpssz(2) mpssz(3)]);
                    [Q,C]=qr(U,0);
                    Q=reshape(Q,mpssz);
                    
                    % create new left edge for 0-site Hamiltonian (also needed later anyway)
                    tmp_edg=add_to_left_edge3_AB(edg{mm},Q,ham.data{mm});

                    
                    cssz(1)=size(C,1);
                    cssz(2)=size(C,2);
                    C_vec_dim=prod(cssz);
                    
                    KFA = @(C_vec_in) edge_contract(tmp_edg, edg{mm+1}, ham.data{mm}, cssz , C_vec_in);

                    C=reshape(C,[C_vec_dim 1]);                    
                    %errmat(mm,2)=real(C'*KFA(KFA(C)));
                    %errmat(mm,4)=real(C'*(KFA(C)));
                    err=err+real(C'*KFA(KFA(C)));
                    
                    % absorb C
                    mpssz(1)=size(mps.data{mm+1},1);
                    mpssz(2)=size(mps.data{mm+1},2);
                    mpssz(3)=size(mps.data{mm+1},3);
                    
                    C=reshape(C, [cssz(1) cssz(2)]);
                    
                    tmp1=permute(mps.data{mm+1},[2 1 3]);
                    tmp1=reshape(tmp1,[mpssz(2) mpssz(1)*mpssz(3)]);
                    tmp1=reshape(C*tmp1,[cssz(1) mpssz(1) mpssz(3)]);
                    mps.data{mm+1}=permute(tmp1, [2 1 3]);
                    
                    % update edge
                    edg{mm+1}=tmp_edg;
                
                end
                
            end
            
            err=abs(err+ham2expc);
            
        end
        
        
        
        
        
        function [mps,conv]=apply_tdvp_2s_trotter(mps,ham,dt,expv_opts,order)
        % Apply time-evolution via TDVP. Two-site algorithm.
        % Two time step.
        %
        % expv_opts.tol          - tolerance
        % expv_opts.nkryl        - number of Krylov vectors
        % expv_opts.isclean      - cleaning after evolution (questinable parameter)
        % expv_opts.is_dyn_trunc - dynamical change of bond dimensions (questinable parameter)
        %
        % Ref: arxiv.org/abs/1408.5056
            
            if mps.qr~=0
                error('ERROR: function works only for mps.qr==0');
            end
            
            M=size(mps.data,2);
            
            % create edges
            edg{M+1}=ones(1,1,1);
            for mm=M:-1:3
                edg{mm}=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
            end
            edg{1}=ones(1,1,1);
            
            if order==1
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt,expv_opts,edg,1);
                for mm=M:-1:2
                    mps=mps.shift_qr(0);
                end
            elseif order==2
                dt=dt/2;
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt,expv_opts,edg,1);
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt,expv_opts,edg,0);
            elseif order==4
                dt1=dt/12; 
                dt2=-dt/6;
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1T)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt2,expv_opts,edg,0); % (2)T
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,edg,0);                          % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,edg,0);                          % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,edg]=mps.sweep_qr_edge(ham,edg,0);                          % (id)T  
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,edg,1);                          % (id)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,edg,1);                          % (id)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,edg]=mps.sweep_qr_edge(ham,edg,1);                          % (id)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt2,expv_opts,edg,1); % (2)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps,conv,edg]=mps.apply_tdvp_2s_sweep(ham,dt1,expv_opts,edg,0); % (1)T
            else
                error('tdvp_1s_sweep: use order=1,2,4')
            end
        
        end
        
        
        
        
        
        function [err,errmat]=get_tdvp_2s_error(mps,ham, ham2expc)
        % Return error estimation of TDVP. Two-site algorithm.
        %
        % Ref: arxiv.org/abs/1408.5056
        %
        % NOT WORKING
        
            M=size(mps.data,2);
            
            % create edges
            edg{M+1}=ones(1,1,1);
            for mm=M:-1:3
                edg{mm}=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
            end
            edg{1}=ones(1,1,1);

            err=0;
            
            for mm=1:M-1 % right sweep (mm,mm+1)=optimization sitesa
                
                [mlsz1,mlsz2,~]=size(mps.data{mm});
                [mrsz1,~,mrsz3]=size(mps.data{mm+1}); 
                
                dblmps=merge_3Darrays(mps.data{mm},mps.data{mm+1});
                dblmpo=merge_4Darrays(ham.data{mm},ham.data{mm+1});
                
                HFA = @(dblmps_vec_in) edge3_contract_AB(edg{mm},edg{mm+2},dblmpo,dblmps_vec_in,[mlsz1*mrsz1 mlsz2 mrsz3]);
                
                U=reshape(dblmps,[],1);
                errmat(mm,1)=real(U'*HFA(HFA(U)));
                errmat(mm,3)=real(U'*(HFA(U)));
                err=err-real(U'*HFA(HFA(U)));
                
                if mm<M-1
                    
                    U=reshape(U,[mlsz1 mrsz1 mlsz2 mrsz3]);
                    U=permute(U,[1 3 2 4]);
                    U=reshape(U,[mlsz1*mlsz2 mrsz1*mrsz3]);
                    
                    [L,lam,R]=svd(U,'econ');

                    R=R';
                    cDmax=min(size(mps.data{mm},3),mps.Dmax);
                    %conv.trunc(mm)=sum(lam((cDmax+1):end).^2);
                    L=L(:,1:cDmax)*diag(lam(1:cDmax));  
                    R=R(1:cDmax,:);
                    lam=diag(lam);
                    L=reshape(L,[mlsz1 mlsz2 cDmax]);
                    R=reshape(R,[cDmax mrsz1 mrsz3]);
                    R=permute(R,[2 1 3]);
                    
                    % create new left edge for 1-site Hamiltonian 
                    edg{mm+1}=add_to_left_edge3_AB(edg{mm},mps.data{mm},ham.data{mm});



                    
                    mpssz(1)=mrsz1;
                    mpssz(2)=cDmax;
                    mpssz(3)=mrsz3;
                    mps_vec_dim=prod(mpssz);

                    KFA = @(mps_vec_in) edge3_contract_AB(edg{mm+1},edg{mm+2},ham.data{mm+1},mps_vec_in,mpssz);

                    C=reshape(mps.data{mm+1}, [mps_vec_dim 1]);
                    
                    
                    
                    err=err+real(C'*KFA((KFA(C))));
                    errmat(mm,2)=real(C'*KFA((KFA(C))));
                    errmat(mm,4)=real(C'*(KFA(C)));
                    
                end
                
            end
            
            err=abs(err+ham2expc);
            errmat
        end
    
    end
    
    
    
    
    
    methods (Access=protected)   
        
        function [mps,conv,edg]=apply_tdvp_1s_sweep(mps,ham,dt,expv_opts,edg,lr)
        % Apply single sweep of TDVP. Single-site algorithm.
        
            M=size(mps.data,2);
            
            %conv=-99;
            conv.tnrms=zeros(1,M);
            
            if lr % go right   
                
                for mm=1:M; % right sweep mm=optimization site
                
                    mpssz(1)=size(mps.data{mm},1);
                    mpssz(2)=size(mps.data{mm},2);
                    mpssz(3)=size(mps.data{mm},3);
                    mps_vec_dim=prod(mpssz);
                
                    strH.FA = @(mps_vec_in) edge3_contract_AB(edg{mm},edg{mm+1},ham.data{mm},mps_vec_in,mpssz);
                    strH.n=mps_vec_dim;
                    
                    % step one: evolve local matrix and make it right orthogonal
                    [U]=expv_fh(-1i.*dt,strH,reshape(mps.data{mm},[mps_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                    if expv_opts.isclean
                        U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                    end
                    
                    tnrm=U'*U;
                    conv.tnrms(mm)=tnrm;
                    
                    U=reshape(U,[mpssz(1)*mpssz(2) mpssz(3)]);
                    [Q,C]=qr(U,0);
                    
                    % de-normalize for effective Hamiltonian case
                    % Q=Q.*sqrt(tnrm);
                    % C=C./sqrt(tnrm);

                    % update
                    mps.data{mm}=reshape(Q,mpssz);
                    
                    if mm<M
                    
                        % create new left edge for 0-site Hamiltonian (also needed later anyway)
                        tmp_edg=add_to_left_edge3_AB(edg{mm},mps.data{mm},ham.data{mm});
                        
                        % now evolve C backwards in time
                        cssz(1)=size(C,1);
                        cssz(2)=size(C,2);
                        C_vec_dim=prod(cssz);
                        
                        strK.FA = @(C_vec_in) edge_contract(tmp_edg,edg{mm+1},ham.data{mm},cssz,C_vec_in);
                        strK.n=C_vec_dim;
                        
                        [D]=expv_fh(1i.*dt,strK,reshape(C,[C_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                        if expv_opts.isclean
                            D(abs(D)<mps.zero_thres*max(abs(D)))=0;
                        end
                        
                        % absorb into right matrix
                        mpssz(1)=size(mps.data{mm+1},1);
                        mpssz(2)=size(mps.data{mm+1},2);
                        mpssz(3)=size(mps.data{mm+1},3);
                        
                        D=reshape(D, [cssz(1) cssz(2)]);
                        
                        tmp1=permute(mps.data{mm+1},[2 1 3]);
                        tmp1=reshape(tmp1,[mpssz(2) mpssz(1)*mpssz(3)]);
                        tmp1=reshape(D*tmp1,[cssz(1) mpssz(1) mpssz(3)]);
                        mps.data{mm+1}=permute(tmp1, [2 1 3]);
                        
                        % update edge
                        edg{mm+1}=tmp_edg;
                        mps.qr=mps.qr+1;
                    else
                        % absorb the norm
                        if ~expv_opts.is_norm
                            mps.data{mm}=mps.data{mm}*C;
                        end
                    end
                    
                end

            else % go left
                
                for mm=M:-1:1

                    mpssz(1)=size(mps.data{mm},1);
                    mpssz(2)=size(mps.data{mm},2);
                    mpssz(3)=size(mps.data{mm},3);
                    mps_vec_dim=prod(mpssz);
                    
                    strH.FA = @(mps_vec_in) edge3_contract_AB(edg{mm},edg{mm+1},ham.data{mm},mps_vec_in,mpssz);
                    strH.n=mps_vec_dim;
                    
                    % step one: evolve local matrix and make it left orthogonal
                    [U]=expv_fh(-1i.*dt,strH,reshape(mps.data{mm},[mps_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                    if expv_opts.isclean
                        U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                    end
                    
                    tnrm=U'*U;
                    conv.tnrms(mm)=tnrm;

                    U=reshape(U,mpssz);
                    U=permute(U,[2 1 3]);
                    U=reshape(U,[mpssz(2) mpssz(1)*mpssz(3)]);
                    
                    U=permute(U,[2 1]);
                    [Q,C]=qr(U,0);
                    
                    % Q=Q.*sqrt(tnrm);
                    % C=C./sqrt(tnrm);
                    
                    Q=permute(Q,[2 1]);
                    C=permute(C,[2 1]);

                    % update
                    Q=reshape(Q,[mpssz(2) mpssz(1) mpssz(3)]);
                    mps.data{mm}=permute(Q,[2 1 3]);
                    
                    if mm>1
                    
                        % create new right edge for 0-site Hamiltonian (also needed later anyway)
                        tmp_edg=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
                        
                        % now evolve C backwards in time
                        cssz(1)=size(C,1);
                        cssz(2)=size(C,2);
                        C_vec_dim=prod(cssz);
                        
                        strK.FA = @(C_vec_in) edge_contract(edg{mm},tmp_edg,ham.data{mm},cssz,C_vec_in);
                        strK.n=C_vec_dim;
                        
                        [D]=expv_fh(1i.*dt,strK,reshape(C,[C_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                        if expv_opts.isclean
                            D(abs(D)<mps.zero_thres*max(abs(D)))=0;
                        end
                        
                        % absorb into left matrix
                        
                        mpssz(1)=size(mps.data{mm-1},1);
                        mpssz(2)=size(mps.data{mm-1},2);
                        mpssz(3)=size(mps.data{mm-1},3);
                        
                        D=reshape(D, [cssz(1) cssz(2)]);
                        
                        tmp1=reshape(mps.data{mm-1},[mpssz(1)*mpssz(2) mpssz(3)]);
                        mps.data{mm-1}=reshape(tmp1*D,[mpssz(1) mpssz(2) cssz(2)]);
                        
                        % update edge
                        edg{mm}=tmp_edg;
                        
                        mps.qr=mps.qr-1;
                    else
                        % absorb the norm
                        if ~expv_opts.is_norm
                            mps.data{mm}=mps.data{mm}*C;
                        end
                    end
                end
                
            end
            
        end
        
        
        
        
        
        function [mps,conv,edg]=apply_tdvp_1s_sweep_nonherm(mps,ham,expmLL,dt,expv_opts,edg,lr)
        % Apply single sweep of TDVP with non-Hermitian Hamiltonian. 
        % Single-site algorithm.

            M=size(mps.data,2);
            
            conv=-99;
            
            if lr % go right
                
                
                for mm=1:M; % right sweep mm=optimization site
                
                    mpssz(1)=size(mps.data{mm},1);
                    mpssz(2)=size(mps.data{mm},2);
                    mpssz(3)=size(mps.data{mm},3);
                    mps_vec_dim=prod(mpssz);
                
                    strH.FA = @(mps_vec_in) edge3_contract_AB(edg{mm},edg{mm+1},ham.data{mm},mps_vec_in,mpssz);
                    strH.n=mps_vec_dim;

                    
                    % step one: evolve local matrix and make it orthogonal
                    [U]=expv_fh(-1i.*dt,strH,reshape(mps.data{mm},[mps_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                    if expv_opts.isclean
                        U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                    end
                    
                    % before making it orthogonal, apply non-hermitian evolution (the MPS
                    % has to be in proper lr form to make this evolution
                    %U=expmLL{mm}*reshape(U,[mpssz(1) mpssz(2)*mpssz(3)]);  

                    VVV=reshape(U,[mps_vec_dim 1]);
                    VVVS{mm}=VVV'*VVV;
                    
                    U=reshape(U,[mpssz(1)*mpssz(2) mpssz(3)]);                    
                    [Q,C]=qr(U,0);
                    
                    % update 
                    %Q=expmLL{mm}*reshape(Q,[mpssz(1) mpssz(2)*mpssz(3)]);
                    mps.data{mm}=reshape(Q,mpssz);
                    
                    %UIUI=max(max(Q'*Q-eye(size(Q'*Q))))
                    
                    
                    %Q(:,1)'*Q(:,1)
                    
                    %error('STOOP')
                    
                    if mm<M
                    
                        % create new left edge for 0-site Hamiltonian (also needed later anyway)
                        tmp_edg=add_to_left_edge3_AB(edg{mm},mps.data{mm},ham.data{mm});
                        
                        % now evolve C backwards in time
                        cssz(1)=size(C,1);
                        cssz(2)=size(C,2);
                        C_vec_dim=prod(cssz);
                        
                        strK.FA = @(C_vec_in) edge_contract(tmp_edg,edg{mm+1},ham.data{mm},cssz,C_vec_in);
                        strK.n=C_vec_dim;
                        
                        [D]=expv_fh(1i.*dt,strK,reshape(C,[C_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                        if expv_opts.isclean
                            D(abs(D)<mps.zero_thres*max(abs(D)))=0;
                        end

                        % absorb into right matrix
                        mpssz(1)=size(mps.data{mm+1},1);
                        mpssz(2)=size(mps.data{mm+1},2);
                        mpssz(3)=size(mps.data{mm+1},3);
                        
                        D=reshape(D, [cssz(1) cssz(2)]);
                        
                        tmp1=permute(mps.data{mm+1},[2 1 3]);
                        tmp1=reshape(tmp1,[mpssz(2) mpssz(1)*mpssz(3)]);
                        tmp1=reshape(D*tmp1,[cssz(1) mpssz(1) mpssz(3)]);
                        mps.data{mm+1}=permute(tmp1, [2 1 3]);
                        
                        % update edge
                        edg{mm+1}=tmp_edg;
                        mps.qr=mps.qr+1;
                    end
                    
                end

            else % go left
                
                for mm=M:-1:1

                    mpssz(1)=size(mps.data{mm},1);
                    mpssz(2)=size(mps.data{mm},2);
                    mpssz(3)=size(mps.data{mm},3);
                    mps_vec_dim=prod(mpssz);
                    
                    strH.FA = @(mps_vec_in) edge3_contract_AB(edg{mm},edg{mm+1},ham.data{mm},mps_vec_in,mpssz);
                    strH.n=mps_vec_dim;
                    
                    % step one: evolve local matrix and make it orthogonal
                    [U]=expv_fh(-1i.*dt, strH, reshape(mps.data{mm},[mps_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                    if expv_opts.isclean
                        U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                    end
                    
                    %U=expmLL{mm}*reshape(U,[mpssz(1) mpssz(2)*mpssz(3)]);  
                    
                    %WWW=reshape(U,[mps_vec_dim 1]);
                    %WWWs{mm}=WWW'*WWW

                    
                    U=reshape(U,mpssz);
                    U=permute(U,[2 1 3]);
                    U=reshape(U,[mpssz(2) mpssz(1)*mpssz(3)]);
                    
                    U=permute(U,[2 1]);
                    [Q,C]=qr(U,0);
                    Q=permute(Q,[2 1]);
                    C=permute(C,[2 1]);

                    % update
                    Q=reshape(Q,[mpssz(2) mpssz(1) mpssz(3)]);
                    Q=permute(Q,[2 1 3]);
                    Q=expmLL{mm}*reshape(Q,[mpssz(1) mpssz(2)*mpssz(3)]);
                    mps.data{mm}=reshape(Q,mpssz);

                    
                    if mm>1
                    
                        % create new right edge for 0-site Hamiltonian (also needed later anyway)
                        tmp_edg=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
                        
                        % now evolve C backwards in time
                        cssz(1)=size(C,1);
                        cssz(2)=size(C,2);
                        C_vec_dim=prod(cssz);
                        
                        strK.FA = @(C_vec_in) edge_contract(edg{mm}, tmp_edg, ham.data{mm}, cssz, C_vec_in);
                        strK.n=C_vec_dim;
                        
                        [D]=expv_fh(1i.*dt, strK, reshape(C,[C_vec_dim 1]), expv_opts.tol, expv_opts.nkryl);
                        if expv_opts.isclean
                            D(abs(D)<mps.zero_thres*max(abs(D)))=0;
                        end
                        
                        % absorb into left matrix
                        
                        mpssz(1)=size(mps.data{mm-1},1);
                        mpssz(2)=size(mps.data{mm-1},2);
                        mpssz(3)=size(mps.data{mm-1},3);
                        
                        D=reshape(D, [cssz(1) cssz(2)]);
                        
                        tmp1=reshape(mps.data{mm-1},[mpssz(1)*mpssz(2) mpssz(3)]);
                        mps.data{mm-1}=reshape(tmp1*D,[mpssz(1) mpssz(2) cssz(2)]);
                        
                        % update edge
                        edg{mm}=tmp_edg;
                        
                        mps.qr=mps.qr-1;
                    end
                end
                
            end
            
        end        
        
        
        
        
             
        function [mps,conv,edg]=apply_tdvp_2s_sweep(mps,ham,dt,expv_opts,edg,lr)
        % Apply single sweep of TDVP. Two-site algorithm.
        
            M=size(mps.data,2);
            
            conv.trunc=zeros(1,M-1);
            
            if lr % go right
                
                for mm=1:M-1 % right sweep (mm,mm+1)=optimization sites
                    
                    [mlsz1,mlsz2,~]=size(mps.data{mm});
                    [mrsz1,~,mrsz3]=size(mps.data{mm+1});
                    
                    dblmps=merge_3Darrays(mps.data{mm},mps.data{mm+1});
                    dblmpo=merge_4Darrays(ham.data{mm},ham.data{mm+1});
                    
                    dblmps_vec_dim=numel(dblmps);

                    strH.FA = @(dblmps_vec_in) edge3_contract_AB(edg{mm},edg{mm+2},...
                        dblmpo,dblmps_vec_in,[mlsz1*mrsz1 mlsz2 mrsz3]);
                    strH.n=dblmps_vec_dim;
                    
                    % evolve local 2s matrix
                    [U]=expv_fh(-1i.*dt,strH,reshape(dblmps,dblmps_vec_dim,1),expv_opts.tol,expv_opts.nkryl);
                    if expv_opts.isclean
                        U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                    end
                    %nrmU=sqrt(U'*U);

                    % svd and truncation
                    U=reshape(U,[mlsz1 mrsz1 mlsz2 mrsz3]);
                    U=permute(U,[1 3 2 4]);
                    U=reshape(U,[mlsz1*mlsz2 mrsz1*mrsz3]);
                    
                    [L,lam,R]=svd(U,'econ');
                    lam=diag(lam);
                    R=R';
                    
                    if expv_opts.is_dyn_trunc
                        cDmax=min(length(find(lam>mps.zero_thres*max(lam))),mps.Dmax); % dynamical change of D
                    else
%                         cDmax=min(size(mps.data{mm},3),mps.Dmax); % D can only grow
                        cDmax=min(max(size(mps.data{mm},3),length(find(lam>mps.zero_thres*max(lam)))),...
                            mps.Dmax); % test it
                    end
                    conv.trunc(mm)=sum(lam((cDmax+1):end).^2);
                    
                    %L=L(:,1:cDmax)*diag(lam(1:cDmax)); 
                    L=L(:,1:cDmax);  
                    R=diag(lam(1:cDmax))*R(1:cDmax,:);
                    % absorption of lam in right right matrix creates: > ><
                    % . . < < <
                    % > . . < <
                    % > > . . <
                    % > > > . .
                    % ... at the end:
                    % > > > > ><
                    
                    L=reshape(L,[mlsz1 mlsz2 cDmax]);
                    R=reshape(R,[cDmax mrsz1 mrsz3]);
                    R=permute(R,[2 1 3]);
                    
                    % update
                    mps.data{mm}=L;
                    mps.data{mm+1}=R;
                    
                    mps.qr=mps.qr+1;
                    
                    if mm < M-1
                        % create new left edge for 1-site Hamiltonian 
                        edg{mm+1}=add_to_left_edge3_AB(edg{mm},mps.data{mm},ham.data{mm});
                        
                        % now evolve R backwards in time
                        mpssz=[mrsz1 cDmax mrsz3];
                        mps_vec_dim=prod(mpssz);
                        
                        strK.FA = @(mps_vec_in) edge3_contract_AB(edg{mm+1},edg{mm+2},ham.data{mm+1},mps_vec_in,mpssz);                
                        strK.n=mps_vec_dim;

                        % step one: evolve local matrix and make it right orthogonal
                        [U]=expv_fh(1i.*dt,strK,reshape(R,[mps_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                        if expv_opts.isclean
                            U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                        end
                        
                        mps.data{mm+1}=reshape(U,mpssz);
                        
                    end
                        
                end

            else % go left
                
                for mm=M-1:-1:1

                    [mlsz1,mlsz2,~]=size(mps.data{mm});
                    [mrsz1,~,mrsz3]=size(mps.data{mm+1});
                    
                    dblmps=merge_3Darrays(mps.data{mm},mps.data{mm+1});
                    dblmpo=merge_4Darrays(ham.data{mm},ham.data{mm+1});
                    
                    dblmps_vec_dim=numel(dblmps);
                    
                    strH.FA = @(dblmps_vec_in) edge3_contract_AB(edg{mm},edg{mm+2},...
                        dblmpo,dblmps_vec_in,[mlsz1*mrsz1 mlsz2 mrsz3]);
                    strH.n=dblmps_vec_dim;
                    
                    % evolve local 2s matrix
                    [U]=expv_fh(-1i.*dt,strH,reshape(dblmps,dblmps_vec_dim,1),expv_opts.tol,expv_opts.nkryl);
                    if expv_opts.isclean
                        U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                    end
                    %nrmU=sqrt(U'*U);

                    % svd and truncation
                    U=reshape(U,[mlsz1 mrsz1 mlsz2 mrsz3]);
                    U=permute(U,[1 3 2 4]);
                    U=reshape(U,[mlsz1*mlsz2 mrsz1*mrsz3]);
                    
                    [L,lam,R]=svd(U,'econ');
                    lam=diag(lam);
                    R=R';
                    
                    if expv_opts.is_dyn_trunc
                        cDmax=min(length(find(lam>mps.zero_thres*max(lam))),mps.Dmax); % dynamical change of D
                    else
%                         cDmax=min(size(mps.data{mm},3),mps.Dmax); % D can only grow
                        cDmax=min(max(size(mps.data{mm},3),length(find(lam>mps.zero_thres*max(lam)))),...
                            mps.Dmax); % test it
                    end
                    conv.trunc(mm)=sum(lam((cDmax+1):end).^2);
                    
                    L=L(:,1:cDmax)*diag(lam(1:cDmax)); % now: absorption in left matrix
                    R=R(1:cDmax,:);
                    
                    L=reshape(L,[mlsz1 mlsz2 cDmax]);
                    R=reshape(R,[cDmax mrsz1 mrsz3]);
                    R=permute(R,[2 1 3]);
                    
                    % update
                    mps.data{mm}=L;
                    mps.data{mm+1}=R;
                    
                    mps.qr=mps.qr-1;
                    
                    if mm > 1
                        % create new right edge for 1-site Hamiltonian (also needed later anyway)
                        edg{mm+1}=add_to_right_edge3_AB(edg{mm+2},mps.data{mm+1},ham.data{mm+1});
                        
                        % now evolve L backwards in time
                        mpssz=[mlsz1 mlsz2 cDmax];
                        mps_vec_dim=prod(mpssz);
                        
                        strK.FA = @(mps_vec_in) edge3_contract_AB(edg{mm},edg{mm+1},ham.data{mm},mps_vec_in,mpssz);                
                        strK.n=mps_vec_dim;
                        
                        % step one: evolve local matrix and make it right orthogonal
                        [U]=expv_fh(1i.*dt,strK,reshape(L,[mps_vec_dim 1]),expv_opts.tol,expv_opts.nkryl);
                        if expv_opts.isclean
                            U(abs(U)<mps.zero_thres*max(abs(U)))=0;
                        end
                        
                        mps.data{mm}=reshape(U,mpssz);
                        
                    end

                    
                end
                
            end
            
        end
        
        
        
        
        
        function [mps,edg]=sweep_qr_edge(mps,ham,edg,lr)
        % Move boundary between left and right forms of MPS and edge
        
            M=length(mps.data);
            if lr % shift right
                for mm=1:M-1
                    mps=mps.shift_qr(1);
                    edg{mm+1}=add_to_left_edge3_AB(edg{mm},mps.data{mm},ham.data{mm});
                end
            else
                for mm=M:-1:2
                    mps=mps.shift_qr(0);
                    edg{mm}=add_to_right_edge3_AB(edg{mm+1},mps.data{mm},ham.data{mm});
                end
            end
        end
        
        
        
        
        
        function [mps,trunc]=apply_loc_2s(mps,loc2op,pos,lr,nrm,isclean,is_dyn_trunc)
        % Apply local 2s gate and truncate with svd
        %
        % If lr==0, multiplication of Schmidt values to the left matrix,
        % if lr==1, multiplication of Schmidt values to the right matrix.
        %
        % If nrm==1, normalize the state.
        %
        % Messes up qr scheme, don't simply apply.  loc2op
        % has to have the form (out_left*out_right,in_left*in_right).
        %
        % NOTE: redo via merge_3Darrays and split_3Darrays
            
            
            [d0,DL0,DR0]=size(mps.data{pos});
            [d1,DL1,DR1]=size(mps.data{pos+1});
            
            LL=reshape(mps.data{pos}, [d0*DL0 DR0]);
            RR=permute(mps.data{pos+1}, [2 1 3]);
            RR=reshape(RR, [DL1 d1*DR1]);
            
            joined=reshape(LL*RR, [d0 DL0 d1 DR1]);
            joined=permute(joined, [1 3 2 4]);
            joined=reshape(joined, [d0*d1 DL0*DR1]);

            joined=reshape(loc2op*joined, [d0 d1 DL0 DR1]);
            joined=permute(joined, [1 3 2 4]);
            joined=reshape(joined, [d0*DL0 d1*DR1]);
	
            % sometimes svd doesn't converge. Cleaning the matrix from small values initially 
            % prevents this and speeds up computations in sparse-ish situations.
            if isclean
                joined(abs(joined)<mps.zero_thres*max(max(abs(joined))))=0;
            end
            if nrm==1
                joined=joined./norm(joined(:));
            end		
 		
            %[L,lam,R]=svd(joined);   
            % even with cleaning svd crashes with certain LAPACK installations. Thus it's better to use
            % the LAPACK independent svdecon.m, which relies only on eig 
            % (in tools, http://www.mathworks.com/matlabcentral/fileexchange/47132-fast-svd-and-pca/content/svdecon.m)
            % svdecon can produce NaN's for non-quadratic matrices, thus we have to remove them. 
            % !!! check svd(joined,'econ');
            [L,lam,R]=svdecon(joined);
	    
            R(~isfinite(R))=0;
            L(~isfinite(L))=0;

            lam=diag(lam);
            lam(~isfinite(lam))=0;
            R=R';
            
            if is_dyn_trunc
                cDmax=min(length(find(lam>mps.zero_thres*max(lam))),mps.Dmax); % dynamical change of D
            else
%                 cDmax=min(DR0,mps.Dmax); % D can only grow
                cDmax=min(max(DR0,length(find(lam>mps.zero_thres*max(lam)))),mps.Dmax); % test it
            end
            trunc=sum(lam((cDmax+1):end).^2);
            
            if ~lr
                % right tensor will be in the rigth canonical form
                L=L(:,1:cDmax)*diag(lam(1:cDmax));
                R=R(1:cDmax,:);
            else
                % left  tensor will be in the left  canonical form
                L=L(:,1:cDmax);
                R=diag(lam(1:cDmax))*R(1:cDmax,:);
            end
            mps.data{pos}=reshape(L,[d0 DL0 cDmax]);
            
            R=reshape(R, [cDmax d1 DR1]);
            R=permute(R, [2 1 3]);
            mps.data{pos+1}=reshape(R,[d1 cDmax DR1]);
            
        end
        
        
        
        
        
        function [mps,trunc]=swap(mps,pos,lr,isclean,is_dyn_trunc)
        % Swap two sites and truncate
        %
        % If lr==0, Schmidt values are stored in left matrix,
        % if lr==1, multiplication of Schmidt values to the right matrix.
        % 
        % Messes up qr scheme, don't simply apply. 
        %
        % NOTE: redo via merge_3Darrays and split_3Darrays
                
            [d0,DL0,DR0]=size(mps.data{pos});
            [d1,DL1,DR1]=size(mps.data{pos+1});
        
            LL=reshape(mps.data{pos}, [d0*DL0 DR0]);
            RR=permute(mps.data{pos+1}, [2 1 3]);
            RR=reshape(RR, [DL1 d1*DR1]);
            
            joined=reshape(LL*RR, [d0 DL0 d1 DR1]);
            joined=permute(joined, [3 2 1 4]);
            joined=reshape(joined, [d1*DL0 d0*DR1]);
            
            % sometimes svd doesn't converge. Cleaning the matrix from small values initially
            % prevents this and speeds up computations in sparse-ish situations.
            if isclean
                joined(abs(joined)<mps.zero_thres*max(max(abs(joined))))=0;
            end
            
            % !!! check svd(joined,'econ');
            %[L,lam,R]=svd(joined);
            [L,lam,R]=svdecon(joined);

            R(~isfinite(R))=0;
            L(~isfinite(L))=0;
	    
            lam=diag(lam);   
            lam(~isfinite(lam))=0;
            R=R';
            
            if is_dyn_trunc
                cDmax=min(length(find(lam>mps.zero_thres*max(lam))),mps.Dmax); % dynamical change of D
            else
                cDmax=min(mps.Dmax,DR0); % D can only grow
            end
            trunc=sum(lam((cDmax+1):end).^2);
            
            if ~lr
                L=L(:,1:cDmax)*diag(lam(1:cDmax));
                R=R(1:cDmax,:);
            else
                L=L(:,1:cDmax);
                R=diag(lam(1:cDmax))*R(1:cDmax,:);
            end
            mps.data{pos}=reshape(L,[d0 DL0 cDmax]);
            
            R=reshape(R, [cDmax d1 DR1]);
            R=permute(R, [2 1 3]);
            mps.data{pos+1}=reshape(R,[d1 cDmax DR1]);

            
        end
        
        
        
        
        
        function [mps,schmidt]=shift_qr(mps,lr)
        % Move boundary between left-/right-canonical forms of MPS
        %
        % If lr==1, move to right (qr=qr+1), 
        % if lr==0, more to left (qr=qr-1).
        %
        % See definition of qr.
        %
        % Requirement: 0 <= mps.qr <= M-1
        
            M=length(mps.data);
            datind=mps.qr+1;
            
            if lr % shift right

                if mps.qr==(M-1)
                    error('mps.shift_qr, already at right edge');
                end
                
                [d, DL, DR] =size(mps.data{datind});
                [dR,DRL,DRR]=size(mps.data{datind+1});
                
                [Q,R]=qr(reshape(mps.data{datind},d*DL,DR),0);
                schmidt=svd(R);
                
                nDR=size(R,1); % it can happen that d*DL<DR ... in that case we have to update DR
                mps.data{datind}=reshape(Q,d,DL,nDR);

                tmp=R*reshape(permute(mps.data{datind+1},[2 1 3]),DRL,dR*DRR);
                mps.data{datind+1}=permute(reshape(tmp,nDR,dR,DRR),[2 1 3]);
                
                mps.qr=mps.qr+1;
            
            else % shift left

                if mps.qr==0
                    error('mps.shift_qr, already at left edge');
                end
                
                [d, DL, DR] =size(mps.data{datind-1});
                [dR,DRL,DRR]=size(mps.data{datind});
                
                tmp1=permute(mps.data{datind},[2 1 3]);
                tmp1=reshape(tmp1,[DRL dR*DRR]);
                tmp1=permute(tmp1,[2 1]);

                [Q,R]=qr(tmp1,0);
                schmidt=svd(R);
                
                % it can happen that dR*DRR<DRL ... in that case we have to update DRL
                nDRL=size(R,1);

                Q=permute(Q, [2 1]);
                Q=reshape(Q, [nDRL dR DRR]);
                mps.data{datind}=permute(Q,[2 1 3]);
                
                R=permute(R,[2 1]);
                tmp1=reshape(mps.data{datind-1},[d*DL nDRL]);
                mps.data{datind-1}=reshape(tmp1*R,[d DL nDRL]);
                
                mps.qr=mps.qr-1;

            end
            
        end

    end
        
end
