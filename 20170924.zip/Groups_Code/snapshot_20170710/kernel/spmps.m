classdef mps
   
    properties (SetAccess=public)
    end
    
    
    properties (SetAccess=protected)

        Dmax        % max allowed bond dimension
        data        % matrix data
        qr          % indicates the bond of the the change between left/right orthogonal (default=0)
        zero_thres  % threshold of what is considered zero
    
    end
    

    methods
       
        function mps = mps(M,Dmax)

            mps.Dmax=Dmax;
            mps.data=cell(1,M);
            mps.zero_thres=1e-14;
            mps.qr=-1;
            
        end
        
        
        function mps=set_state(mps,vec,pos)
            
            M=size(mps.data,2);
            d=length(vec);
            
            Dmaxvec=ones(1,M+1);
            for bb=1:M
                Dmaxvec(bb+1)=min(Dmaxvec(bb).*d,mps.Dmax);
            end
            
            fr=round(M/2);
            if mod(M,2)
                Dmaxvec((fr+1):(M+1))=fliplr(Dmaxvec(1:fr));
            else
                Dmaxvec((fr+2):(M+1))=fliplr(Dmaxvec(1:fr));
            end
                        
            for pp=pos
                tmp_mat=zeros(size(vec,1),Dmaxvec(pp),Dmaxvec(pp+1));
                tmp_mat(:,1,1)=vec;
                %tmp_mat=single(tmp_mat);
                %import edu.stanford.covert.util.SparseMat;
                tmp_mat=SparseMat(tmp_mat);
                mps.data{pp}=tmp_mat;
            end
            mps.qr=0;
        end
        
        
        function vals=schmidt(mps)
           
            M=length(mps.data);
            for mm=1:(M-1)
                [mps vals{mm}]=mps.shift_qr(1);
            end
        
        end
        
        
        function expc=corr_mat_herm(mps,op1,op2)
            
            M=size(mps.data,2);
            expc=diag(mps.loc_expc(op1*op2))./2;
            
            for mm=2:M
                expc(mm,1:(mm-1))=mps.corr_line(op1,op2,mm);
            end
            
            expc=expc+expc';
            
        end
        
        
        function expc=corr_line(mps,op1,op2,op2idx)
            
            expc=zeros(1,op2idx-1);

            mm=op2idx;
            
            for nn=1:mm-1
                mps=mps.shift_qr(1);
            end
                
            mpssz(1)=size(mps.data{mm},1);
            mpssz(2)=size(mps.data{mm},2);
            mpssz(3)=size(mps.data{mm},3);
            tmp1=reshape(mps.data{mm},[mpssz(1) mpssz(2)*mpssz(3)]);
            tmp1=reshape(op2*tmp1,[mpssz(1) mpssz(2) mpssz(3)]);
            
            edg=eye(mpssz(3));
            edg=add_to_right_edge2(edg,mps.data{mm},tmp1);
            
            for mm=(op2idx-1):-1:1

                mpssz(1)=size(mps.data{mm},1);
                mpssz(2)=size(mps.data{mm},2);
                mpssz(3)=size(mps.data{mm},3);
                tmp1=reshape(mps.data{mm},[mpssz(1) mpssz(2)*mpssz(3)]);
                tmp1=reshape(op1*tmp1,[mpssz(1) mpssz(2) mpssz(3)]);
                
                eval_edg=add_to_right_edge2(edg,mps.data{mm},tmp1);
                expc(mm)=trace(eval_edg);
                
                edg=add_to_right_edge2(edg,mps.data{mm},mps.data{mm});
                
            end
            
            if min(imag(expc))<mps.zero_thres
                expc=real(expc);
            end
                
        end

        
        
        function expc=loc_expc(mps,locop)
            
            M=size(mps.data,2);
            
            for pos=1:M;
                
                d=size(mps.data{pos},1);
                DL=size(mps.data{pos},2);
                DR=size(mps.data{pos},3);
                tmp=sparse(reshape(mps.data{pos},d, DL*DR));
                expc(pos)=trace(tmp'*locop*tmp);
                if pos<M
                    mps=mps.shift_qr(1);
                end
            end
            
            if min(imag(expc))<mps.zero_thres
                expc=real(expc);
            end
                
        end
        
        
        function [mps conv]=dmrg_1s_sweep(mps,varargin)
            

            if nargin==2
                ham=varargin{1};
                eigs_opts.issym=1;
                eigs_opts.isreal=1;
                %eigs_opts.disp=2;
            elseif nargin==3
                ham=varargin{1};
                eigs_opts=varargin{2};
                eigs_opts.issym=1;
                eigs_opts.isreal=1;
            end
                
            M=size(mps.data,2);
            sweep_en.r=zeros(1,M-1);
            sweep_en.l=zeros(1,M);
            flags.r=zeros(1,M-1);
            flags.l=zeros(1,M);
            
            % create edges
            edg{M+1}=ones(1,1,1);
            for mm=M:-1:2
                edg{mm}=add_to_right_edge3(edg{mm+1},mps.data{mm},ham.data{mm});
            end
            edg{1}=ones(1,1,1);
            
            for mm=1:(M-1); % right sweep mm=optimization site
            
                mpssz(1)=size(mps.data{mm},1);
                mpssz(2)=size(mps.data{mm},2);
                mpssz(3)=size(mps.data{mm},3);
                mps_vec_dim=prod(mpssz);
                

                F = @(mps_vec_in) mpo_edge_contract(edg{mm},edg{mm+1},ham.data{mm}, mpssz, mps_vec_in);
               
                %eigs_opts.v0=reshape(mps.data{mm},[mps_vec_dim 1]);
                %eigs_opts.v0=ones(mps_vec_dim,1);
                [U V flags.r(mm)]=eigs(F,mps_vec_dim, 1, 'sa', eigs_opts);
                sweep_en.r(mm)=V;
                U(find(abs(U)<mps.zero_thres))=0;
                
                U=reshape(U,[mpssz(1)*mpssz(2) mpssz(3)]);
                [Q C]=qr(sparse(U),0);

                mps.data{mm}=SparseMat(reshape(Q,mpssz));
                mps.qr=mps.qr+1;
                % C can be thrown away
                
                % build new edge
                edg{mm+1}=add_to_left_edge3(edg{mm},mps.data{mm},ham.data{mm});
                
            end
            
            % left sweep
            for mm=M:-1:1

                mpssz(1)=size(mps.data{mm},1);
                mpssz(2)=size(mps.data{mm},2);
                mpssz(3)=size(mps.data{mm},3);
                mps_vec_dim=prod(mpssz);
                

                F = @(mps_vec_in) mpo_edge_contract(edg{mm},edg{mm+1},ham.data{mm}, mpssz, mps_vec_in);
                
                %eigs_opts.v0=reshape(mps.data{mm},[mps_vec_dim 1]);
                %eigs_opts.v0=ones(mps_vec_dim,1);
                [U V flags.l(mm)]=eigs(F,mps_vec_dim, 1, 'sa', eigs_opts);
                sweep_en.l(mm)=V;
                U(find(abs(U)<mps.zero_thres))=0;
                
                U=reshape(U,mpssz);
                U=permute(U,[2 1 3]);
                U=reshape(U,[mpssz(2) mpssz(1)*mpssz(3)]);
                [Q C]=qr(sparse(U'),0);
                
                % Q is unitary and has the form (d rD x lD)
                Q=reshape(Q,[mpssz(1) mpssz(3) mpssz(2)]);
                mps.data{mm}=SparseMat(permute(Q,[1 3 2]));
                
                if mm>1
                    edg{mm}=add_to_right_edge3(edg{mm+1},mps.data{mm},ham.data{mm});
                    mps.qr=mps.qr-1;
                end
            end
            
            
            conv.sweep_en=[sweep_en.r fliplr(sweep_en.l)];
            conv.sweep_eigs_flags=[flags.r fliplr(flags.l)];
            
        end
        

        function [mps conv]=tdvp_trotter(mps,ham,dt,expv_opts,order)
            
        
            M=size(mps.data,2);
            
            % create edges
            edg{M+1}=ones(1,1,1);
            for mm=M:-1:2
                edg{mm}=add_to_right_edge3(edg{mm+1},mps.data{mm},ham.data{mm});
            end
            edg{1}=ones(1,1,1);
            
            if order==1
                [mps conv edg]=mps.tdvp_sweep(ham,dt,expv_opts,edg,1);
                for mm=M:-1:2
                    mps=mps.shift_qr(0);
                end
            elseif order==2
                dt=dt/2;
                [mps conv edg]=mps.tdvp_sweep(ham,dt,expv_opts,edg,1);
                [mps conv edg]=mps.tdvp_sweep(ham,dt,expv_opts,edg,0);
            elseif order==4
                dt1=dt/12; 
                dt2=-dt/6;
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1T)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps conv edg]=mps.tdvp_sweep(ham,dt2,expv_opts,edg,0); % (2)T
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps edg]=mps.sweep_qr_edge(ham,edg,0);                 % (id)T  
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps edg]=mps.sweep_qr_edge(ham,edg,0);                 % (id)T  
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps edg]=mps.sweep_qr_edge(ham,edg,0);                 % (id)T  
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps edg]=mps.sweep_qr_edge(ham,edg,1);                 % (id)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps edg]=mps.sweep_qr_edge(ham,edg,1);                 % (id)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps edg]=mps.sweep_qr_edge(ham,edg,1);                 % (id)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps conv edg]=mps.tdvp_sweep(ham,dt2,expv_opts,edg,1); % (2)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1)T
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,1); % (1)
                [mps conv edg]=mps.tdvp_sweep(ham,dt1,expv_opts,edg,0); % (1)T
            else
                error('tdvp_sweep: use order=1,2,4')
            end
        
        end
        
        
    end
   

    

    
    methods (Access=protected)
        
        
        
        function [mps conv edg]=tdvp_sweep(mps,ham,dt,expv_opts,edg,lr)

            M=size(mps.data,2);
            
            if lr % go right
                
                conv.errH=zeros(1,M-1);
                conv.errK=zeros(1,M-1);
                conv.humpH=zeros(1,M-1);
                conv.humpK=zeros(1,M-1);
                
                for mm=1:M; % right sweep mm=optimization site
                
                    mpssz(1)=size(mps.data{mm},1);
                    mpssz(2)=size(mps.data{mm},2);
                    mpssz(3)=size(mps.data{mm},3);
                    mps_vec_dim=prod(mpssz);
                
                    strH.FA = @(mps_vec_in) mpo_edge_contract(edg{mm},edg{mm+1},ham.data{mm}, mpssz, mps_vec_in);
                    strH.n=mps_vec_dim;
                    
                    % step one: evolve local matrix and make it right orthogonal
                    [U conv.errH(mm) conv.humpK(mm)]=expv_fh(-1i.*dt, strH, reshape(mps.data{mm},[mps_vec_dim 1]), expv_opts.tol, expv_opts.nkryl);
                    
                    %U(find(abs(U)<mps.zero_thres))=0;
                    U=reshape(U,[mpssz(1)*mpssz(2) mpssz(3)]);
                    [Q C]=qr(sparse(U),0);
                    
                    % update
                    mps.data{mm}=SparseMat(reshape(Q,mpssz));
                    
                    % create new left edge for 0-site Hamiltonian (also needed later anyway)
                    tmp_edg=add_to_left_edge3(edg{mm},mps.data{mm},ham.data{mm});
                    
                    % now evolve C backwards in time
                    cssz(1)=size(C,1);
                    cssz(2)=size(C,2);
                    C_vec_dim=prod(cssz);
                
                    strK.FA = @(C_vec_in) edge_contract(tmp_edg, edg{mm+1}, ham.data{mm}, cssz , C_vec_in);
                    strK.n=C_vec_dim;
                    
                    [D conv.errK(mm) conv.humpK(mm)]=expv_fh(1i.*dt, strK, reshape(C,[C_vec_dim 1]), expv_opts.tol, expv_opts.nkryl);
                    
                    % absorb into right matrix
                    if mm<M
                        mpssz(1)=size(mps.data{mm+1},1);
                        mpssz(2)=size(mps.data{mm+1},2);
                        mpssz(3)=size(mps.data{mm+1},3);
                        
                        D=reshape(D, [cssz(1) cssz(2)]);
                        
                        tmp1=permute(mps.data{mm+1},[2 1 3]);
                        tmp1=reshape(tmp1,[mpssz(2) mpssz(1)*mpssz(3)]);
                        tmp1=reshape(D*tmp1,[cssz(1) mpssz(1) mpssz(3)]);
                        mps.data{mm+1}=SparseMat(permute(tmp1, [2 1 3]));
                        
                        % update edge
                        edg{mm+1}=tmp_edg;
                        mps.qr=mps.qr+1;
                    end
                    
                end

            else % go left
                
                for mm=M:-1:1

                    mpssz(1)=size(mps.data{mm},1);
                    mpssz(2)=size(mps.data{mm},2);
                    mpssz(3)=size(mps.data{mm},3);
                    mps_vec_dim=prod(mpssz);
                    
                    strH.FA = @(mps_vec_in) mpo_edge_contract(edg{mm},edg{mm+1},ham.data{mm}, mpssz, mps_vec_in);
                    strH.n=mps_vec_dim;
                    
                    % step one: evolve local matrix and make it left orthogonal
                    U=expv_fh(-1i.*dt, strH, reshape(mps.data{mm},[mps_vec_dim 1]), expv_opts.tol, expv_opts.nkryl);
                    %U(find(abs(U)<mps.zero_thres))=0;
                    
                    U=reshape(U,mpssz);
                    U=permute(U,[2 1 3]);
                    U=reshape(U,[mpssz(2) mpssz(1)*mpssz(3)]);
                    
                    U=permute(U,[2 1]);
                    [Q C]=qr(sparse(U),0);
                    Q=permute(Q,[2 1]);
                    C=permute(C,[2 1]);

                    % update
                    Q=reshape(Q,[mpssz(2) mpssz(1) mpssz(3)]);
                    mps.data{mm}=SparseMat(permute(Q,[2 1 3]));
                    
                    % create new right edge for 0-site Hamiltonian (also needed later anyway)
                    tmp_edg=add_to_right_edge3(edg{mm+1},mps.data{mm},ham.data{mm});
                    
                    % now evolve C backwards in time
                    cssz(1)=size(C,1);
                    cssz(2)=size(C,2);
                    C_vec_dim=prod(cssz);
                    
                    strK.FA = @(C_vec_in) edge_contract(edg{mm}, tmp_edg, ham.data{mm}, cssz, C_vec_in);
                    strK.n=C_vec_dim;
                    
                    [D conv.errK conv.humpK]=expv_fh(1i.*dt, strK, reshape(C,[C_vec_dim 1]), expv_opts.tol, expv_opts.nkryl);
                    
                    % absorb into left matrix
                    if mm>1
                        mpssz(1)=size(mps.data{mm-1},1);
                        mpssz(2)=size(mps.data{mm-1},2);
                        mpssz(3)=size(mps.data{mm-1},3);
                        
                        D=reshape(D, [cssz(1) cssz(2)]);
                        
                        tmp1=reshape(mps.data{mm-1},[mpssz(1)*mpssz(2) mpssz(3)]);
                        mps.data{mm-1}=SparseMat(reshape(tmp1*D,[mpssz(1) mpssz(2) cssz(2)]));
                        
                        % update edge
                        edg{mm}=tmp_edg;
                        
                        mps.qr=mps.qr-1;
                    end
                end
                
            end
            
        end
        
        
        function [mps edg]=sweep_qr_edge(mps,ham,edg,lr)
            
            M=length(mps.data);
            if lr % shift right
                for mm=1:M-1
                    mps=mps.shift_qr(1);
                    edg{mm+1}=add_to_left_edge3(edg{mm},mps.data{mm},ham.data{mm});
                end
            else
                for mm=M:-1:2
                    mps=mps.shift_qr(0);
                    edg{mm}=add_to_right_edge3(edg{mm+1},mps.data{mm},ham.data{mm});
                end
            end
        end
        
        function [mps schmidt]=shift_qr(mps,lr)
            
            M=length(mps.data);
            datind=mps.qr+1;
            
            if lr % shift right

                if mps.qr==(M-1)
                    error('mps.shift_qr, already at right edge');
                end
                
                d=size(mps.data{datind},1);
                DL=size(mps.data{datind},2);
                DR=size(mps.data{datind},3);
                
                dR=size(mps.data{datind+1},1);
                DRL=size(mps.data{datind+1},2);
                DRR=size(mps.data{datind+1},3);
                
                [Q R]=qr(sparse(reshape(mps.data{datind},d*DL,DR)),0);
                schmidt=svd(full(R));
                
                
                mps.data{datind}=SparseMat(reshape(full(Q),d,DL,DR));
                
                tmp=R*reshape(permute(mps.data{datind+1},[2 1 3]),DRL,dR*DRR);
                mps.data{datind+1}=SparseMat(permute(reshape(tmp,DRL,dR,DRR),[2 1 3]));
                
                mps.qr=mps.qr+1;
            
            else % shift left

                if mps.qr==0
                    error('mps.shift_qr, already at left edge');
                end
                
                d=size(mps.data{datind-1},1);
                DL=size(mps.data{datind-1},2);
                DR=size(mps.data{datind-1},3);
                
                dR=size(mps.data{datind},1);
                DRL=size(mps.data{datind},2);
                DRR=size(mps.data{datind},3);
                
                tmp1=permute(mps.data{datind},[2 1 3]);
                tmp1=reshape(tmp1,[DRL dR*DRR]);
                tmp1=permute(tmp1,[2 1]);

                [Q R]=qr(sparse(tmp1),0);
                schmidt=svd(R);

                Q=permute(Q, [2 1]);
                Q=reshape(Q, [DRL dR DRR]);
                mps.data{datind}=SparseMat(permute(Q,[2 1 3]));
                
                R=permute(R,[2 1]);
                tmp1=reshape(mps.data{datind-1},[d*DL DR]);
                mps.data{datind-1}=SparseMat(reshape(tmp1*R,[d DL DR]));
                
                mps.qr=mps.qr-1;

            end
            
        end

    end
        
end