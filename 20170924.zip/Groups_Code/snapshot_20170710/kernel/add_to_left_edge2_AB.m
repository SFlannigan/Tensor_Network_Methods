function le_out = add_to_left_edge2_AB(le_in,mpsmatA,mpsmatB)
% Contract left edge with two 3D arrays, <B|A>
%
% If B is not provided replaces it with conj(A).
%
% NOTE: this funciton reproduces a basic overlab <B|A>, but B array 
% should be conjugated beforehand!
% This reversed order is chosen, so as to avoid misunderstanding when
% providing only one 3D array.
% 
% Contraction scheme:
% +----+    +---+   
% |    |2  2| A |3  
% |    |    +---+   
% |    |      1     
% | le |            
% |    |      1     
% |    |    +---+   
% |    |1  2| B |3  
% +----+    +---+   
%
% Benchmarking:
% addpath('./kernel/')
% addpath('./tools/')
% le_in = rand(12,11);
% mpsmatA = rand(10,11,11)+1i*rand(10,11,11);
% mpsmatB = rand(10,12,12)+1i*rand(10,12,12);
% le_out = add_to_left_edge2_AB(le_in,mpsmatA,mpsmatB);
% le_out_ncon = ncon({le_in,mpsmatA,mpsmatB},{[1 2],[3 2 -2],[3 1 -1]},[1 2 3]);
% % % one 3D array
% % le_in = rand(11,11);
% % le_out = add_to_left_edge2_AB(le_in,mpsmatA);
% % le_out_ncon = ncon({le_in,mpsmatA,conj(mpsmatA)},{[1 2],[3 2 -2],[3 1 -1]},[1 2 3]);
% max(max(abs((le_out-le_out_ncon)./le_out)))

if nargin==2
    mpsmatB=conj(mpsmatA);
end

% A/B sizes
[szA1,szA2,szA3]=size(mpsmatA);
[szB1,szB2,szB3]=size(mpsmatB);

tmp1=permute(mpsmatB, [3 1 2]);
tmp1=reshape(tmp1, [szB3*szB1 szB2]);
tmp1=reshape(tmp1*le_in, [szB3 szB1 szA2]);
tmp1=reshape(tmp1, [szB3 szB1*szA2]);


tmp2=reshape(mpsmatA, [szA1*szA2 szA3]);

le_out=tmp1*tmp2;

end