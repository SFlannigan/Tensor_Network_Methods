function C_vec_out = edge_contract(le, re, mpomat, cssz, C_vec_in)
% USED BUT CLEARLY UNFINSHED FUNCTION
% mpomat is unused, unless you haven't finished TDVP

Cmat=reshape(C_vec_in,cssz);

mposz(1)=size(mpomat,1);
mposz(2)=size(mpomat,2);
mposz(3)=size(mpomat,3);
mposz(4)=size(mpomat,4);

lesz(1)=size(le,1); 
lesz(2)=size(le,2); 
lesz(3)=size(le,3);

resz(1)=size(re,1); 
resz(2)=size(re,2); 
resz(3)=size(re,3);


tmp1=reshape(le,[lesz(1)*lesz(2) lesz(3)]);
tmp1=reshape(tmp1*Cmat, [lesz(1) lesz(2)*cssz(2)]);

tmp2=reshape(re, [resz(1) resz(2)*resz(3)]);
tmp2=permute(tmp2,[2 1]);

C_vec_out=reshape(tmp1*tmp2, [cssz(1)*cssz(2) 1]);

end