function nr_out = edge3_sandwich_AB(le_in,re_in,mps_in_A,mpo_in,mps_in_B)
% Contract left and right edges with two 3D arrays and one 4D array
%
% If B is not provided replaces it with conj(A).
%
% NOTE: this funciton reproduces a basic overlab <B|O|A>, but B array 
% should be conjugated beforehand!
% This reversed order is chosen, so as to avoid misunderstanding when
% providing only one 3D array.
%  
% Contraction scheme:
% +----+    +---+    +----+
% |    |3  2| A |3  3|    |
% |    |    +---+    |    |
% |    |      1      |    |
% |    |             |    |
% |    |      2      |    |
% |    |    +---+    |    |
% | le |2  3|mpo|4  2| re |
% |    |    +---+    |    |
% |    |      1      |    |
% |    |             |    |
% |    |      1      |    |
% |    |    +---+    |    |
% |    |1  2| B |3  1|    |
% +----+    +---+    +----+
%
% Benchmarking:
% addpath('./tools/')
% re_in = rand(12,7,11);
% le_in = rand(12,7,11);
% mps_in_A = rand(10,11,11)+1i*rand(10,11,11);
% mps_in_B = rand(10,12,12)+1i*rand(10,12,12);
% mpo_in = rand(10,10,7,7)+1i*rand(10,10,7,7);
% nr_out = edge3_sandwich_AB(le_in,re_in,mps_in_A,mpo_in,mps_in_B);
% nr_out_ncon = ncon({le_in,re_in,mps_in_A,mpo_in,mps_in_B},...
%     {[6 7 8],[1 2 3],[5 8 3],[4 5 7 2],[4 6 1]},[1 2 4 3 5 6 7 8]);
% max(max(max(abs((nr_out-nr_out_ncon)./nr_out))))
    
    if nargin==4
        tmp1=add_to_right_edge3_AB(re_in,mps_in_A,mpo_in);
    else
        tmp1=add_to_right_edge3_AB(re_in,mps_in_A,mpo_in,mps_in_B);
    end
    
    tmp1=reshape(tmp1, [numel(tmp1) 1]);
    tmp2=reshape(le_in, [1 numel(le_in)]);
    nr_out=tmp2*tmp1;
    
end