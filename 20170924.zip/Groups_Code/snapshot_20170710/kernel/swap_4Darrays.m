function [Anew,Bnew,trunc]=swap_4Darrays(A,B,lrschmidt,Dmax)
% Swap two 4D arrays and truncate if needed
%
% Contraction scheme:
%      2A           2B
%    +----+       +----+
%  3A| A  |4A - 3B| B  |4B
%    +----+       +----+
%      1A           1B
%
% TO
%
%      2B           2A
%    +----+       +----+
%  3A|Anew|4a - 3b|Bnew|4B
%    +----+       +----+
%      1B           1A
%
% size(4A)==size(3B) and in general is not equal to size(4a)==size(3b)
% If Dmax is defined, then truncate the middle dimension
%
% If lrschmidt==1, merge Schmidt coefficients into Anew (Bnew is right-canonical),
% if lrschmidt==0, merge Schmidt coefficients into Bnew (Anew is  left-canonical)

[dout_A,din_A,DL_A,DR_A]=size(A); 
[dout_B,din_B,DL_B,DR_B]=size(B); 

A=reshape(A,[dout_A*din_A DL_A DR_A]);
B=reshape(B,[dout_B*din_B DL_B DR_B]);

if nargin==3
    [Anew,Bnew,trunc]=swap_3Darrays(A,B,lrschmidt);
elseif nargin==4
    [Anew,Bnew,trunc]=swap_3Darrays(A,B,lrschmidt,Dmax);
else
    error('ERROR: wrong number of arguments')
end

Anew=reshape(Anew,dout_B,din_B,DL_A,[]);
Bnew=reshape(Bnew,dout_A,din_A,[],DR_B);
    
end