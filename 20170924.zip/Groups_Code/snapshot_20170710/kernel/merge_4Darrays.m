function AB=merge_4Darrays(A,B)
% Contract two 4D arrays in the middle and merge parallel indices
%
% Contraction scheme:
%     2        2
%   +---+    +---+
%  3| A |4  3| B |4
%   +---+    +---+
%     1        1
%
% TO
%
%     22
%   +----+  
%  3| AB |4 
%   +----+  
%     11
%
% Benchmarking:
% addpath('./tools/')
% addpath('./kernel/')
% A = rand(20,20,10,11);
% B = rand(20,20,11,12);
% AB = merge_4Darrays(A,B);
% AB_ncon = reshape(ncon({A,B}, {[-1 -3 -5 1],[-2 -4 1 -6]}),[20^2 20^2 10 12]);
% max(max(max(max(abs((AB-AB_ncon)./AB)))))

[dout_A,din_A,DL_A,DR_A]=size(A); 
[dout_B,din_B,DL_B,DR_B]=size(B); 

AB = reshape(A,[dout_A*din_A*DL_A DR_A]);

tmp = permute(B,[3 1 2 4]);
tmp = reshape(tmp,[DL_B dout_B*din_B*DR_B]);

AB = reshape(AB*tmp, [dout_A din_A DL_A dout_B din_B DR_B]);
AB = permute(AB, [1 4 2 5 3 6]);
AB = reshape(AB, [dout_A*dout_B din_A*din_B DL_A DR_B]);
    
end