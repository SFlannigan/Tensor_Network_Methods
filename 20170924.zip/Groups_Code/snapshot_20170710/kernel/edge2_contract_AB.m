function mps_out = edge2_contract_AB(le2_in,re2_in,mps_in,mpssz)
% Contract left and right edges with only one 3D tensor,
% the other one is its output
%
% If mps_in is given in a form of a column, its sizes must be providet
% (it's needed for using this function for eigs,expv,etc.).
%
% Note: input and output tensor can have different sizes
%
% Contraction scheme:
% +----+    +---+    +----+
% |    |2  2|in |3  2|    |
% |    |    +---+    |    |
% |    |      1      |    |
% | le |             | re |
% |    |     -1      |    |
% |    |    +---+    |    |
% |    |1 -2|out|-3 1|    |
% +----+    +---+    +----+
%
% Benchmarking:
% addpath('./tools/')
% addpath('./kernel/')
% re2_in = rand(12,11);
% le2_in = rand(12,11);
% mps_in = rand(10,11,11)+1i*rand(10,11,11);
% % if given a 3D array
% mps_out = edge2_contract_AB(le2_in,re2_in,mps_in);
% mps_out_ncon = ncon({le2_in,re2_in,mps_in},{[-2 1],[-3 2],[-1 1 2]});
% max(max(max(abs((mps_out-mps_out_ncon)./mps_out))))
% % if given a column
% mps_out = edge2_contract_AB(le2_in,re2_in,reshape(mps_in,[numel(mps_in) 1]),size(mps_in));
% mps_out_ncon = reshape(ncon({le2_in,re2_in,mps_in},{[-2 1],[-3 2],[-1 1 2]}),[1440 1]);
% max(max(max(abs((mps_out-mps_out_ncon)./mps_out))))

if nargin==4
    % in this case input is a column, which to be reshaped to the 3D array 
    % output should be reshaped in a column accordingly
    mps_in=reshape(mps_in,mpssz);
end

% sizes
[mpssz1,mpssz2,mpssz3]=size(mps_in);
le2sz1=size(le2_in,1);
re2sz1=size(re2_in,1);

tmp1=permute(mps_in,[2 1 3]);
tmp1=reshape(tmp1,[mpssz2 mpssz1*mpssz3]);

tmp1=reshape(le2_in*tmp1,[le2sz1*mpssz1 mpssz3]);

tmp1=reshape(tmp1*re2_in.' ,[le2sz1 mpssz1 re2sz1]);

mps_out=permute(tmp1,[2 1 3]);

if nargin==4
    mps_out=reshape(mps_out,[numel(mps_out) 1]);
end

end