classdef mpo
% Matrix Product Operator Class
%
% Ref: e.g. New J. Phys. 14 125015, chapter 2.2
%
% To do:
%     - check all DOUBLECHECK methods
%     - group methods, like set-functions (nn and lr), add functions, other

    properties (SetAccess=protected)

        % Matrix data
        %
        % Cell array of M elements (for M sites). Each element is a 4D
        % array d_output x d_input x D_left x D_right.
        % d_output x d_input - dimensions of operators (both equals d)
        % D_left and D_right - row and column dimensions
        data        
        
        % Threshold of what is considered zero
        zero_thres

    end



    methods
        
        function mpo = mpo(M)
        % Class constructor
        
            mpo.data=cell(1,M);
            mpo.zero_thres=1e-14;
            
        end
        
        
        
        
        
        function mat=get_mpo_in_standard_basis(mpo)
        % Return matrix in standard basis equivalent of MPO 
        % 
        % IMPORTANT: don't use for large systems
        
            M=size(mpo.data,2);
            d=size(mpo.data{1},1);
        
            if d^M > 2^11
                error('WARNING:get_mpo_in_standard_basis: too many calculations');
            end
            
            mat = zeros(d^M,d^M);

            for iIn = 1:d^M
                for iOut = 1:d^M
                    strIn = dec2base(iIn-1, d, M);
                    strOut = dec2base(iOut-1, d, M);
                    matElement = 1;
                    for iM = 1:M
                        indIn  = str2double(strIn(1))  + 1;
                        indOut = str2double(strOut(1)) + 1;
                        strIn(1)  = [];
                        strOut(1) = [];
                        matElement = matElement*permute(mpo.data{iM}(indOut,indIn,:,:),[3 4 1 2]);
                    end
                    mat(iOut,iIn) = matElement;   
                end
            end
            
        end        
        
        
        
        
        
        function mpo=set_suma(mpo,a)
        % Set MPO = \sum a_i 
        %
        % a can be a single dxd matrix or a dxdxM array
        %
        % DOUBLECHECK
            
            M=length(mpo.data);
            d=size(a,1);
            
            if size(a,3)==1
                aten=repmat(a,1,1,M);
            elseif size(a,3)==M;
                aten=a;
            else
                error('ERROR: a needs to be a dxd matrix or a dxdxM array');
            end
            
            for mm=1:M
                mpo.data{mm}=zeros(d,d,2,2);
                mpo.data{mm}(:,:,1,1)=eye(d,d);
                mpo.data{mm}(:,:,2,2)=eye(d,d);
                mpo.data{mm}(:,:,2,1)=aten(:,:,mm);
            end
            
            mpo.data{1}=mpo.data{1}(:,:,end,:); 
            mpo.data{M}=mpo.data{M}(:,:,:,1); 
            
        end        
        
        
        
        
        
        function mpo=set_proda(mpo,a)
        % Set MPO = \prod a_i
        %
        % a can be a single dxd matrix or a dxdxM array
        %
        % DOUBLECHECK
        
            d=size(a,1);
            M=length(mpo.data);
            
            if size(a,3)==1
                aten=repmat(a,1,1,M);
            elseif size(a,3)==M;
                aten=a;
            else
                error('ERROR: a needs to be a dxd matrix or a dxdxM array');
            end
            
            for mm=1:M
                mpo.data{mm}=zeros(d,d,1,1);
                mpo.data{mm}(:,:,1,1)=aten(:,:,mm);
            end
            
        end
        
        
        
        
        
        function mpo=set_sumab_sumc(mpo,a,b,c)
        % Set MPO = \sum(a_i b_{i+1}) + \sum c_i
        %
        % c can be a single dxd matrix or a dxdxM array
            
            d=size(a,1);
            M=length(mpo.data);
            
            if size(c,3)==1
                cten=repmat(c,1,1,M);
            elseif size(c,3)==M;
                cten=c;
            else
                error('ERROR: c needs to be a dxd matrix or a dxdxM array');
            end
            
            for mm=1:M
                mpo.data{mm}=zeros(d,d,3,3);
                mpo.data{mm}(:,:,1,1)=eye(d,d);
                mpo.data{mm}(:,:,2,1)=a;
                mpo.data{mm}(:,:,3,1)=cten(:,:,mm);
                mpo.data{mm}(:,:,3,2)=b;
                mpo.data{mm}(:,:,3,3)=eye(d,d);
            end
            
            mpo.data{1}=mpo.data{1}(:,:,end,:); 
            mpo.data{M}=mpo.data{M}(:,:,:,1); 
            
        end
        
        
        
        
        
        function mpo=set_n1sumab_n2sumba_sumc(mpo,a,b,c,n1,n2)
        % Set MPO = \sum(n1 a_i b_{i+1} + n2 b_i a_{i+1}) + \sum c_i
        %
        % c can be a single dxd matrix or a dxdxM array
        % n1,n2 --- scalars
        
            d=size(a,1);
            M=length(mpo.data);
            
            if size(c,3)==1
                cten=repmat(c,1,1,M);
            elseif size(c,3)==M;
                cten=c;
            else
                error('ERROR: c needs to be a dxd matrix or a dxdxM array');
            end
            
            for mm=1:M
                mpo.data{mm}=zeros(d,d,4,4);
                mpo.data{mm}(:,:,1,1)=eye(d,d);
                mpo.data{mm}(:,:,2,1)=a;
                mpo.data{mm}(:,:,3,1)=b;
                mpo.data{mm}(:,:,4,1)=cten(:,:,mm);
                mpo.data{mm}(:,:,4,2)=n2*b;
                mpo.data{mm}(:,:,4,3)=n1*a;
                mpo.data{mm}(:,:,4,4)=eye(d,d);
            end
            
            mpo.data{1}=mpo.data{1}(:,:,end,:); 
            mpo.data{M}=mpo.data{M}(:,:,:,1); 
            
        end
        
        
        
        
        
        function mpo=add_pbc_n1ab_n2ba(mpo,a,b,n1,n2)
        % Add periodic boundary conditions to MPO in the following form: 
        % n1 a1 bM + n2 b1 aM
        %
        % n1,n2 --- scalars
        %
        % DOUBLECHECK  
        
            d=size(a,1);
            M=length(mpo.data);
            oldD=size(mpo.data{1},4);
            newD=oldD+2;
            
            new_data=zeros(d,d,1,newD);
            new_data(:,:,1,1:oldD)=mpo.data{1};
            new_data(:,:,1,oldD+1)=n2*b;
            new_data(:,:,1,oldD+2)=n1*a;
            mpo.data{1}=new_data;
            
            for mm=2:M-1
                new_data=zeros(d,d,newD,newD);
                new_data(:,:,1:oldD,1:oldD)=mpo.data{mm};
                new_data(:,:,oldD+1,oldD+1)=eye(d,d);
                new_data(:,:,oldD+2,oldD+2)=eye(d,d);
                mpo.data{mm}=new_data;
            end
            
            new_data=zeros(d,d,newD,1);
            new_data(:,:,1:oldD,1)=mpo.data{M};
            new_data(:,:,oldD+1,1)=a;
            new_data(:,:,oldD+2,1)=b;
            mpo.data{M}=new_data;
        
        end
        
        
        
        
        
        function mpo=add_pbc_n1aa_n2bb_n3cc(mpo,a,b,c,n1,n2,n3)
        % Add periodic boundary conditions to MPO of the following form: 
        % n1 a1 aM + n2 b1 bM + n3 c1 cM
        %
        % n1,n2,n3 --- scalars
        %
        % DOUBLECHECK  
        
            ld=size(a,1);
            M=length(mpo.data);
            oldD=size(mpo.data{1},4);
            newD=oldD+3;
            
            new_data=zeros(ld,ld,1,newD);
            new_data(:,:,1,1:oldD)=mpo.data{1};
            new_data(:,:,1,oldD+1)=n1*a;
            new_data(:,:,1,oldD+2)=n2*b;
            new_data(:,:,1,oldD+3)=n3*c;
            mpo.data{1}=new_data;
            
            for mm=2:M-1
                new_data=zeros(ld,ld,newD,newD);
                new_data(:,:,1:oldD,1:oldD)=mpo.data{mm};
                new_data(:,:,oldD+1,oldD+1)=eye(ld,ld);
                new_data(:,:,oldD+2,oldD+2)=eye(ld,ld);
                new_data(:,:,oldD+3,oldD+3)=eye(ld,ld);
                mpo.data{mm}=new_data;
            end
            
            new_data=zeros(ld,ld,newD,1);
            new_data(:,:,1:oldD,1)=mpo.data{M};
            new_data(:,:,oldD+1,1)=a;
            new_data(:,:,oldD+2,1)=b;
            new_data(:,:,oldD+3,1)=c;
            mpo.data{M}=new_data;
        
        end
        
        
        
        
        
        function mpo=add_pbc_n1ab_n2ba_n3cd_n4dc(mpo,a,b,c,d,n1,n2,n3,n4)
        % Add periodic boundary conditions to MPO of the following form: 
        % n1 a1 bM + n2 b1 aM + n3 c1 dM + n4 d1 cM,
        %
        % n1,n2,n3,n4 --- scalars
        %
        % DOUBLECHECK  
        
            ld=size(a,1);
            M=length(mpo.data);
            oldD=size(mpo.data{1},4);
            newD=oldD+4;
            
            new_data=zeros(ld,ld,1,newD);
            new_data(:,:,1,1:oldD)=mpo.data{1};
            new_data(:,:,1,oldD+1)=n2*b;
            new_data(:,:,1,oldD+2)=n1*a;
            new_data(:,:,1,oldD+3)=n4*d;
            new_data(:,:,1,oldD+4)=n3*c;
            mpo.data{1}=new_data;
            
            for mm=2:M-1
                new_data=zeros(ld,ld,newD,newD);
                new_data(:,:,1:oldD,1:oldD)=mpo.data{mm};
                new_data(:,:,oldD+1,oldD+1)=eye(ld,ld);
                new_data(:,:,oldD+2,oldD+2)=eye(ld,ld);
                new_data(:,:,oldD+3,oldD+3)=eye(ld,ld);
                new_data(:,:,oldD+4,oldD+4)=eye(ld,ld);
                mpo.data{mm}=new_data;
            end
            
            new_data=zeros(ld,ld,newD,1);
            new_data(:,:,1:oldD,1)=mpo.data{M};
            new_data(:,:,oldD+1,1)=a;
            new_data(:,:,oldD+2,1)=b;
            new_data(:,:,oldD+3,1)=c;
            new_data(:,:,oldD+4,1)=d;
            mpo.data{M}=new_data;
        
        end
        
        
        
        
        
        function mpo=set_n1sumab_n2sumba_n3sumcd_n4sumdc_sume(mpo,a,b,c,d,e,n1,n2,n3,n4)
        % Set MPO = \sum(n1 a_i b_{i+1} + n2 b_i a_{i+1} + n3 c_i d_{i+1}...
        % + n4 d_i c_{i+1}) + \sum e_i
        %
        % e can be a single dxd matrix or a dxdxM array
        % n1,n2,n3,n4 --- scalars
            
            ld=size(a,1);
            M=length(mpo.data);
            
            if size(e,3)==1
                eten=repmat(e,1,1,M);
            elseif size(e,3)==M;
                eten=e;
            else
                error('ERROR: e needs to be a dxd matrix or a dxdxM array');
            end
            
            % (0 n2b n1a n4d n3c 1)    1                     1
            %                          a                     a
            %                          b                     b   
            %                          c                     c
            %                          d                     d
            %                          0 n2b n1a n4d n3c 1   0
            %          
            %                  1
            %                  a
            %                  b
            %                  c
            %                  d
            %                  n2 b1 a2 + n1 a1 b2 + n4 d1 c2 + n3 c1 d2
            %
            % n2 b0 a1 + n1 a0 b1 + n4 d0 c1 + n3 c0 d1 + n2 b1 a2 + n1 a1 b2 + n4 d1 c2 + n3 c1 d2
            
            for mm=1:M
                mpo.data{mm}=zeros(ld,ld,6,6);
                mpo.data{mm}(:,:,1,1)=eye(ld,ld);
                mpo.data{mm}(:,:,2,1)=a;
                mpo.data{mm}(:,:,3,1)=b;
                mpo.data{mm}(:,:,4,1)=c;
                mpo.data{mm}(:,:,5,1)=d;
                mpo.data{mm}(:,:,6,1)=eten(:,:,mm);
                mpo.data{mm}(:,:,6,2)=n2*b;
                mpo.data{mm}(:,:,6,3)=n1*a;
                mpo.data{mm}(:,:,6,4)=n4*d;
                mpo.data{mm}(:,:,6,5)=n3*c;
                mpo.data{mm}(:,:,6,6)=eye(ld,ld);
            end
            
            mpo.data{1}=mpo.data{1}(:,:,end,:); 
            mpo.data{M}=mpo.data{M}(:,:,:,1); 

        end
        
        
        
        
        
        function mpo=set_n1sumaa_n2sumbb_n3sumcc_sumd(mpo,a,b,c,d,n1,n2,n3)
        % Set MPO = \sum(n1 a_i a_{i+1} + n2 b_i b_{i+1} + n3 c_i c_{i+1}) + \sum d_i
        %
        % d can be a single dxd matrix or a dxdxM array
        % n1,n2,n3 --- scalars
            
            ld=size(a,1);
            M=length(mpo.data);
            
            if size(ld,3)==1
                dten=repmat(d,1,1,M);
            elseif size(ld,3)==M;
                dten=d;
            else
                error('ERROR: d needs to be a dxd matrix or a dxdxM array');
            end
            
            for mm=1:M
                mpo.data{mm}=zeros(ld,ld,5,5);
                mpo.data{mm}(:,:,1,1)=eye(ld,ld);
                mpo.data{mm}(:,:,2,1)=a;
                mpo.data{mm}(:,:,3,1)=b;
                mpo.data{mm}(:,:,4,1)=c;
                mpo.data{mm}(:,:,5,1)=dten(:,:,mm);
                mpo.data{mm}(:,:,5,2)=n1*a;
                mpo.data{mm}(:,:,5,3)=n2*b;
                mpo.data{mm}(:,:,5,4)=n3*c;
                mpo.data{mm}(:,:,5,5)=eye(ld,ld);
            end
            
            mpo.data{1}=mpo.data{1}(:,:,end,:); 
            mpo.data{M}=mpo.data{M}(:,:,:,1); 
            
        end
        
        
        
        
        
        function mpo=set_n1sumaa_sumc_lr(mpo,a,c,n1,exdec)
        % Set MPO = \sum J_{ij} n1 a_i a_j + \sum c_i
        %
        % c can be a single dxd matrix or a dxdxM array
        % n1 --- scalar
        %
        % DOUBLECHECK
            
            d=size(a,1);
            M=length(mpo.data);
            nroe=length(exdec.lambdas);
            DO=nroe+2;
            
            if size(c,3)==1
                cten=repmat(c,1,1,M);
            elseif size(c,3)==M;
                cten=c;
            else
                error('ERROR: c needs to be a dxd matrix or a dxdxM array');
            end
            
            for mm=1:M
                mpo.data{mm}=zeros(d,d,DO,DO);
                mpo.data{mm}(:,:,1,1)=eye(d,d);
                mpo.data{mm}(:,:,end,end)=eye(d,d);
                for nn=1:nroe
                    mpo.data{mm}(:,:,nn+1,1)=exdec.xs(nn).*a;
                    mpo.data{mm}(:,:,end,nn+1)=n1*a;
                    mpo.data{mm}(:,:,nn+1,nn+1)=exdec.lambdas(nn).*eye(d,d);
                end
                mpo.data{mm}(:,:,end,1)=cten(:,:,mm);
            end
            
            mpo.data{1}=mpo.data{1}(:,:,end,:); 
            mpo.data{M}=mpo.data{M}(:,:,:,1);
            
        end
        
        
        
        
        
        function mpo=set_n1sumab_n2sumba_sumc_lr(mpo,a,b,c,n1,n2,exdec)
        % Set MPO = \sum J_{ij} n1 a_i b_j + n2 b_i a_j + \sum c_i
        %
        % c can be a single dxd matrix or a dxdxM array
        % n1,n2 --- scalars
        %
        % DOUBLECHECK
            
            d=size(a,1);
            M=length(mpo.data);
            nroe=length(exdec.lambdas);
            DO=2*nroe+2;
            
            if size(c,3)==1
                cten=repmat(c,1,1,M);
            elseif size(c,3)==M;
                cten=c;
            else
                error('ERROR: c needs to be a dxd matrix or a dxdxM array');
            end
            
            for mm=1:M
                mpo.data{mm}=zeros(d,d,DO,DO);
                mpo.data{mm}(:,:,1,1)=eye(d,d);
                mpo.data{mm}(:,:,end,end)=eye(d,d);
                for nn=1:nroe
                    mpo.data{mm}(:,:,(2*nn-1)+1,1)=exdec.xs(nn).*a;
                    mpo.data{mm}(:,:,(2*nn)+1,1)=exdec.xs(nn).*b;
                    mpo.data{mm}(:,:,end,(2*nn-1)+1)=n2*b;
                    mpo.data{mm}(:,:,end,(2*nn)+1)=n1*a;
                    mpo.data{mm}(:,:,(2*nn-1)+1,(2*nn-1)+1)= exdec.lambdas(nn).*eye(d,d);
                    mpo.data{mm}(:,:,(2*nn)+1,(2*nn)+1)= exdec.lambdas(nn).*eye(d,d);
                end
                mpo.data{mm}(:,:,end,1)=cten(:,:,mm);
            end
            
            mpo.data{1}=mpo.data{1}(:,:,end,:); 
            mpo.data{M}=mpo.data{M}(:,:,:,1);
            
        end
        
        
        
        
        
        function mpo=mult(mpo,mpo2)
        % Multiply two MPOs (==mpo*mpo2)
        %
        % Note: the order is important
        %
        % DOUBLECHECK
            
            M=length(mpo.data);
            
            for mm=1:M

                m1sz(1)=size(mpo.data{mm},1);
                m1sz(2)=size(mpo.data{mm},2);
                m1sz(3)=size(mpo.data{mm},3);
                m1sz(4)=size(mpo.data{mm},4);

                m2sz(1)=size(mpo2.data{mm},1);
                m2sz(2)=size(mpo2.data{mm},2);
                m2sz(3)=size(mpo2.data{mm},3);
                m2sz(4)=size(mpo2.data{mm},4);
                
                tmp1=reshape(mpo2.data{mm},[m2sz(1) m2sz(2)*m2sz(3)*m2sz(4)]);

                tmp2=permute(mpo.data{mm},[1 3 4 2]);
                tmp2=reshape(tmp2,[m1sz(1)*m1sz(3)*m1sz(4) m1sz(2)]);
                
                tmp2=reshape(tmp2*tmp1,[m1sz(1) m1sz(3) m1sz(4) m2sz(2) m2sz(3) m2sz(4)]);
                tmp2=permute(tmp2,[1 4 2 5 3 6]);
                mpo.data{mm}=reshape(tmp2, [m1sz(1) m2sz(2) m1sz(3)*m2sz(3) m1sz(4)*m2sz(4)]);
                
            end
            
        end
        
        
        
        
        
        function mpo=sum(mpo,mpo2)
        % Sum up two MPOs (==mpo+mpo2)
        %
        % The outrup MPO has block-diagonal contraction
        %
        % DOUBLECHECK
            
            M=length(mpo.data);
            if M~=length(mpo2.data)
                error('Error: MPOs have different lengths')
            end            
            
            for mm=1:M
                [m1sz1,m1sz2,m1sz3,m1sz4]=size(mpo.data{mm});
                [~    ,~    ,m2sz3,m2sz4]=size(mpo2.data{mm});
                
                if     mm==1
                    tmp=zeros(m1sz1,m1sz2,1          ,m1sz4+m2sz4);
                    tmp(:,:,1,1:m1sz4    )=mpo.data{mm};
                    tmp(:,:,1,m1sz4+1:end)=mpo2.data{mm};
                elseif mm==M
                    tmp=zeros(m1sz1,m1sz2,m1sz3+m2sz3,1          );
                    tmp(:,:,1:m1sz3    ,1)=mpo.data{mm};
                    tmp(:,:,m1sz3+1:end,1)=mpo2.data{mm};
                else
                    tmp=zeros(m1sz1,m1sz2,m1sz3+m2sz3,m1sz4+m2sz4);
                    tmp(:,:,1:m1sz3    ,1:m1sz4    )=mpo.data{mm};
                    tmp(:,:,m1sz3+1:end,m1sz4+1:end)=mpo2.data{mm};
                end
                mpo.data{mm}=tmp;                
                
            end
            
        end
        
        
        
        
        
        function mpo=get_conj(mpo) 
        % Return complex conjugated MPO
            
            M=length(mpo.data);
            
            for mm=1:M
                mpo.data{mm}=conj(mpo.data{mm});
            end
            
        end
        
        
        
        
        
        function mpo=get_transpose(mpo) 
        % Return transposed MPO
            
            M=length(mpo.data);
            
            for mm=1:M
                mpo.data{mm}=permute(mpo.data{mm},[2 1 3 4]);
            end
            
        end
        
        
        
        
        
        function mpo=get_herm_conj(mpo) 
        % Return Hermitian conjugated MPO
            
            mpo=mpo.get_conj();
            mpo=mpo.get_transpose();
            
        end
        
        
        
        
        
        function mpo=trotter_sweep(mpo, nn_hams, dt)
        % Take a cell array of M-1 nearest neighbor Hamiltonians
        % (nn_hams) and creates a mpo time-evolution operator via
        % trotter expansion of order "order". nn_hams have the "form"
        % (left_down*right_down,left_up*right_up).
        %
        % REPLACE UP/DOWN WITH IN/OUT
        % 
        % WORKS, BUT NOT EFFICIENT, DIRECT APPLICATION IS BETTER
            
            d=sqrt(size(nn_hams{1},1));

            M=length(mpo.data);
            
            UL=expm(-1i.*dt.*nn_hams{1});
            UL=reshape(UL,[d d d d]);
            UL=permute(UL,[1 3 2 4]);            
            UL=reshape(UL,[d*d d*d]);

            [L,lam,R]=svd(UL);
            lam=diag(lam);
            R=R';
            cDmax=length(find(lam>mpo.zero_thres));

            L=L(:,1:cDmax)*diag(lam(1:cDmax));
            R=R(1:cDmax,:);
            
            mpo.data{1}=reshape(L,[d d 1 cDmax]);
            
            oldR=reshape(R, [cDmax d d]);
            oldR=permute(oldR, [1 3 2]); % reshape for later contraction
            oldR=reshape(oldR, [cDmax*d d]);
            
            % next sites
            for mm=2:(M-1)
                
                UL=expm(-1i.*dt.*nn_hams{mm});
                UL=reshape(UL,[d d d d]);
                UL=permute(UL,[1 3 2 4]);            
                UL=reshape(UL,[d*d d*d]);
                [L,lam,R]=svd(UL);
                lam=diag(lam);
                R=R';
                cDmax=length(find(lam>mpo.zero_thres));
                
                L=L(:,1:cDmax)*diag(lam(1:cDmax));
                L=reshape(L,[d d cDmax]);
                L=permute(L,[2 1 3]);
                L=reshape(L,[d d*cDmax]);
                L=reshape(oldR*L,[cDmax d d cDmax]);
                L=permute(L,[3 2 1 4]);
                mpo.data{mm}=L;
                
                R=R(1:cDmax,:);
                
                if mm<(M-1)
                    oldR=reshape(R, [cDmax d d]);
                    oldR=permute(oldR, [1 3 2]); 
                    oldR=reshape(oldR, [cDmax*d d]);
                end
            end
            
            
            R=reshape(R, [cDmax d d 1]);
            R=permute(R, [2 3 1 4]);
            mpo.data{M}=R;
            
        end
        
        
                
        
        
        function mpo=set_data(mpo,data,isites)
        % Set any MPO manually
        %
        % It's used when Hamiltonian is too specific, so it won't be used
        % by other users.
        %
        % There are 2 ways to use this function:
        % 1. nargin==2: data is a cell(1,M), which replaces mpo.data
        % 2. nargin==3: data is a 4D array, which replaces mpo.data(isites)
        %
        % Note: isites can be a vector
            
            if nargin==2
                if and(iscell(data),size(data,2)==length(mpo.data))
                    mpo.data=data;
                else
                    error('ERROR: wrong input')
                end
            elseif nargin==3
                for is=isites
                    mpo.data{is}=data;
                end
            else
                error('ERROR: wrong input')
            end
            
        end  
        
        
        
        
        
        function mpo=convert_mps2mpo(mpo,mps)
        % Conver MPS to MPO
        %
        % Split local dimention dd of MPS into d_out==d_in and save the object
        % as MPO with tensor dimensions d_out x d_in x D_left x D_right
        %
        % Comment: maybe make it more general so d_out~=d_in
            
            if length(mps.data)~=length(mpo.data)
                error('wrong object size')
            end
            
            for iM=1:length(mpo.data)
                [dd,DL,DR]=size(mps.data{iM});
                d=sqrt(dd);
                if floor(d)~=d, error('local dimensions '); end
                mpo.data{iM}=reshape(mps.data{iM},[d d DL DR]);
            end
            
        end
        
        
        
        
        
        function [mpo,trunc]=compress_via_svd(mpo,lrcan)
        % Compression MPO via SVD on each bond
        % Use as preliminary, quick compression before variational
        % compression.
        %
        % lrcan is basically irrelevantl
        %
        % NOTE: probably it is better to have this function in mps.m
            
            M=length(mpo.data);
            trunc=zeros(1,M-1);
            
            if lrcan
                MVec=1:M-1;
            else
                MVec=M-1:-1:1;
            end
                
            for iM=MVec
                
                [dout_A,din_A,DL_A,DR_A]=size(mpo.data{iM}); 
                [dout_B,din_B,DL_B,DR_B]=size(mpo.data{iM+1}); 
                
                A=reshape(mpo.data{iM},  [dout_A*din_A DL_A DR_A]);
                B=reshape(mpo.data{iM+1},[dout_B*din_B DL_B DR_B]);
                
                % ~lrcan trick spreads the norm across the whole mpo
                [A,B,trunc(iM)]=compress_3Darrays(A,B,~lrcan,mpo.zero_thres);
                cDim=size(A,3); % that is the compressed dimension
                
                mpo.data{iM}  =reshape(A,[dout_A din_A DL_A cDim]);
                mpo.data{iM+1}=reshape(B,[dout_B din_B cDim DR_B]);
                
            end
            
        end
        
        
        
        
        
        function sizes=get_data_sizes(mpo)
        % Return sizes of data cells

            MVec=1:length(mpo.data);
            sizes=zeros(length(mpo.data),4);
            
            for iM=MVec
                [a,b,c,d]=size(mpo.data{iM});
                sizes(iM,:)=[a,b,c,d];
            end

        end
        
        end
        
        
        
        
        
        
        
        
        
        
        
        
        
end