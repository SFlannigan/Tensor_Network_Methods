function re_out = add_to_right_edge2_AB(re_in,mpsmatA,mpsmatB)
% Contract right edge with two 3D arrays, <B|A>
%
% If B is not provided replaces it with conj(A).
%
% NOTE: this funciton reproduces a basic overlab <B|A>, but B array 
% should be conjugated beforehand!
% This reversed order is chosen, so as to avoid misunderstanding when
% providing only one 3D array.
% 
% Contraction scheme:
%  +---+    +----+
% 2| A |3  2|    |
%  +---+    |    |
%    1      |    |
%           | re |
%    1      |    |
%  +---+    |    |
% 2| B |3  1|    |
%  +---+    +----+
%
% Benchmarking:
% addpath('./kernel/')
% addpath('./tools/')
% re_in = rand(12,11);
% mpsmatA = rand(10,11,11)+1i*rand(10,11,11);
% mpsmatB = rand(10,12,12)+1i*rand(10,12,12);
% re_out = add_to_right_edge2_AB(re_in,mpsmatA,mpsmatB);
% re_out_ncon = ncon({re_in,mpsmatA,mpsmatB},{[1 2],[3 -2 2],[3 -1 1]},[1 2 3]);
% % % one 3D array
% % re_in = rand(11,11);
% % re_out = add_to_right_edge2_AB(re_in,mpsmatA);
% % re_out_ncon = ncon({re_in,mpsmatA,conj(mpsmatA)},{[1 2],[3 -2 2],[3 -1 1]},[1 2 3]);
% max(max(abs((re_out-re_out_ncon)./re_out)))

if nargin==2
    mpsmatB=conj(mpsmatA);
end

% A/B sizes
[szA1,szA2,szA3]=size(mpsmatA);
[szB1,szB2,szB3]=size(mpsmatB);

tmp1=reshape(mpsmatB, [szB1*szB2 szB3]);
tmp1=reshape(tmp1*re_in, [szB1 szB2 szA3]);
tmp1=permute(tmp1, [2 1 3]);
tmp1=reshape(tmp1, [szB2 szB1*szA3]);

tmp2=permute(mpsmatA, [1 3 2]);
tmp2=reshape(tmp2, [szA1*szA3 szA2]);

re_out=tmp1*tmp2;

end