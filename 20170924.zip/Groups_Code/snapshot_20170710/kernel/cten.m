classdef cten
% class for a number conserving tensors 
%
    
    properties (SetAccess=public)
        
        nc
        tens
        imap
        isin
        
    end



    properties (SetAccess=protected)
        
        
    end



    methods
        
        
       
        function cten = cten(isin, nc)
            
            cten.nc = nc;
            cten.tens = cell(0, 1);
            cten.imap = zeros(0, nc.* length(isin) );
            cten.isin = isin;
            
            
        end
        
        
        
        
        function cten = insert(cten, in_qn, ten)
        % inserts a tensor with in_qn without check (every qn in imap must be
        % unique)
            
            if ismember(in_qn, cten.imap, 'rows')
               error('in_qn already exists') 
            end
            
            cten.tens{end+1,1} = ten;
            cten.imap(end+1,:) = in_qn;
            
        end
        
        
        
        
        
        
        
        function A = conjugate(A, idxA)
        % reverses all index directions and complex conjugates
            A.isin = ~ A.isin;
            
            for dd = 1:size(A.tens,1)
                A.tens{dd} = conj(A.tens{dd});
            end
        end
        
        
        
        
        
        
        function A = permute(A, perm)
        % permute indices
            
            nc = A.nc;
            
            % permute isin
            A.isin = A.isin(perm);
            
            % permute qns
            new_qns = zeros(size(A.imap));
            for ii = 1:length(A.isin)
                jj = perm(ii);
                ran_jj = ((jj-1).*nc + 1) : jj.*nc;
                ran_ii = ((ii-1).*nc + 1) : ii.*nc;
                new_qns(:, ran_ii) = A.imap(:, ran_jj);
            end
            A.imap = new_qns;

            for dd = 1:size(A.tens,1)
                A.tens{dd} = permute(A.tens{dd}, perm);
            end
            
            
        end
        
        
        
        
        
        function A = add_const_qn(A, const_qn, idx_i, idx_o)
        % adds a constant quantum number to input index idx_i and output index
        % idx_o
           
            if A.isin(idx_i) == A.isin(idx_o)
                error('can add constant only to io-combo')
            end
                
            nc = A.nc;
            
            ran_i = ( (idx_i-1) .* nc + 1) : (idx_i).*nc;
            ran_o = ( (idx_o-1) .* nc + 1) : (idx_o).*nc;

            nb = size(A.imap,1);

            A.imap(:, ran_i) =  A.imap(:, ran_i) + repmat(const_qn, [nb 1]);
            A.imap(:, ran_o) =  A.imap(:, ran_o) + repmat(const_qn, [nb 1]);
            
            
        end
        
        
        
        
        
        function A = merge_cten(A, B)
        % adds another cten with unique numbers. Check uniqueness
           
            new_imap = [A.imap; B.imap];
            
            if size(unique(new_imap, 'rows'), 1) ~= size(new_imap, 1)
                error('cannot merge, new cten.imap not unique');
            end
            
            A.imap = new_imap;
            A.tens = [A.tens; B.tens];
            
        end
        
        
        
        
        
        function C = contract(A, ni,  B)
        % contracts A with B over the first ni dimensions
            
            if  sum(A.isin(1:ni) ~= B.isin(1:ni)) ~= ni
                
                error(['Wrong io configuration ' ...
                       ' A.isin->[' num2str(A.isin(1:ni)) ']' ...
                       ' and B.isin->[' num2str(B.isin(1:ni)) ']' ]);
            end

            nc = A.nc;
            
            % useful numbers
            nia = length(A.isin); % number of indices A
            nib = length(B.isin);
            nra = nia - ni; % number of remaining indices A
            nrb = nib - ni;
            
            new_isin = [A.isin( (ni+1):end ) B.isin( (ni+1):end )];
            nic = length(new_isin); 
            
            C = cten(new_isin, nc);
            
            % build list of matching blocks for connecting index (bls)
            inda = 1 : (ni.*nc);
            indb = 1 : (ni.*nc);
            ind_rema = (ni.*nc+1) : nia.*nc;
            ind_remb = (ni.*nc+1) : nib.*nc;
            
            bls = zeros(0,2);
            nqnb = size(B.imap(:, indb),1);
            for aa = 1:size(A.imap,1)
                cur_qns = A.imap(aa, inda);
                
                bbs = find( all( repmat(cur_qns, nqnb , 1) == B.imap(:, indb), 2));
                sbbs = length(bbs);
                if sbbs
                    bls = [bls; aa.*ones(sbbs,1) bbs];
                end
            end
            
            % add new qns and allocate C
            for ii = 1:size(bls, 1)
                
                aa = bls(ii,1);
                bb = bls(ii,2);
                
                qn = [A.imap(aa, ind_rema)  B.imap(bb, ind_remb)];
                
                szc = zeros(1, nic);
                for cc = 1:nra
                    szc(cc) = size(A.tens{aa},ni+cc);
                end
                for cc = 1:nrb
                    szc(nra+cc) = size(B.tens{bb},ni+cc);
                end
                
                C = C.insert(qn, zeros(szc));
            end

            
            % perform multiplication. can be made parallel
            for ii = 1:size(bls, 1)
                
                aa = bls(ii,1);
                bb = bls(ii,2);
                
                tmpa = A.tens{aa};
                tmpb = B.tens{bb};
                
                sza = zeros(1, nia);
                for cc = 1:nia
                    sza(1, cc) = size(tmpa, cc);
                end
                
                szb = zeros(1, nib);
                for cc = 1:nib
                    szb(1, cc) = size(tmpb, cc);
                end
                
                s1 = prod( sza( 1:ni ) );
                s2 = prod( sza( (ni+1):end ) );
                tmpa = reshape(tmpa, [s1 s2]);

                s1 = prod( szb( 1:ni ) );
                s2 = prod( szb( (ni+1):end ) );
                tmpb = reshape(tmpb, [s1 s2]);
                
                C.tens{ii} = transpose(tmpa)*tmpb;

            end
            
        end
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    end
            
    
    
    
    
    
    
        
    methods (Access=protected)   
            
        
        
             
    end
    
        
end



















% functions not-needed: functions that where written at one point but aren't needed





        
%{
function cten = insert_unique(cten, in_qn, ten)
% inserts a tensor with in_qn and check whether in_qn already exists,
% only insert if it doesn't.
    
    if ~ismember(in_qn, cten.imap, 'rows')
        
        cten.tens{end+1,1} = ten;
        cten.imap(end+1,:) = in_qn;
        
    end
    
end
%}
        
