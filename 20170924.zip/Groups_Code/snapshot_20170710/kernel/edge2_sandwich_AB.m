function nr_out = edge2_sandwich_AB(le2_in,re2_in,mps_in_A,mps_in_B)
% Contract left and right edges with two 3D arrays
%
% If B is not provided replaces it with conj(A).
%
% NOTE: this funciton reproduces a basic overlab <B|A>, but B array 
% should be conjugated beforehand!
% This reversed order is chosen, so as to avoid misunderstanding when
% providing only one 3D array.
%  
% Contraction scheme:
% +----+    +---+    +----+
% |    |2  2| A |3  2|    |
% |    |    +---+    |    |
% |    |      1      |    |
% | le |             | re |
% |    |      1      |    |
% |    |    +---+    |    |
% |    |1  2| B |3  1|    |
% +----+    +---+    +----+
%
% Benchmarking:
% addpath('./tools/')
% re2_in = rand(12,11);
% le2_in = rand(12,11);
% mps_in_A = rand(10,11,11)+1i*rand(10,11,11);
% mps_in_B = rand(10,12,12)+1i*rand(10,12,12);
% nr_out = edge2_sandwich_AB(le2_in,re2_in,mps_in_A,mps_in_B);
% nr_out_ncon = ncon({le2_in,re2_in,mps_in_A,mps_in_B},...
%     {[4 5],[1 2],[3 5 2],[3 4 1]},[1 2 3 4 5]);
% max(max(abs((nr_out-nr_out_ncon)./nr_out)))

    if nargin==3
        tmp1=add_to_right_edge2_AB(re2_in,mps_in_A);
    else
        tmp1=add_to_right_edge2_AB(re2_in,mps_in_A,mps_in_B);
    end
    
    tmp1=reshape(tmp1, [numel(tmp1) 1]);
    tmp2=reshape(le2_in, [1 numel(le2_in)]);
    nr_out=tmp2*tmp1;
    
end