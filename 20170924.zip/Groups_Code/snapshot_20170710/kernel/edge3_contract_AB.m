function mps_out = edge3_contract_AB(le_in,re_in,mpoX,mps_in,mpssz)
% Contract left and right edges and one 4D array with only one 3D tensor,
% the other one is its output
%
% If mps_in is given in a form of a column, its sizes must be providet
% (it's needed for using this function for eigs,expv,etc.).
%
% Note: input and output tensor can have different sizes
%
% Contraction scheme:
% +----+    +---+    +----+
% |    |3  2|in |3  3|    |
% |    |    +---+    |    |
% |    |      1      |    |
% |    |             |    |
% |    |      2      |    |
% |    |    +---+    |    |
% | le |2  3|mpo|4  2| re |
% |    |    +---+    |    |
% |    |      1      |    |
% |    |             |    |
% |    |     -1      |    |
% |    |    +---+    |    |
% |    |1 -2|out|-3 1|    |
% +----+    +---+    +----+
%
% Benchmarking:
% addpath('./tools/')
% addpath('./kernel/')
% re_in = rand(12,7,11);
% le_in = rand(12,7,11);
% mps_in = rand(10,11,11)+1i*rand(10,11,11);
% mpoX = rand(10,10,7,7)+1i*rand(10,10,7,7);
% % if given a 3D array
% mps_out = edge3_contract_AB(le_in,re_in,mpoX,mps_in);
% mps_out_ncon = ncon({le_in,re_in,mpoX,mps_in},...
%     {[-2 1 2],[-3 4 5],[-1 3 1 4],[3 2 5]},[2 1 3 4 5]);
% max(max(max(abs((mps_out-mps_out_ncon)./mps_out))))
% % if given a column
% mps_out = edge3_contract_AB(le_in,re_in,mpoX,reshape(mps_in, [numel(mps_in) 1]),size(mps_in));
% mps_out_ncon = reshape(ncon({le_in,re_in,mpoX,mps_in},...
%     {[-2 1 2],[-3 4 5],[-1 3 1 4],[3 2 5]},[2 1 3 4 5]),[1440 1]);
% max(abs((mps_out-mps_out_ncon)./mps_out))

if nargin==5
    % in this case input is a column, which to be reshaped to the 3D array 
    % output should be reshaped in a column accordingly
    mps_in=reshape(mps_in,mpssz);
end

% sizes
[mpssz1,mpssz2,mpssz3]=size(mps_in);
[mposz1,mposz2,mposz3,mposz4]=size(mpoX);
[lesz1,lesz2,lesz3]=size(le_in);
[resz1,resz2,resz3]=size(re_in);

tmp1=reshape(re_in,[resz1*resz2 resz3]);

tmp2=reshape(mps_in,[mpssz1*mpssz2 mpssz3]);
tmp2=permute(tmp2,[2 1]);

tmp2=reshape(tmp1*tmp2 , [resz1 resz2*mpssz1 mpssz2]);
tmp2=permute(tmp2,[2 3 1]);
tmp2=reshape(tmp2,[resz2*mpssz1 mpssz2*resz1]);

tmp1=permute(mpoX,[1 3 4 2]);
tmp1=reshape(tmp1,[mposz1*mposz3 mposz4*mposz2]);

tmp2=reshape(tmp1*tmp2, [mposz1 mposz3*mpssz2 resz1]);
tmp2=permute(tmp2, [2 1 3]);
tmp2=reshape(tmp2, [mposz3*mpssz2 mposz1*resz1]);

tmp1=reshape(le_in, [lesz1 lesz2*lesz3]);

tmp2=reshape(tmp1*tmp2, [lesz1 mposz1 resz1]);
mps_out=permute(tmp2, [2 1 3]);

if nargin==5
    mps_out=reshape(mps_out,[numel(mps_out) 1]);
end

end