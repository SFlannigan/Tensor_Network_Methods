function AB=merge_3Darrays(A,B)
% Contract two 3D arrays in the middle and merge parallel indices
%
% Contraction scheme:
%   +---+    +---+
%  2| A |3  2| B |3
%   +---+    +---+
%     1        1
%
% TO
%
%   +----+  
%  2| AB |3 
%   +----+  
%     11
%
% Benchmarking:
% addpath('./tools/')
% addpath('./kernel/')
% A = rand(20,10,11);
% B = rand(20,11,12);
% AB = merge_3Darrays(A,B);
% AB_ncon = reshape(ncon({A,B}, {[-1 -3 1],[-2 1 -4]}),[20^2 10 12]);
% max(max(max(abs((AB-AB_ncon)./AB))))

[d_A,DL_A,DR_A]=size(A); 
[d_B,DL_B,DR_B]=size(B); 

AB = reshape(A,[d_A*DL_A DR_A]);

tmp = permute(B,[2 1 3]);
tmp = reshape(tmp,[DL_B d_B*DR_B]);

AB = reshape(AB*tmp, [d_A DL_A d_B DR_B]);
AB = permute(AB, [1 3 2 4]);
AB = reshape(AB, [d_A*d_B DL_A DR_B]);
    
end