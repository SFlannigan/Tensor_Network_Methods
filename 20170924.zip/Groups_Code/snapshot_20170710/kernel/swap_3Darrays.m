function [Anew,Bnew,trunc]=swap_3Darrays(A,B,lrschmidt,Dmax)
% Swap two 3D arrays and truncate if needed
%
% Contraction scheme:
%    +----+       +----+
%  2A| A  |3A - 2B| B  |3B
%    +----+       +----+
%      1A           1B
%
% TO
%
%    +----+       +----+
%  2A|Anew|3a - 2b|Bnew|3B
%    +----+       +----+
%      1B           1A
%
% size(3A)==size(2B) and in general is not equal to size(3a)==size(2b)
% If Dmax is defined, then truncate the middle dimension
%
% If lrschmidt==1, merge Schmidt coefficients into Anew (Bnew is right-canonical),
% if lrschmidt==0, merge Schmidt coefficients into Bnew (Anew is  left-canonical)

[d_A,DL_A,DR_A]=size(A); 
[d_B,DL_B,DR_B]=size(B); 

A=reshape(A,[d_A*DL_A DR_A]);
B=permute(B,[2 1 3]);
B=reshape(B,[DL_B d_B*DR_B]);

AB=reshape(A*B,[d_A DL_A d_B DR_B]);
AB=permute(AB,[3 2 1 4]);
AB=reshape(AB,[d_B*DL_A d_A*DR_B]);

if     nargin==3
    % qr
    if lrschmidt
        [Bnew,Anew]=qr(AB.',0);
        Anew=Anew.';
        Bnew=Bnew.';
    else
        [Anew,Bnew]=qr(AB,0);
    end
    trunc=0;
elseif nargin==4
    % svd with econ
    % !!! ??? AB(abs(AB)<10^-14)=0;    
    [L,lam,R]=svdecon(AB);
    
    % there could be NaNs
    L(~isfinite(L))=0;
    lam=diag(lam);   
    lam(~isfinite(lam))=0;
    R(~isfinite(R))=0;
    R=R';
    
    cDmax=min(Dmax,DR_A);
    trunc=sum(lam((cDmax+1):end).^2);
    
    if lrschmidt
        Anew=L(:,1:cDmax)*diag(lam(1:cDmax));
        Bnew=R(1:cDmax,:);
    else
        Anew=L(:,1:cDmax);
        Bnew=diag(lam(1:cDmax))*R(1:cDmax,:);
    end
else
    error('ERROR: wrong number of arguments')
end

% update the middle dimensions
DR_A=size(Anew,2);
DL_B=size(Bnew,1);

% restoration of the initial shapes
Anew=reshape(Anew,[d_B DL_A DR_A]);
Bnew=reshape(Bnew,[DL_B d_A DR_B]);
Bnew=permute(Bnew,[2 1 3]);
    
end