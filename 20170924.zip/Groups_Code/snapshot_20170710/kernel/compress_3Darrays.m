function [A,B,trunc]=compress_3Darrays(A,B,lrcan,zero_thres)
% Compress the middle bond dimension using SVD
%
% TO_DO: add comments and Dmax option

[d_A,DL_A,~   ]=size(A); 
[d_B,~   ,DR_B]=size(B); 

AB=merge_3Darrays(A,B);
AB=reshape(AB,[d_A d_B DL_A DR_B]);
AB=permute(AB,[1 3 2 4]);
AB=reshape(AB,[d_A*DL_A d_B*DR_B]);

[L,lam,R]=svd(AB,'econ');
lam=diag(lam);
R=R';

% cDmax=min(length(find(lam>zero_thres)),Dmax);
cDmax=length(find(lam>zero_thres*max(lam)));
trunc=sum(lam((cDmax+1):end).^2);

if lrcan
    A=reshape(L(:,1:cDmax)                   ,[d_A DL_A cDmax]);
    B=reshape(diag(lam(1:cDmax))*R(1:cDmax,:),[cDmax d_B DR_B]);
else
    A=reshape(L(:,1:cDmax)*diag(lam(1:cDmax)),[d_A DL_A cDmax]);
    B=reshape(R(1:cDmax,:)                   ,[cDmax d_B DR_B]);
end
B=permute(B,[2 1 3]);

end