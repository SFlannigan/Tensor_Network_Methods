function le_out = add_to_left_edge3_AB(le_in,mpsmatA,mpomat,mpsmatB)
% Contract left edge with two 3D arrays and one 4D array, <B|O|A>
%
% If B is not provided replaces it with conj(A).
%
% NOTE: this funciton reproduces a basic overlab <B|O|A>, but B array 
% should be conjugated beforehand!
% This reversed order is chosen, so as to avoid misunderstanding when
% providing only one 3D array.
% 
% Contraction scheme:
% +----+    +---+   
% |    |3  2| A |3  
% |    |    +---+   
% |    |      1     
% |    |            
% |    |      2     
% |    |    +---+   
% | le |2  3|mpo|4  
% |    |    +---+   
% |    |      1     
% |    |            
% |    |      1     
% |    |    +---+   
% |    |1  2| B |3  
% +----+    +---+ 
%
% Benchmarking:
% addpath('./tools/')
% le_in = rand(12,7,11);
% mpsmatA = rand(10,11,11)+1i*rand(10,11,11);
% mpsmatB = rand(10,12,12)+1i*rand(10,12,12);
% mpomat = rand(10,10,7,7)+1i*rand(10,10,7,7);
% le_out = add_to_left_edge3_AB(le_in,mpsmatA,mpomat,mpsmatB);
% le_out_ncon = ncon({le_in,mpsmatA,mpomat,mpsmatB},{[1 2 3],[5 3 -3],[4 5 2 -2],[4 1 -1]},[1 2 4 3 5]);
% % % one 3D array
% % le_in = rand(11,7,11);
% % le_out = add_to_left_edge3_AB(le_in,mpsmatA,mpomat);
% % le_out_ncon = ncon({le_in,mpsmatA,mpomat,conj(mpsmatA)},{[1 2 3],[5 3 -3],[4 5 2 -2],[4 1 -1]},[1 2 4 3 5]);
% max(max(max(abs((le_out-le_out_ncon)./le_out))))

if nargin==3
    mpsmatB=conj(mpsmatA);
end

[esszA,ehsz,esszB]       =size(le_in);
[csszA1,csszA2,csszA3]   =size(mpsmatA);
[csszB1,csszB2,csszB3]   =size(mpsmatB);
[chsz1,chsz2,chsz3,chsz4]=size(mpomat);

% B mps
tmp1=permute(mpsmatB, [1 3 2]);
tmp1=reshape(tmp1, [csszB1*csszB3 csszB2]);

% contract with le
tmp2=reshape(le_in,[esszA ehsz*esszB]);
tmp2=tmp1*tmp2;
tmp2=reshape(tmp2, [csszB1 csszB3 ehsz esszB]);
tmp2=permute(tmp2, [1 3 2 4]);
tmp2=reshape(tmp2, [csszB1*ehsz csszB3*esszB]);

% contract with mpo
tmp3=permute(mpomat, [2 4 1 3]);
tmp3=reshape(tmp3,[chsz2*chsz4 chsz1*chsz3]);

tmp2=reshape(tmp3*tmp2, [chsz2 chsz4 csszB3 esszB]);
tmp2=permute(tmp2, [3 2 1 4]);
tmp2=reshape(tmp2, [csszB3*chsz4 chsz2*esszB]);

% contract with A mps

tmp1=reshape(mpsmatA,[csszA1*csszA2 csszA3]);

le_out=reshape(tmp2*tmp1,[csszB3 chsz4 csszA3]);

end