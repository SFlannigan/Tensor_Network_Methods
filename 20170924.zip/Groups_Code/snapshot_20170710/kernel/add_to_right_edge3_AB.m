function re_out = add_to_right_edge3_AB(re_in,mpsmatA,mpomat,mpsmatB)
% Contract right edge with two 3D arrays and one 4D array, <B|O|A>
%
% If B is not provided replaces it with conj(A).
%
% NOTE: this funciton reproduces a basic overlab <B|O|A>, but B array 
% should be conjugated beforehand!
% This reversed order is chosen, so as to avoid misunderstanding when
% providing only one 3D array.
% 
% Contraction scheme:
%  +---+    +----+
% 2| A |3  3|    |
%  +---+    |    |
%    1      |    |
%           |    |
%    2      |    |
%  +---+    |    |
% 3|mpo|4  2| re |
%  +---+    |    |
%    1      |    |
%           |    |
%    1      |    |
%  +---+    |    |
% 2| B |3  1|    |
%  +---+    +----+
%
% Benchmarking:
% addpath('./tools/')
% re_in = rand(12,7,11);
% mpsmatA = rand(10,11,11)+1i*rand(10,11,11);
% mpsmatB = rand(10,12,12)+1i*rand(10,12,12);
% mpomat = rand(10,10,7,7)+1i*rand(10,10,7,7);
% le_out = add_to_right_edge3_AB(re_in,mpsmatA,mpomat,mpsmatB);
% le_out_ncon = ncon({re_in,mpsmatA,mpomat,mpsmatB},{[1 2 3],[5 -3 3],[4 5 -2 2],[4 -1 1]},[1 2 4 3 5]);
% % % one 3D array
% % le_in = rand(11,7,11);
% % le_out = add_to_right_edge3_AB(le_in,mpsmatA,mpomat);
% % le_out_ncon = ncon({le_in,mpsmatA,mpomat,conj(mpsmatA)},{[1 2 3],[5 -3 3],[4 5 -2 2],[4 -1 1]},[1 2 4 3 5]);
% max(max(max(abs((le_out-le_out_ncon)./le_out))))

if nargin==3
    mpsmatB=conj(mpsmatA);
end

[esszA,ehsz,esszB]       =size(re_in);
[csszA1,csszA2,csszA3]   =size(mpsmatA);
[csszB1,csszB2,csszB3]   =size(mpsmatB);
[chsz1,chsz2,chsz3,chsz4]=size(mpomat);

% B mps

tmp1=reshape(mpsmatB, [csszB1*csszB2 csszB3]);

% contract with re
tmp2=reshape(re_in,[esszA ehsz*esszB]);
tmp2=tmp1*tmp2;
tmp2=reshape(tmp2, [csszB1 csszB2 ehsz esszB]);
tmp2=permute(tmp2, [1 3 2 4]);
tmp2=reshape(tmp2, [csszB1*ehsz csszB2*esszB]);

% contract with mpo
tmp3=permute(mpomat, [2 3 1 4]);
tmp3=reshape(tmp3,[chsz2*chsz3 chsz1*chsz4]);

tmp2=reshape(tmp3*tmp2, [chsz2 chsz3 csszB2 esszB]);
tmp2=permute(tmp2, [3 2 1 4]);
tmp2=reshape(tmp2, [csszB2*chsz3 chsz2*esszB]);
                
% contract with A mps
tmp1=permute(mpsmatA,[1 3 2]);
tmp1=reshape(tmp1,[csszA1*csszA3 csszA2]);

re_out=reshape(tmp2*tmp1,[csszB2 chsz3 csszA2]);

end